import { existsSync, readFileSync } from 'node:fs';
const fail=m=>{console.error('BLOCKED:',m);process.exit(2)};
for (const p of ['package.json','.nvmrc','NETLIFY_RUNTIME_REQUIREMENTS.json','netlify.toml']) if(!existsSync(p)) fail(`missing runtime requirement file: ${p}`);
const pkg=JSON.parse(readFileSync('package.json','utf8'));
const req=JSON.parse(readFileSync('NETLIFY_RUNTIME_REQUIREMENTS.json','utf8'));
const nvm=readFileSync('.nvmrc','utf8').trim();
if(req.protocol!=='JOSHGPT-NETLIFY-RUNTIME-1') fail('runtime protocol mismatch');
if(req.version!==pkg.version) fail('runtime requirement version mismatch');
if(req.buildNodeMajor!==24||req.functionNodeMajor!==24) fail('Node 24 runtime requirement changed');
if(nvm!=='24') fail(`.nvmrc must pin Node 24, got ${nvm}`);
if(pkg.engines?.node!=='24.x') fail(`package engines.node must be 24.x, got ${pkg.engines?.node||'missing'}`);
const { execFileSync }=await import('node:child_process');
let hits='';
try { hits=execFileSync('grep',['-R','-n','--include=*.js','process\\.env','netlify/functions'],{encoding:'utf8'}); } catch(e) { if(e.status!==1) fail('environment-access scan failed'); }
if(hits.trim()) fail('process.env found in Netlify function runtime; JoshGPT policy requires Netlify.env');
console.log(JSON.stringify({protocol:req.protocol,status:'PASS',declaredBuildNode:'24',declaredFunctionNode:'24',engines:pkg.engines.node,nvmrc:nvm,environmentAccess:'NETLIFY_ENV_ONLY',localVerificationNode:process.versions.node,localNodeMatchesTarget:Number(process.versions.node.split('.')[0])===24},null,2));
