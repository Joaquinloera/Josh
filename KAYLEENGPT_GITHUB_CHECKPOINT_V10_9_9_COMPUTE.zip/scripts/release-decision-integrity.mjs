import { createHash } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { verifyDependencyLock } from './verify-dependency-lock.mjs';
const sha=v=>createHash('sha256').update(v).digest('hex');
const pkg=JSON.parse(readFileSync('package.json','utf8'));
const target={project:'joshgpt13',siteId:'322db469-6833-4187-b023-60638716b3c7',corporatePolicy:'DO_NOT_DEPLOY_OR_MODIFY'};
let decision=null; try{decision=JSON.parse(readFileSync('DEPENDENCY_RELEASE_DECISION.json','utf8'));}catch{}
let chain=null; try{chain=JSON.parse(readFileSync('DEPENDENCY_EVIDENCE_CHAIN.json','utf8'));}catch{}
const lockPresent=existsSync('package-lock.json');
const lockSha256=lockPresent?sha(readFileSync('package-lock.json')):null;
const decisionValid=!!decision&&decision.protocol==='JOSHGPT-DEPENDENCY-RELEASE-DECISION-1'&&decision.version===pkg.version&&decision.target?.project===target.project&&decision.target?.siteId===target.siteId&&decision.target?.corporatePolicy===target.corporatePolicy&&typeof decision.decisionDigest==='string'&&decision.decisionDigest.length===64;
const chainValid=!!chain&&chain.protocol==='JOSHGPT-DEPENDENCY-EVIDENCE-CHAIN-1'&&chain.version===pkg.version&&typeof chain.chainDigest==='string'&&chain.chainDigest.length===64;
const lockIntegrity=lockPresent?verifyDependencyLock(process.cwd()):{ok:false,errors:['package-lock.json missing']};
const bound=decisionValid&&chainValid&&lockPresent&&lockIntegrity.ok&&decision.status==='DEPENDENCY_RELEASE_GATE_READY'&&decision.lockBound===true&&decision.lockSha256===lockSha256&&decision.chainDigest===chain.chainDigest&&chain.lockPresent===true&&chain.lockSha256===lockSha256&&chain.status==='DEPENDENCY_LOCK_VERIFIED';
const blockers=[];
if(!decisionValid) blockers.push('DEPENDENCY_RELEASE_DECISION_INVALID');
if(!chainValid) blockers.push('DEPENDENCY_EVIDENCE_CHAIN_INVALID');
if(!lockPresent) blockers.push('MISSING_GENUINE_PACKAGE_LOCK');
if(lockPresent&&!lockIntegrity.ok) blockers.push('DEPENDENCY_LOCK_INTEGRITY_FAILED');
if(!bound) blockers.push('RELEASE_DECISION_NOT_BOUND_TO_CURRENT_LOCK');
const status=blockers.length?'RELEASE_BLOCKED':'RELEASE_DECISION_INTEGRITY_READY';
const report={protocol:'JOSHGPT-RELEASE-DECISION-INTEGRITY-1',version:pkg.version,target,policy:{failClosed:true,noLockFabrication:true,requiresCurrentLockBinding:true,requiresVerifiedEvidenceChain:true},decisionValid,chainValid,lockPresent,lockSha256,lockIntegrityOk:lockIntegrity.ok,bound,blockers,status};
report.reportDigest=sha(JSON.stringify(report));
writeFileSync('RELEASE_DECISION_INTEGRITY.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
process.exitCode=status==='RELEASE_DECISION_INTEGRITY_READY'?0:2;
