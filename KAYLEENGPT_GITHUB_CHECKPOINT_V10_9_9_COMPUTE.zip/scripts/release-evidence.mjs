import fs from 'node:fs';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';

const readJson=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const sha=v=>crypto.createHash('sha256').update(typeof v==='string'?v:JSON.stringify(v)).digest('hex');
const pkg=readJson('package.json');
const target=readJson('DEPLOYMENT_TARGET.json');
const manifest=readJson('RELEASE_MANIFEST.json');
const lockPresent=fs.existsSync('package-lock.json');
const commands=[
 ['releaseManifestVerify',['node','scripts/verify-release-manifest.mjs']],
 ['packageBoundary',['node','scripts/package-boundary.mjs']],
 ['runtimeVerify',['node','scripts/verify-netlify-runtime.mjs']],
 ['dependencyLockVerify',['node','scripts/verify-dependency-lock.mjs']],
 ['releaseBlockerConsensus',['node','scripts/release-blocker-consensus.mjs']],
];
const results={};
for(const [name,[cmd,...args]] of commands){
 const r=spawnSync(cmd,args,{encoding:'utf8',timeout:60000});
 results[name]={exitStatus:r.status,signal:r.signal||null,stdoutDigest:sha(r.stdout||''),stderrDigest:sha(r.stderr||'')};
}
const nonDependencyFailures=Object.entries(results).filter(([n,r])=>!['dependencyLockVerify','releaseBlockerConsensus'].includes(n)&&r.exitStatus!==0).map(([n])=>n);
const dependencyBlocked=!lockPresent || results.dependencyLockVerify.exitStatus!==0 || results.releaseBlockerConsensus.exitStatus===2;
const report={
 protocol:'JOSHGPT-RELEASE-EVIDENCE-1',version:pkg.version,
 target:{project:target.project,siteId:target.siteId,corporateSitePolicy:target.corporateSitePolicy},
 manifest:{digest:manifest.manifestDigest,fileCount:Object.keys(manifest.files||{}).length},
 dependency:{name:'@netlify/blobs',required:pkg.dependencies?.['@netlify/blobs'],lockPresent},
 results,nonDependencyFailures,
 status:nonDependencyFailures.length?'BLOCKED_NON_DEPENDENCY':dependencyBlocked?'BLOCKED_DEPENDENCY_LOCK_ONLY':'READY_FOR_FINAL_RELEASE_GATE'
};
report.evidenceDigest=sha(report);
fs.writeFileSync('RELEASE_EVIDENCE.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
if(nonDependencyFailures.length) process.exit(1);
if(dependencyBlocked) process.exit(2);
