import { spawnSync } from 'node:child_process';
import { existsSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { verifyDependencyLock } from './verify-dependency-lock.mjs';

const pkg=JSON.parse(readFileSync('package.json','utf8'));
const before=existsSync('package-lock.json')?createHash('sha256').update(readFileSync('package-lock.json')).digest('hex'):null;
const args=['install','--package-lock-only','--ignore-scripts','--no-audit','--no-fund','--fetch-retries=1','--fetch-timeout=20000'];
const run=spawnSync('npm',args,{encoding:'utf8',timeout:90000});
const text=`${run.stdout||''}\n${run.stderr||''}`;
let failure='NPM_RESOLUTION_FAILED';
if(/EAI_AGAIN|getaddrinfo/i.test(text)) failure='NPM_DNS_UNAVAILABLE';
else if(/ETIMEDOUT|timeout/i.test(text)) failure='NPM_NETWORK_TIMEOUT';
else if(/ECONNREFUSED|ENETUNREACH/i.test(text)) failure='NPM_NETWORK_UNREACHABLE';
else if(/E404|not found/i.test(text)) failure='NPM_PACKAGE_NOT_FOUND';
const verification=verifyDependencyLock(process.cwd());
// Never retain a newly-created lock unless it passes the strict verifier.
if(!verification.ok && !before && existsSync('package-lock.json')) rmSync('package-lock.json');
const after=existsSync('package-lock.json')?createHash('sha256').update(readFileSync('package-lock.json')).digest('hex'):null;
const report={protocol:'JOSHGPT-DEPENDENCY-LOCK-ACQUISITION-1',version:pkg.version,dependency:{name:'@netlify/blobs',required:'11.1.0'},attempt:{exitStatus:run.status,timedOut:Boolean(run.error?.code==='ETIMEDOUT')},verification,status:verification.ok?'ACQUIRED_VERIFIED':'BLOCKED',blocker:verification.ok?null:failure,lock:{beforeSha256:before,afterSha256:after,retained:Boolean(after)}};
report.reportDigest=createHash('sha256').update(JSON.stringify(report)).digest('hex');
writeFileSync('DEPENDENCY_LOCK_ACQUISITION.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
process.exitCode=verification.ok?0:2;
