import { promises as dns } from 'node:dns';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { readFileSync } from 'node:fs';

const host = 'registry.npmjs.org';
const attempts = 3;
const sha = v => createHash('sha256').update(v).digest('hex');
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const errors = [];
const observations = [];
let registry = null;
try { registry = execFileSync('npm',['config','get','registry'],{encoding:'utf8',timeout:5000}).trim(); } catch (e) { errors.push({stage:'npm_registry',code:e?.code||'NPM_CONFIG_ERROR'}); }

for (let i=1;i<=attempts;i++) {
  const row={attempt:i,lookup:[],resolve4:[],resolve6:[],errors:[]};
  try { row.lookup=(await dns.lookup(host,{all:true})).map(x=>x.address).sort(); } catch(e) { row.errors.push({method:'lookup',code:e?.code||'DNS_ERROR'}); }
  try { row.resolve4=(await dns.resolve4(host)).sort(); } catch(e) { row.errors.push({method:'resolve4',code:e?.code||'DNS_ERROR'}); }
  try { row.resolve6=(await dns.resolve6(host)).sort(); } catch(e) { row.errors.push({method:'resolve6',code:e?.code||'DNS_ERROR'}); }
  observations.push(row);
  if (row.lookup.length || row.resolve4.length || row.resolve6.length) break;
  if (i < attempts) await sleep(250 * i);
}
const reachable = observations.some(x=>x.lookup.length||x.resolve4.length||x.resolve6.length);
const codes=[...new Set(observations.flatMap(x=>x.errors.map(e=>e.code)))].sort();
const transientOnly = !reachable && codes.length>0 && codes.every(c=>['EAI_AGAIN','ETIMEOUT','SERVFAIL'].includes(c));
const status = reachable ? 'DNS_READY' : transientOnly ? 'BLOCKED_TRANSIENT_DNS' : 'BLOCKED_DNS';
const report={
  protocol:'JOSHGPT-DEPENDENCY-NETWORK-PROBE-1',
  packageVersion:JSON.parse(readFileSync('package.json','utf8')).version,
  host, registry, attemptsConfigured:attempts, attemptsPerformed:observations.length,
  reachable, errorCodes:codes, transientOnly, status, observations,
  policy:{boundedRetries:true,noProxyMutation:true,noDnsMutation:true,noLockFabrication:true}
};
report.reportDigest=sha(JSON.stringify(report));
console.log(JSON.stringify(report,null,2));
process.exitCode = reachable ? 0 : 2;
