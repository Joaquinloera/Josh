import { promises as dns } from 'node:dns';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { existsSync, readFileSync } from 'node:fs';

const required = '@netlify/blobs';
const requiredVersion = '11.1.0';
const registryHost = 'registry.npmjs.org';
const sha = (v) => createHash('sha256').update(v).digest('hex');
let npmVersion = null, registry = null, dnsAddresses = [], dnsError = null;
try { npmVersion = execFileSync('npm',['--version'],{encoding:'utf8',timeout:5000}).trim(); } catch {}
try { registry = execFileSync('npm',['config','get','registry'],{encoding:'utf8',timeout:5000}).trim(); } catch {}
try { dnsAddresses = (await dns.lookup(registryHost,{all:true})).map(x=>x.address).sort(); } catch (e) { dnsError = e?.code || e?.message || 'DNS_ERROR'; }
const lockPresent = existsSync('package-lock.json');
let lockSha256 = null;
if (lockPresent) lockSha256 = sha(readFileSync('package-lock.json'));
const status = lockPresent ? 'LOCK_PRESENT_VERIFY_REQUIRED' : (dnsAddresses.length ? 'NETWORK_READY_LOCK_ACQUISITION_REQUIRED' : 'BLOCKED_DNS');
const report = {
  protocol:'JOSHGPT-DEPENDENCY-ENVIRONMENT-READINESS-1',
  packageVersion:JSON.parse(readFileSync('package.json','utf8')).version,
  requiredDependency:`${required}@${requiredVersion}`,
  registryHost,
  npmVersion,
  registry,
  dnsReachable:dnsAddresses.length>0,
  dnsAddressCount:dnsAddresses.length,
  dnsError,
  lockPresent,
  lockSha256,
  status,
  noLockFabrication:true,
};
report.reportDigest = sha(JSON.stringify(report));
console.log(JSON.stringify(report,null,2));
process.exitCode = status === 'BLOCKED_DNS' ? 2 : 0;
