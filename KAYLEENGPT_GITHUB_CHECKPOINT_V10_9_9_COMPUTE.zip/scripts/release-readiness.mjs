import { existsSync, readFileSync } from 'node:fs';
import { verifyDependencyLock } from './verify-dependency-lock.mjs';
const fail=(m)=>{console.error(`BLOCKED: ${m}`);process.exitCode=2};
const pkg=JSON.parse(readFileSync('package.json','utf8'));
if(!/^\d+\.\d+\.\d+$/.test(pkg.version)) fail('package version is not valid semver');
if(pkg.dependencies?.['@netlify/blobs']!=='11.1.0') fail('@netlify/blobs is not pinned to 11.1.0');
if(!existsSync('package-lock.json')) fail('package-lock.json is missing; dependency resolution is not reproducibly locked');
else {
 const result=verifyDependencyLock(process.cwd());
 if(!result.ok) for(const error of result.errors) fail(`dependency lock integrity: ${error}`);
}
if(!process.exitCode) console.log(`PASS: V${pkg.version} dependency release gate`);
