import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';

const pkg=JSON.parse(readFileSync('package.json','utf8'));
const sha=v=>createHash('sha256').update(v).digest('hex');
const run=(script,timeout=120000)=>spawnSync(process.execPath,[script],{encoding:'utf8',timeout});
const parseLastJson=text=>{
  const start=text.indexOf('{');
  if(start<0) return null;
  try{return JSON.parse(text.slice(start));}catch{return null;}
};
const probeRun=run('scripts/dependency-network-probe.mjs',45000);
const probe=parseLastJson(probeRun.stdout||'');
let acquisition=null;
let acquisitionExecuted=false;
let status='BLOCKED_NETWORK';
let blocker=probe?.status||'NETWORK_PROBE_FAILED';
if(probe?.reachable===true){
  acquisitionExecuted=true;
  const acqRun=run('scripts/acquire-dependency-lock.mjs',120000);
  acquisition=parseLastJson(acqRun.stdout||'');
  if(acquisition?.status==='ACQUIRED_VERIFIED') { status='LOCK_ACQUIRED_VERIFIED'; blocker=null; }
  else { status='BLOCKED_ACQUISITION'; blocker=acquisition?.blocker||'LOCK_ACQUISITION_FAILED'; }
}
const lockPresent=existsSync('package-lock.json');
const report={
  protocol:'JOSHGPT-DEPENDENCY-RETRY-CONTROLLER-1',version:pkg.version,
  policy:{probeBeforeNpm:true,bounded:true,maxAcquisitionAttempts:1,noRegistryMutation:true,noProxyMutation:true,noDnsMutation:true,noLockFabrication:true},
  probe:{exitStatus:probeRun.status,status:probe?.status||null,reachable:probe?.reachable===true,reportDigest:probe?.reportDigest||null},
  acquisition:{executed:acquisitionExecuted,status:acquisition?.status||null,blocker:acquisition?.blocker||null,reportDigest:acquisition?.reportDigest||null},
  lockPresent,status,blocker
};
report.reportDigest=sha(JSON.stringify(report));
writeFileSync('DEPENDENCY_RETRY_STATUS.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
process.exitCode=status==='LOCK_ACQUIRED_VERIFIED'?0:2;
