import { existsSync, readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';

export function verifyDependencyLock(root='.') {
  const errors=[];
  const pkgPath=`${root}/package.json`;
  const lockPath=`${root}/package-lock.json`;
  if(!existsSync(lockPath)) return {ok:false,status:'BLOCKED_MISSING_LOCKFILE',errors:['package-lock.json is missing']};
  let pkg,lock;
  try { pkg=JSON.parse(readFileSync(pkgPath,'utf8')); } catch { return {ok:false,status:'INVALID_PACKAGE_JSON',errors:['package.json is invalid']}; }
  try { lock=JSON.parse(readFileSync(lockPath,'utf8')); } catch { return {ok:false,status:'INVALID_LOCK_JSON',errors:['package-lock.json is invalid']}; }
  if(!Number.isInteger(lock.lockfileVersion) || lock.lockfileVersion < 3) errors.push('lockfileVersion must be >= 3');
  const rootPkg=lock.packages?.[''];
  if(!rootPkg) errors.push('lockfile root package entry is missing');
  const expected=pkg.dependencies?.['@netlify/blobs'];
  if(expected!=='11.1.0') errors.push('package.json must pin @netlify/blobs to 11.1.0');
  if(rootPkg?.dependencies?.['@netlify/blobs']!==expected) errors.push('lockfile root dependency pin does not match package.json');
  const blobs=lock.packages?.['node_modules/@netlify/blobs'];
  if(!blobs) errors.push('@netlify/blobs resolved package entry is missing');
  else {
    if(blobs.version!==expected) errors.push('@netlify/blobs resolved version is not exactly 11.1.0');
    if(typeof blobs.resolved!=='string' || !blobs.resolved.startsWith('https://registry.npmjs.org/')) errors.push('@netlify/blobs resolved source is not the npm registry over HTTPS');
    if(typeof blobs.integrity!=='string' || !/^sha512-[A-Za-z0-9+/=]+$/.test(blobs.integrity)) errors.push('@netlify/blobs integrity is missing or not sha512');
  }
  for(const [name,entry] of Object.entries(lock.packages||{})) {
    if(!name.startsWith('node_modules/')) continue;
    if(typeof entry.version!=='string' || !entry.version) errors.push(`${name} has no resolved version`);
    if(entry.resolved && !/^https:\/\//.test(entry.resolved)) errors.push(`${name} uses a non-HTTPS resolved source`);
    if(entry.resolved && /^https:\/\/registry\.npmjs\.org\//.test(entry.resolved) && !/^sha512-[A-Za-z0-9+/=]+$/.test(entry.integrity||'')) errors.push(`${name} npm-registry entry lacks sha512 integrity`);
  }
  const digest=createHash('sha256').update(readFileSync(lockPath)).digest('hex');
  return {ok:errors.length===0,status:errors.length?'INVALID_LOCKFILE':'VERIFIED',errors,lockfileVersion:lock.lockfileVersion,packageCount:Object.keys(lock.packages||{}).length,sha256:digest};
}

if(import.meta.url===`file://${process.argv[1]}`){
  const r=verifyDependencyLock(process.cwd());
  console.log(JSON.stringify(r,null,2));
  process.exitCode=r.ok?0:2;
}
