import { createHash } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
const sha = value => createHash('sha256').update(value).digest('hex');
const readJson = p => { try { return JSON.parse(readFileSync(p,'utf8')); } catch { return null; } };
const pkg=readJson('package.json');
const target=readJson('DEPLOYMENT_TARGET.json');
const manifest=readJson('RELEASE_MANIFEST.json');
const auth=readJson('FINAL_RELEASE_AUTHORIZATION.json');
const lockPresent=existsSync('package-lock.json');
const lockSha256=lockPresent?sha(readFileSync('package-lock.json')):null;
const expected={project:'joshgpt13',siteId:'322db469-6833-4187-b023-60638716b3c7',corporateSitePolicy:'DO_NOT_DEPLOY_OR_MODIFY'};
const manifestDigest=manifest?sha(JSON.stringify(manifest)):null;
const checks={
 version:pkg?.version==='10.9.0',
 target:target?.project===expected.project&&target?.siteId===expected.siteId&&target?.corporateSitePolicy===expected.corporateSitePolicy,
 manifestCurrent:manifest?.protocol==='JOSHGPT-RELEASE-MANIFEST-2'&&manifest?.version===pkg?.version,
 authorizationCurrent:auth?.protocol==='JOSHGPT-FINAL-RELEASE-AUTHORIZATION-1'&&auth?.version===pkg?.version,
 authorizationDigestValid:auth?.authorizationDigest===sha(JSON.stringify(Object.fromEntries(Object.entries(auth??{}).filter(([k])=>k!=='authorizationDigest')))),
 authorizationReady:auth?.status==='FINAL_RELEASE_AUTHORIZED'&&auth?.blockers?.length===0,
 genuineLockBound:lockPresent&&auth?.lockSha256===lockSha256&&manifest?.files?.['package-lock.json']===lockSha256,
};
const blockers=Object.entries(checks).filter(([,ok])=>!ok).map(([k])=>k);
const status=blockers.length===0?'FINAL_RELEASE_RECEIPT_READY':'FINAL_RELEASE_RECEIPT_BLOCKED';
const receipt={protocol:'JOSHGPT-FINAL-RELEASE-RECEIPT-1',version:pkg?.version??null,target:expected,manifestDigest,authorizationDigest:auth?.authorizationDigest??null,lockSha256,policy:{failClosed:true,noLockFabrication:true,corporateSiteExcluded:true,receiptDoesNotDeploy:true},checks,blockers,status};
receipt.receiptDigest=sha(JSON.stringify(receipt));
writeFileSync('FINAL_RELEASE_RECEIPT.json',JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify(receipt,null,2));
process.exitCode=status==='FINAL_RELEASE_RECEIPT_READY'?0:2;
