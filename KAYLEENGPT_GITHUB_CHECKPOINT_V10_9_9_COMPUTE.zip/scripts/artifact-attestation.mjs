import fs from 'node:fs';
import crypto from 'node:crypto';
import { basename } from 'node:path';
import { spawnSync } from 'node:child_process';
const zipPath=process.argv[2];
const fail=m=>{console.error('BLOCKED:',m);process.exit(2)};
if(!zipPath) fail('ZIP path required');
let zip; try{zip=fs.readFileSync(zipPath)}catch{fail('ZIP unreadable')}
const verify=spawnSync(process.execPath,['scripts/verify-deployment-zip.mjs',zipPath],{encoding:'utf8',timeout:60000});
if(verify.status!==0) fail('deployment ZIP verification failed');
let zipEvidence; try{zipEvidence=JSON.parse(verify.stdout)}catch{fail('deployment ZIP verifier output invalid')}
if(zipEvidence.status!=='PASS'||!['JOSHGPT-DEPLOYMENT-ZIP-2','JOSHGPT-DEPLOYMENT-ZIP-3'].includes(zipEvidence.protocol)) fail('deployment ZIP verifier did not attest PASS');
const readJson=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const pkg=readJson('package.json'), target=readJson('DEPLOYMENT_TARGET.json'), manifest=readJson('RELEASE_MANIFEST.json');
if(zipEvidence.version!==pkg.version) fail('ZIP version differs from workspace package');
if(zipEvidence.manifestFiles!==Object.keys(manifest.files||{}).length) fail('ZIP manifest inventory count differs from workspace manifest');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const report={protocol:'JOSHGPT-ARTIFACT-ATTESTATION-1',status:'PASS',version:pkg.version,archive:basename(zipPath),archiveSha256:sha(zip),archiveBytes:zip.length,target:{project:target.project,siteId:target.siteId,corporateSitePolicy:target.corporateSitePolicy},manifest:{digest:manifest.manifestDigest,fileCount:Object.keys(manifest.files||{}).length},zipVerification:zipEvidence};
report.attestationDigest=sha(Buffer.from(JSON.stringify(report)));
const out=process.argv[3]||'ARTIFACT_ATTESTATION.json';
fs.writeFileSync(out,JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
