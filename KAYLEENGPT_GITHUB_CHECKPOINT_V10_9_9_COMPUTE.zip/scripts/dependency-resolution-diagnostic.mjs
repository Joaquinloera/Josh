import { spawnSync } from 'node:child_process';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';

const pkg=JSON.parse(readFileSync('package.json','utf8'));
const expected='11.1.0';
const args=['install','--package-lock-only','--ignore-scripts','--no-audit','--no-fund','--fetch-retries=1','--fetch-timeout=20000'];
const run=spawnSync('npm',args,{encoding:'utf8',timeout:90000});
const text=`${run.stdout||''}\n${run.stderr||''}`;
let code='NPM_RESOLUTION_FAILED';
if(/EAI_AGAIN|getaddrinfo/i.test(text)) code='NPM_DNS_UNAVAILABLE';
else if(/ETIMEDOUT|timeout/i.test(text)) code='NPM_NETWORK_TIMEOUT';
else if(/ECONNREFUSED|ENETUNREACH/i.test(text)) code='NPM_NETWORK_UNREACHABLE';
else if(/E404|not found/i.test(text)) code='NPM_PACKAGE_NOT_FOUND';
const lockPresent=existsSync('package-lock.json');
let lockValid=false;
if(lockPresent){
  try{
    const lock=JSON.parse(readFileSync('package-lock.json','utf8'));
    lockValid=lock.packages?.['']?.dependencies?.['@netlify/blobs']===expected && Boolean(lock.packages?.['node_modules/@netlify/blobs']);
  }catch{}
}
const report={
 protocol:'JOSHGPT-DEPENDENCY-RESOLUTION-DIAGNOSTIC-1',
 version:pkg.version,
 dependency:{name:'@netlify/blobs',required:expected},
 attempt:{command:'npm install --package-lock-only --ignore-scripts --no-audit --no-fund',exitStatus:run.status,timedOut:Boolean(run.error?.code==='ETIMEDOUT')},
 result:lockValid?'PASS':'BLOCKED',
 blocker:lockValid?null:{code,detail:code==='NPM_DNS_UNAVAILABLE'?'Build environment DNS could not resolve registry.npmjs.org. Source code is not the cause of this dependency-resolution failure.':'npm did not produce a verifiable dependency lockfile.'},
 lockfile:{present:lockPresent,verified:lockValid}
};
report.reportDigest=createHash('sha256').update(JSON.stringify(report)).digest('hex');
writeFileSync('DEPENDENCY_RESOLUTION_STATUS.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
process.exitCode=lockValid?0:2;
