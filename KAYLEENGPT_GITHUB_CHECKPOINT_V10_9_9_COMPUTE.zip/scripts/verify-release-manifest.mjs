import { createHash } from 'node:crypto';
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { join, relative } from 'node:path';
const fail=m=>{ console.error(`BLOCKED: ${m}`); process.exitCode=2; };
const sha=p=>createHash('sha256').update(readFileSync(p)).digest('hex');
const walk=(root)=>readdirSync(root,{withFileTypes:true}).flatMap(e=>{const p=join(root,e.name);return e.isDirectory()?walk(p):[p]});
const expectedInventory=()=>[...['index.html','netlify.toml','package.json','DEPLOYMENT_TARGET.json'],...walk('netlify/functions').filter(p=>statSync(p).isFile()&&p.endsWith('.js')).map(p=>relative('.',p).replaceAll('\\','/')),...(existsSync('package-lock.json')?['package-lock.json']:[])].sort();
if(!existsSync('RELEASE_MANIFEST.json')) fail('RELEASE_MANIFEST.json is missing');
else {
 const manifest=JSON.parse(readFileSync('RELEASE_MANIFEST.json','utf8'));
 const pkg=JSON.parse(readFileSync('package.json','utf8'));
 const target=JSON.parse(readFileSync('DEPLOYMENT_TARGET.json','utf8'));
 if(manifest.protocol!=='JOSHGPT-RELEASE-MANIFEST-2') fail('release manifest protocol mismatch');
 if(manifest.version!==pkg.version) fail('release manifest version does not match package version');
 if(manifest.target?.project!==target.project||manifest.target?.siteId!==target.siteId) fail('release manifest deployment target mismatch');
 if(manifest.target?.corporateSitePolicy!=='DO_NOT_DEPLOY_OR_MODIFY') fail('corporate deployment exclusion missing from manifest');
 const expectedLock=existsSync('package-lock.json')?'PRESENT':'BLOCKED_MISSING_LOCKFILE';
 if(manifest.dependencyLock!==expectedLock) fail('dependency lock state is stale');
 const expected=expectedInventory(); const actual=Object.keys(manifest.files||{}).sort();
 if(manifest.inventory?.policy!=='ALL_NETLIFY_FUNCTION_JS_PLUS_RELEASE_ROOTS') fail('release inventory policy mismatch');
 if(manifest.inventory?.count!==expected.length) fail('release inventory count mismatch');
 if(JSON.stringify(actual)!==JSON.stringify(expected)) fail('release manifest inventory is incomplete or contains unexpected files');
 for(const file of expected) {
   if(!existsSync(file)) { fail(`manifest file missing: ${file}`); continue; }
   if(sha(file)!==manifest.files?.[file]) fail(`manifest digest mismatch: ${file}`);
 }
 const unsigned={...manifest}; delete unsigned.manifestDigest;
 const digest=createHash('sha256').update(JSON.stringify(unsigned)).digest('hex');
 if(digest!==manifest.manifestDigest) fail('release manifest self-digest mismatch');
 if(!process.exitCode) console.log(`PASS: verified complete release manifest ${manifest.manifestDigest} (${expected.length} files)`);
}
