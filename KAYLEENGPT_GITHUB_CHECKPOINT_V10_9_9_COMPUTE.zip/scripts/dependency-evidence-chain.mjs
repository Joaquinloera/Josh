import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';

const pkg=JSON.parse(readFileSync('package.json','utf8'));
const sha=v=>createHash('sha256').update(v).digest('hex');
const run=(script,timeout=60000)=>spawnSync(process.execPath,[script],{encoding:'utf8',timeout});
const parseJson=text=>{const i=(text||'').indexOf('{'); if(i<0)return null; try{return JSON.parse(text.slice(i));}catch{return null;}};
const steps=[
  ['environment','scripts/dependency-environment-readiness.mjs',30000],
  ['network','scripts/dependency-network-probe.mjs',45000],
  ['retry','scripts/dependency-retry-controller.mjs',150000],
];
const evidence={};
for(const [name,script,timeout] of steps){
  const r=run(script,timeout); const body=parseJson(r.stdout);
  evidence[name]={script,exitStatus:r.status,status:body?.status||null,reportDigest:body?.reportDigest||null,parsed:!!body};
}
const lockPresent=existsSync('package-lock.json');
const lockSha256=lockPresent?sha(readFileSync('package-lock.json')):null;
const malformed=Object.values(evidence).some(x=>!x.parsed||!x.reportDigest);
const networkReady=evidence.network.status==='DNS_READY';
const acquired=evidence.retry.status==='LOCK_ACQUIRED_VERIFIED'&&lockPresent;
let status='BLOCKED_DEPENDENCY_NETWORK'; let blocker='DEPENDENCY_REGISTRY_DNS_UNAVAILABLE';
if(malformed){status='BLOCKED_EVIDENCE_INCOMPLETE';blocker='DEPENDENCY_EVIDENCE_INCOMPLETE';}
else if(acquired){status='DEPENDENCY_LOCK_VERIFIED';blocker=null;}
else if(networkReady){status='BLOCKED_DEPENDENCY_ACQUISITION';blocker='GENUINE_LOCK_NOT_ACQUIRED';}
const report={
  protocol:'JOSHGPT-DEPENDENCY-EVIDENCE-CHAIN-1',version:pkg.version,
  requiredDependency:'@netlify/blobs@11.1.0',
  policy:{bounded:true,noRegistryMutation:true,noProxyMutation:true,noDnsMutation:true,noLockFabrication:true,sha256BoundEvidence:true},
  evidence,lockPresent,lockSha256,status,blocker
};
report.chainDigest=sha(JSON.stringify(report));
writeFileSync('DEPENDENCY_EVIDENCE_CHAIN.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
process.exitCode=status==='DEPENDENCY_LOCK_VERIFIED'?0:2;
