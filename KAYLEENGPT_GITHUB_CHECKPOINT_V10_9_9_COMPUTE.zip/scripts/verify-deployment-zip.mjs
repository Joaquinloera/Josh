import {readFileSync} from 'node:fs';
import {basename} from 'node:path';
import {inflateRawSync} from 'node:zlib';
import {createHash} from 'node:crypto';

const zipPath=process.argv[2];
const fail=m=>{console.error('BLOCKED:',m);process.exit(2)};
if(!zipPath) fail('ZIP path required');
let b; try{b=readFileSync(zipPath)}catch{fail('ZIP unreadable')}
const EOCD=0x06054b50,CEN=0x02014b50,LOC=0x04034b50;
let eocd=-1; for(let i=b.length-22;i>=Math.max(0,b.length-65557);i--){if(b.readUInt32LE(i)===EOCD){eocd=i;break}}
if(eocd<0) fail('ZIP end-of-central-directory missing');
const disk=b.readUInt16LE(eocd+4),cdDisk=b.readUInt16LE(eocd+6),diskCount=b.readUInt16LE(eocd+8),count=b.readUInt16LE(eocd+10),cdSize=b.readUInt32LE(eocd+12),cdOff=b.readUInt32LE(eocd+16);
if(disk||cdDisk||diskCount!==count) fail('multi-disk ZIP forbidden');
if(count===0xffff||cdSize===0xffffffff||cdOff===0xffffffff) fail('ZIP64 archive unsupported/fail-closed');
if(cdOff+cdSize>eocd) fail('ZIP central directory bounds invalid');
const crcTable=(()=>{const t=new Uint32Array(256);for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=(c&1)?0xedb88320^(c>>>1):c>>>1;t[n]=c>>>0}return t})();
function crc32(buf){let c=0xffffffff;for(const x of buf)c=crcTable[(c^x)&255]^(c>>>8);return (c^0xffffffff)>>>0}
const entries=new Map(); let p=cdOff;
for(let i=0;i<count;i++){
 if(p+46>b.length||b.readUInt32LE(p)!==CEN) fail('ZIP central directory entry invalid');
 const flags=b.readUInt16LE(p+8),method=b.readUInt16LE(p+10),crc=b.readUInt32LE(p+16),compSize=b.readUInt32LE(p+20),rawSize=b.readUInt32LE(p+24),nameLen=b.readUInt16LE(p+28),extraLen=b.readUInt16LE(p+30),commentLen=b.readUInt16LE(p+32),diskStart=b.readUInt16LE(p+34),extAttr=b.readUInt32LE(p+38),localOff=b.readUInt32LE(p+42);
 if([compSize,rawSize,localOff].includes(0xffffffff)||diskStart===0xffff) fail('ZIP64 entry unsupported/fail-closed');
 if(diskStart!==0) fail('multi-disk ZIP entry forbidden');
 if(flags&1) fail('encrypted ZIP entry forbidden'); if(![0,8].includes(method)) fail('unsupported ZIP compression method');
 const end=p+46+nameLen+extraLen+commentLen;if(end>b.length)fail('ZIP entry bounds invalid');
 const name=b.subarray(p+46,p+46+nameLen).toString('utf8').replaceAll('\\','/');
 if(!name||name.startsWith('/')||/^[A-Za-z]:\//.test(name)||name.split('/').includes('..'))fail(`unsafe ZIP path: ${name}`);
 if(entries.has(name))fail(`duplicate ZIP entry: ${name}`); const mode=(extAttr>>>16)&0xffff;if((mode&0xf000)===0xa000)fail(`symlink ZIP entry forbidden: ${name}`);
 entries.set(name,{name,flags,method,crc,compSize,rawSize,localOff});p=end;
}
if(p!==cdOff+cdSize)fail('ZIP central directory size mismatch');
const names=[...entries.keys()],files=names.filter(n=>!n.endsWith('/'));
for(const r of ['index.html','netlify.toml','package.json','DEPLOYMENT_TARGET.json','RELEASE_MANIFEST.json'])if(!entries.has(r))fail(`missing release-root ZIP file: ${r}`);
const forbidden=/(^|\/)(?:\.netlify|node_modules|\.git)(?:\/|$)/,secretish=/(^|\/)(?:\.env(?:\..*)?|.*\.(?:pem|key|p12|pfx)|id_rsa|id_ed25519)$/i;
for(const n of files){if(forbidden.test(n))fail(`forbidden ZIP path: ${n}`);if(secretish.test(n))fail(`secret-like ZIP file: ${n}`)}
const runtime=files.filter(n=>n.startsWith('netlify/functions/')&&n.endsWith('.js'));if(!runtime.length)fail('no Netlify runtime JavaScript in ZIP');
function bytes(name){
 const e=entries.get(name);if(!e)fail(`ZIP entry missing: ${name}`);const o=e.localOff;if(o+30>b.length||b.readUInt32LE(o)!==LOC)fail(`local ZIP header invalid: ${name}`);
 const localFlags=b.readUInt16LE(o+6),localMethod=b.readUInt16LE(o+8),nl=b.readUInt16LE(o+26),xl=b.readUInt16LE(o+28);if(o+30+nl+xl>b.length)fail(`local ZIP header bounds invalid: ${name}`);
 const localName=b.subarray(o+30,o+30+nl).toString('utf8').replaceAll('\\','/');if(localName!==name)fail(`local/central ZIP filename mismatch: ${name}`);if(localMethod!==e.method)fail(`local/central compression method mismatch: ${name}`);if(localFlags!==e.flags)fail(`local/central ZIP flags mismatch: ${name}`);if(localFlags&1)fail(`encrypted local ZIP entry forbidden: ${name}`);
 const start=o+30+nl+xl,end=start+e.compSize;if(end>b.length)fail(`ZIP payload bounds invalid: ${name}`);const packed=b.subarray(start,end);let raw;try{raw=e.method===0?packed:inflateRawSync(packed)}catch{fail(`ZIP decompression failed: ${name}`)}
 if(raw.length!==e.rawSize)fail(`ZIP uncompressed size mismatch: ${name}`);if(crc32(raw)!==e.crc)fail(`ZIP CRC32 mismatch: ${name}`);return raw;
}
let manifest;try{manifest=JSON.parse(bytes('RELEASE_MANIFEST.json').toString('utf8'))}catch{fail('release manifest in ZIP is invalid JSON')}
if(manifest.protocol!=='JOSHGPT-RELEASE-MANIFEST-2')fail('release manifest protocol mismatch');if(!manifest.files||typeof manifest.files!=='object')fail('release manifest file inventory missing');
const listed=Object.keys(manifest.files).sort();for(const name of listed){if(!entries.has(name))fail(`manifest-listed ZIP file missing: ${name}`);const actual=createHash('sha256').update(bytes(name)).digest('hex');if(actual!==manifest.files[name])fail(`manifest digest mismatch inside ZIP: ${name}`)}
const expectedRuntime=runtime.sort(),listedRuntime=listed.filter(n=>n.startsWith('netlify/functions/')&&n.endsWith('.js')).sort();if(JSON.stringify(expectedRuntime)!==JSON.stringify(listedRuntime))fail('ZIP runtime inventory differs from release manifest');
const pkg=JSON.parse(bytes('package.json').toString('utf8'));if(manifest.version!==pkg.version)fail('ZIP package version differs from release manifest');const target=JSON.parse(bytes('DEPLOYMENT_TARGET.json').toString('utf8'));if(manifest.target?.siteId!==target.siteId||manifest.target?.project!==target.project)fail('ZIP deployment target differs from release manifest');
console.log(JSON.stringify({protocol:'JOSHGPT-DEPLOYMENT-ZIP-3',status:'PASS',archive:basename(zipPath),entries:names.length,files:files.length,runtimeFiles:runtime.length,manifestFiles:listed.length,version:pkg.version,crc32Verified:true,localHeaderConsistency:true,zip64Policy:'FAIL_CLOSED'},null,2));
