import { existsSync, readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const pkg=JSON.parse(readFileSync('package.json','utf8'));
const target=JSON.parse(readFileSync('DEPLOYMENT_TARGET.json','utf8'));
const lockPresent=existsSync('package-lock.json');
let lockValid=false, lockReason='package-lock.json is missing';
if(lockPresent){
  try{
    const lock=JSON.parse(readFileSync('package-lock.json','utf8'));
    const rootPin=lock.packages?.['']?.dependencies?.['@netlify/blobs'];
    const resolved=lock.packages?.['node_modules/@netlify/blobs'];
    lockValid=rootPin==='11.1.0'&&Boolean(resolved);
    lockReason=lockValid?'verified @netlify/blobs 11.1.0 lock':'lockfile does not prove @netlify/blobs 11.1.0';
  }catch{ lockReason='package-lock.json is malformed'; }
}
const manifest=existsSync('RELEASE_MANIFEST.json')?JSON.parse(readFileSync('RELEASE_MANIFEST.json','utf8')):null;
const status={
 protocol:'JOSHGPT-RELEASE-STATUS-1', version:pkg.version,
 target:{project:target.project,siteId:target.siteId,corporateSitePolicy:target.corporateSitePolicy},
 gates:{sourcePreflight:'PASS',manifestPresent:Boolean(manifest),dependencyLock:lockValid?'PASS':'BLOCKED'},
 blocker:lockValid?null:{code:'DEPENDENCY_LOCK_UNAVAILABLE',detail:lockReason,requiredAction:'Obtain a genuine npm package-lock.json resolving pinned @netlify/blobs 11.1.0; do not fabricate dependency metadata.'}
};
status.statusDigest=createHash('sha256').update(JSON.stringify(status)).digest('hex');
console.log(JSON.stringify(status,null,2));
if(!lockValid) process.exitCode=2;
