import { createHash } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { verifyDependencyLock } from './verify-dependency-lock.mjs';

const sha = value => createHash('sha256').update(value).digest('hex');
const readJson = path => { try { return JSON.parse(readFileSync(path, 'utf8')); } catch { return null; } };
const pkg = readJson('package.json');
const target = readJson('DEPLOYMENT_TARGET.json');
const manifest = readJson('RELEASE_MANIFEST.json');
const decision = readJson('DEPENDENCY_RELEASE_DECISION.json');
const integrity = readJson('RELEASE_DECISION_INTEGRITY.json');
const chain = readJson('DEPENDENCY_EVIDENCE_CHAIN.json');
const lockPresent = existsSync('package-lock.json');
const lockSha256 = lockPresent ? sha(readFileSync('package-lock.json')) : null;
const lockIntegrity = lockPresent ? verifyDependencyLock(process.cwd()) : { ok:false, errors:['package-lock.json missing'] };
const expectedTarget = { project:'joshgpt13', siteId:'322db469-6833-4187-b023-60638716b3c7', corporateSitePolicy:'DO_NOT_DEPLOY_OR_MODIFY' };

const checks = {
  packageVersion: /^10\.(?:8|9)\.\d+$/.test(pkg?.version ?? ''),
  deploymentTarget: target?.project === expectedTarget.project && target?.siteId === expectedTarget.siteId && target?.corporateSitePolicy === expectedTarget.corporateSitePolicy,
  manifestCurrent: manifest?.protocol === 'JOSHGPT-RELEASE-MANIFEST-2' && manifest?.version === pkg?.version && manifest?.target?.project === expectedTarget.project && manifest?.target?.siteId === expectedTarget.siteId && manifest?.target?.corporateSitePolicy === expectedTarget.corporateSitePolicy,
  genuineLockPresent: lockPresent,
  dependencyLockIntegrity: lockIntegrity.ok === true,
  evidenceChainCurrent: chain?.protocol === 'JOSHGPT-DEPENDENCY-EVIDENCE-CHAIN-1' && chain?.version === pkg?.version && chain?.status === 'DEPENDENCY_LOCK_VERIFIED' && chain?.lockPresent === true && chain?.lockSha256 === lockSha256,
  dependencyDecisionReady: decision?.protocol === 'JOSHGPT-DEPENDENCY-RELEASE-DECISION-1' && decision?.version === pkg?.version && decision?.status === 'DEPENDENCY_RELEASE_GATE_READY' && decision?.lockBound === true && decision?.lockSha256 === lockSha256,
  decisionIntegrityReady: integrity?.protocol === 'JOSHGPT-RELEASE-DECISION-INTEGRITY-1' && integrity?.version === pkg?.version && integrity?.status === 'RELEASE_DECISION_INTEGRITY_READY' && integrity?.bound === true && integrity?.lockSha256 === lockSha256,
  manifestBindsLock: lockPresent && manifest?.dependencyLock === 'PRESENT' && manifest?.files?.['package-lock.json'] === lockSha256,
};
const blockers = Object.entries(checks).filter(([,ok]) => !ok).map(([name]) => name);
const status = blockers.length === 0 ? 'FINAL_RELEASE_AUTHORIZED' : 'FINAL_RELEASE_BLOCKED';
const report = {
  protocol:'JOSHGPT-FINAL-RELEASE-AUTHORIZATION-1', version:pkg?.version ?? null, target:expectedTarget,
  policy:{failClosed:true,noLockFabrication:true,requiresGenuineDependencyLock:true,requiresCurrentManifestBinding:true,requiresDecisionIntegrity:true,corporateSiteExcluded:true},
  lockPresent, lockSha256, checks, blockers, status
};
report.authorizationDigest = sha(JSON.stringify(report));
writeFileSync('FINAL_RELEASE_AUTHORIZATION.json', JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
process.exitCode = status === 'FINAL_RELEASE_AUTHORIZED' ? 0 : 2;
