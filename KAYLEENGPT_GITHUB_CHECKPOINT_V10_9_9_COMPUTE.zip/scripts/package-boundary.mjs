import {readdirSync,readFileSync,existsSync} from 'node:fs';
import {join,relative,sep} from 'node:path';
const root=process.cwd();
const fail=m=>{console.error('BLOCKED:',m);process.exit(2)};
const target=JSON.parse(readFileSync('DEPLOYMENT_TARGET.json','utf8'));
const required=['index.html','netlify.toml','package.json','DEPLOYMENT_TARGET.json','RELEASE_MANIFEST.json'];
for(const p of required) if(!existsSync(p)) fail(`missing release-root file: ${p}`);
if(target.project!=='joshgpt13'||target.siteId!=='322db469-6833-4187-b023-60638716b3c7') fail('deployment target mismatch');
if(target.corporateSitePolicy!=='DO_NOT_DEPLOY_OR_MODIFY') fail('corporate exclusion policy missing');
const forbiddenDirs=new Set(['.netlify','node_modules','.git']);
const secretish=/(^|\/)(\.env(?:\..*)?|.*\.(pem|key|p12|pfx)|id_rsa|id_ed25519)$/i;
const files=[];
function walk(dir){for(const e of readdirSync(dir,{withFileTypes:true})){if(forbiddenDirs.has(e.name)) fail(`forbidden package directory: ${e.name}`);const full=join(dir,e.name), rel=relative(root,full).split(sep).join('/');if(e.isDirectory()) walk(full); else {if(secretish.test(rel)) fail(`secret-like file forbidden: ${rel}`);files.push(rel);}}}
walk(root);
if(files.some(p=>p.startsWith('jg91/')||/^jg\d+\//.test(p))) fail('nested checkpoint root detected');
const runtime=files.filter(p=>p.startsWith('netlify/functions/')&&p.endsWith('.js'));
if(!runtime.length) fail('no Netlify runtime JavaScript found');
console.log(JSON.stringify({protocol:'JOSHGPT-PACKAGE-BOUNDARY-1',status:'PASS',target:target.project,runtimeFiles:runtime.length,totalFiles:files.length,forbiddenDirectories:[...forbiddenDirs],secretLikeFiles:'DENIED'},null,2));
