# JoshGPT Native Portal V3.0 — Epistemic Retrieval & Reasoning Context

- Adds CKG-4 retrieval policy over the persistent CKG-3 epistemic ledger.
- KNOWN claims are eligible for prioritized reasoning context.
- DISPUTED claims are routed to a verification queue and are not injected as factual context.
- REJECTED hypotheses are explicitly excluded from factual context.
- SUPERSEDED claims are retained for lineage but deprioritized; successor links remain visible.
- Retrieval output is SHA-256 bound and verified before Native execution.
- CKG-4 context is injected into the existing Bio × Quantum reasoning pipeline without external AI providers.
