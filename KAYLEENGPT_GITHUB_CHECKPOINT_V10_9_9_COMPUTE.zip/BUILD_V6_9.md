# JoshGPT Native Portal V6.9 — NSF-37 Learning-Bound Durable Learning Continuity

Persists the exact NSF-36 learned-route lineage into the NSF-27 durable learning commit and verifies it again against the NSF-29 durable learning-state attestation. NSF-37 binds the durable learning ledger entry, ledger head/sequence, pathway/receipt, source learning-ledger head/sequence, and source learning-lineage digest. Learned-route learning fails closed when durable lineage is incomplete or altered. This is an engineering checkpoint, not a normalized deployment package.
