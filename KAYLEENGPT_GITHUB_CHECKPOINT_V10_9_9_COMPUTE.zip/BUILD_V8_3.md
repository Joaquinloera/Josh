# JoshGPT Native Portal V8.3 — Authentication Abuse Boundary

V8.3 adds a bounded, account-and-client keyed authentication throttle for password login, signup, passkey option discovery, and passkey login. Throttle identifiers are SHA-256 digests; responses are 429 with Retry-After; successful authentication clears the corresponding attempt state.

The throttle uses the existing production/global vs preview/deploy-scoped Netlify Blobs boundary and strong consistency. Netlify Blobs is last-write-wins and does not provide transactional concurrency control, so this is a bounded abuse-control layer, not a claim of atomic distributed rate limiting.

Architecture remains frozen at V7.0 / NSF-38. OpenAI and Gemini are not runtime providers. This remains a checkpoint until reproducible dependency resolution and production runtime smoke validation are complete.
