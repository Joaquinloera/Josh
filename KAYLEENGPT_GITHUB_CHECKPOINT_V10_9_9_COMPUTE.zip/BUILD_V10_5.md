# JoshGPT Native Portal V10.5 — Dependency Evidence Chain

V10.5 binds the dependency environment, network probe, and bounded retry-controller reports into one SHA-256 evidence chain. The chain fails closed on malformed/missing evidence, distinguishes DNS blocking from acquisition blocking, and records the exact genuine package-lock SHA-256 only when a lock exists. It never mutates DNS, proxy, or registry settings and never fabricates dependency metadata.

Deployment target remains JoshGPT project `joshgpt13` / site `322db469-6833-4187-b023-60638716b3c7`. Corporate site policy remains `DO_NOT_DEPLOY_OR_MODIFY`.
