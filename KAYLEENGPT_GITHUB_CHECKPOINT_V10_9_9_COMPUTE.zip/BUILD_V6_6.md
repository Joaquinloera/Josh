# JoshGPT Native Portal V6.6 — NSF-34 Learning-Bound Durable Execution Continuity

V6.6 carries the verified NSF-30 learning lineage from NSF-31 admission through NSF-20 sealing and NSF-21 fulfillment into the durable NSF-22 execution commit and NSF-24 attestation. Learned execution history now persists the exact learning-lineage digest, learning-ledger head, and learning-ledger sequence that authorized the execution. Mismatched lineage fails closed. Legacy NSF-19 execution remains compatible.
