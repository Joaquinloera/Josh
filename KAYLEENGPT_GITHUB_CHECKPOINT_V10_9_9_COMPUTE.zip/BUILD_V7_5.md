# JoshGPT Native Portal V7.5 — Deployment Hardening V

Architecture remains frozen at V7.0 / NSF-38.

V7.5 adds a fail-closed reproducible-dependency release gate. A production upload is not authorized unless package-lock.json exists, pins @netlify/blobs 11.1.0 at the root, and contains its resolved package record. This prevents a checkpoint from being mislabeled deployment-ready when Netlify dependency resolution has not been cryptographically/reproducibly captured.

In this build environment npm registry resolution was unavailable/timed out, so the lockfile could not be generated here. The release gate therefore correctly reports BLOCKED. This is an explicit production blocker, not a simulated pass.
