# JoshGPT Native Portal V3.2 — Adjudication Closure

CKG-6 closes the evidence-adjudication loop. CKG-5 outcomes now produce SHA-256-bound resolution records with complete finding/adjudication lineage. PROMOTE becomes active KNOWN context immediately; REJECT becomes excluded REJECTED knowledge; HOLD_DISPUTED remains verification-only. Retrieval resolves each claim by its newest ledger sequence so prior disputed versions remain auditable without remaining active. Resolved ledgers persist before downstream reasoning and future conversations consume the updated epistemic state.

No external AI provider is introduced. CAP-1 remains the internal agent signaling protocol.
