# JoshGPT Native Portal V8.7 — Release Blocker Diagnostics

V8.7 keeps the release boundary fail closed while making the remaining blocker machine-readable and unambiguous.

- Adds `scripts/release-status.mjs` and `npm run release:status`.
- Reports the exact deployment target and corporate-site exclusion.
- Distinguishes source/manifest readiness from the unresolved dependency-lock gate.
- Verifies any future `package-lock.json` actually pins and resolves `@netlify/blobs` 11.1.0.
- Never fabricates npm resolution metadata when registry access is unavailable.
- This is a checkpoint, not a deploy-ready artifact.
