# JoshGPT Native Portal V9.5 — Dependency Lock Integrity Gate

V9.5 hardens the final dependency boundary without fabricating a lockfile. A genuine `package-lock.json`, when npm resolution becomes available, must now pass a dedicated fail-closed verifier before it can be trusted: lockfile v3+, exact root pin to `@netlify/blobs` 11.1.0, exact resolved package version, HTTPS npm-registry provenance, SHA-512 integrity for registry artifacts, and rejection of local/non-HTTPS source substitution.

The current build environment still cannot resolve `registry.npmjs.org` (`EAI_AGAIN`), so no lockfile was generated or invented. This checkpoint therefore remains not deploy-ready. The verifier is preparation for safely accepting the real npm-generated lock once network resolution succeeds.
