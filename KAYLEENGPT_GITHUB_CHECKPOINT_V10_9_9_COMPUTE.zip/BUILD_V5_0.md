# JoshGPT Native Portal V5.0 — NSF-18 Pathway Inventory Attestation

NSF-18 extends the V4.9 pathway-state check from ledger-known pathways to the complete persisted pathway inventory.

- Every persisted adaptive pathway must carry an accountability digest proven by the retained ledger or archived NSF-16 replay shield.
- Every pathway represented by retained accountability history must exist in persisted pathway state.
- Retained latest strength/quarantine state must match the ledger.
- Extra, missing, drifted, or unproven pathways fail closed before learned routing.
- The complete pathway inventory is canonicalized and SHA-256 bound.
- CAP-1 uses WITNESS for a verified inventory and GUARD for integrity failure.

This remains conventional deterministic software. It does not claim trained foundation-model weights, biological hardware, or physical quantum hardware.
