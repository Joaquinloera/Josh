# JoshGPT Native Portal V6.5 — NSF-33 Learning-Bound Execution Fulfillment Continuity

V6.5 carries the verified NSF-30 durable-learning lineage from the NSF-31 route admission, through the NSF-20 execution seal, into NSF-21 execution fulfillment. A learned execution fulfillment now binds the exact learning-lineage digest, learning-ledger head, and learning-ledger sequence that authorized the route. Missing lineage on an NSF-31-backed execution fails closed. Legacy NSF-19 fulfillment remains compatible.
