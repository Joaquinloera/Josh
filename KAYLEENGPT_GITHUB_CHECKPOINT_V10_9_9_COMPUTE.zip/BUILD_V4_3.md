# JoshGPT Native Portal V4.3 — NSF-11 Semantic Route Stability

NSF-11 adds a bounded stability layer between semantic trust scoring and learned route execution.

- Cold-start histories may use learned exploitation but cannot explore unproven alternate routes.
- Mature trust below 0.50 quarantines adaptive routing to the deterministic base route.
- Trust from 0.50 to below 0.70 is guarded: exploitation may continue, but exploratory selections are suppressed to base.
- Trust at or above 0.70 permits the bounded BQR-1 exploration policy.
- Explicit host/agent requests remain authoritative and are never silently replaced by adaptive policy.
- Every stability decision binds the NSF-10 trust digest, score, source routing decision, candidate digest, selected route, and CAP-1 signal with SHA-256.
- This is deterministic software policy and does not claim trained foundation-model weights, biological hardware, or physical quantum hardware.
