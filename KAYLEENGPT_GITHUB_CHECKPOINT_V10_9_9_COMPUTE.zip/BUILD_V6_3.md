# JoshGPT Native Portal V6.3 — NSF-31 Learning-Bound Route Admission

NSF-31 binds the existing NSF-19 route admission to the NSF-30 verified durable-learning eligibility proof before execution can be sealed. A learned route must now be both operationally attested and backed by the exact live learning-ledger lineage used to make it eligible. Base and explicit routes preserve their prior behavior. The admission is SHA-256 bound and emits CAP-1 WITNESS/GUARD state.
