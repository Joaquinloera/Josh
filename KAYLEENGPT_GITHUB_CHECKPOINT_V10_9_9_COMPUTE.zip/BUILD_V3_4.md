# JoshGPT Native Portal V3.4 — Semantic Continuity

V3.4 adds NSF-2, a deterministic semantic continuity layer above NSF-1.

- Resolves bounded references to recent user turns without persisting raw prior text in the semantic state.
- Distinguishes ASK, DIRECT, STATE, CONTINUE, and CORRECT dialogue acts.
- Carries forward bounded concepts/entities for continuation and reference requests.
- Emits CAP-1 continuity signals including ANCESTOR, WITNESS, and VERIFY.
- SHA-256 binds the NSF-2 state to the verified NSF-1 frame.
- Keeps OpenAI/Gemini absent from active runtime dependencies.
