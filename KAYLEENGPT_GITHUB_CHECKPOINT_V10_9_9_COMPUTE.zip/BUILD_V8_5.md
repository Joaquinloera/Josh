# JoshGPT Native Portal V8.5 — Release Manifest Verification Gate

V8.5 turns the release manifest from a generated record into a fail-closed verified boundary.

- Verifies manifest protocol and package-version continuity.
- Verifies the exact JoshGPT deployment target and corporate-site exclusion.
- Derives dependency-lock state from the actual artifact; no lock evidence is fabricated.
- Re-hashes every critical file named by the manifest and rejects drift.
- Recomputes and verifies the manifest self-digest without self-referential hashing.
- Integrates verification into deployment preflight.
- The release remains BLOCKED until a genuine package-lock.json resolves pinned @netlify/blobs 11.1.0.
- No live deployment is performed by this checkpoint.
