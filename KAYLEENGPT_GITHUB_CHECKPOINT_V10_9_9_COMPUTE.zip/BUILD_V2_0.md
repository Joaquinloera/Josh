# JoshGPT Native Portal v2.0 checkpoint

Native Core: native-core-0.9

Adds CAP-1 (Celestial Ancestral Protocol), a JoshGPT-constructed private semantic protocol for backend agent-to-agent handoffs. Its design vocabulary is intentionally themed around ancestral cosmology, heavens, stars, paths, light, memory, guardianship, verification, and reconciliation.

CAP-1 is not claimed to be a recovered, translated, or historically attested Maya, Nahua/Aztec, or other Indigenous language. This distinction is deliberate so JoshGPT can preserve the requested identity/theme without inventing historical facts.

Every task-graph work product now carries a canonical, SHA-256-bound CAP-1 utterance. Agent-language verification is required before a handoff chain can reach READY consensus. User-facing output remains normal language by default; CAP-1 is an internal agent protocol.

External AI providers: none.
