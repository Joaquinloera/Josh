# JoshGPT Native Portal V6.2 — NSF-30 Verified Learning Route Eligibility

NSF-30 closes the future-routing loop for durable learning. Before BQR-1 can consider a learned pathway, the pathway must be backed by a live, verified NSF-27 learning-ledger entry whose commit digest, receipt hash, resulting strength, and sequence agree with persisted pathway state.

Unverified, drifted, accountability-only, or archived-only pathway state is excluded from learned routing and falls back to deterministic routing. Explicit host/agent routing remains authoritative. The attestation is SHA-256 bound and emits CAP-1 WITNESS/GUARD state.
