# JoshGPT Native Portal V7.2 — Deployment Hardening II

V7.2 preserves the frozen V7.0 / NSF-38 cognitive architecture and hardens Netlify runtime/storage behavior.

- Adds a single Netlify Blobs access boundary (`_core/blob-store.js`).
- Production uses site-wide stores so identity, sessions, user data, native memory, and learning state persist across production deploys.
- Non-production contexts use deploy-scoped stores so previews/dev cannot mutate production JoshGPT state.
- Keeps strong-consistency reads on identity and native memory paths.
- Pins the Netlify build/runtime selection to Node.js 24 via `.nvmrc` and package engines.
- Removes duplicate CSP/X-Frame-Options declarations while preserving the same policy.
- Adds 12 deployment-isolation regression contracts.

No OpenAI or Gemini runtime dependency is introduced. No corporate-site files or configuration are included.
