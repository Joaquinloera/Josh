# JoshGPT Native Portal V2.9 — Persistent Epistemic Ledger

V2.9 adds CKG-3, a persistent epistemic knowledge lifecycle layered on CKG-1/CKG-2.

- Persistent account-scoped established-claim ledger.
- Rejected hypotheses remain in a separate archive.
- Contradiction history is retained.
- Knowledge states: KNOWN, CANDIDATE, DISPUTED, REJECTED, SUPERSEDED.
- Monotonic epistemic sequence and SHA-256-bound entries.
- CAP-1 state signals: KNOW, SEEK, VERIFY, SHADOW, ANCESTOR.
- Bounded ledger persistence through the existing JoshGPT Native memory store.
- No external AI provider dependency added.
