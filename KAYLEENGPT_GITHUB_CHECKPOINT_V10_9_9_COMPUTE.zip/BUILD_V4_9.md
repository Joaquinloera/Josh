# JoshGPT Native Portal V4.9 — NSF-17 Pathway State Attestation

Adds a fail-closed, SHA-256-bound attestation between the persistent adaptive pathway state and the latest retained NSF-15 accountability commits before learned routing is considered. Strength/quarantine drift, missing pathway records, ledger-head mismatch, or attestation tampering prevents adaptive routing from proceeding. CAP-1 WITNESS marks verified state; GUARD marks drift.

This remains a source checkpoint, not the normalized Netlify deployment artifact.
