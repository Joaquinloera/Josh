# JoshGPT Native Portal V2.5 — Cognitive Persistence & Recovery

Adds BCC-1 cognitive checkpointing: hash-bound resumable cognitive state, single-use 32-byte replay nonces, parent-linked execution lineage, deterministic last-verified recovery, bounded persistent checkpoint history, and fail-closed verification. This is additive to BCS-1 scheduling, BQR-1 routing, BQL-1 learning, BQCA-1, CAP-1, Native memory/tools/identity. No claim of biological or quantum hardware is made.
