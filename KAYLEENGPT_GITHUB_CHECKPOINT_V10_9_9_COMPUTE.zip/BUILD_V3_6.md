# JoshGPT Native Portal V3.6 — NSF-4 Semantic Execution Contract

NSF-4 binds the verified semantic plan to the selected route and cognitive schedule before execution, then settles required semantic subgoals against verified task-graph work products and Native evaluation. Contracts and settlements are SHA-256 bound and CAP-1 signals PATH/WITNESS/VERIFY expose execution state without relying on external AI providers.
