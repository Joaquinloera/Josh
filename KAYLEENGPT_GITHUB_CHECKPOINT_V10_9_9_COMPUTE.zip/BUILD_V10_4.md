# JoshGPT Native Portal V10.4

Dependency Retry Controller checkpoint.

Adds a fail-closed controller that probes npm-registry DNS before attempting genuine lock acquisition. It performs at most one acquisition attempt per invocation, never changes registry/proxy/DNS configuration, never fabricates a lock, and writes a SHA-256-bound status receipt. When DNS is unavailable, npm acquisition is skipped instead of repeatedly waiting on a known network blocker.
