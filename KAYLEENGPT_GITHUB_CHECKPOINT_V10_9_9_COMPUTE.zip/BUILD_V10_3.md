# JoshGPT Native Portal V10.3

Dependency Network Probe hardening. Adds bounded three-attempt DNS diagnostics across the system resolver, IPv4 DNS, and IPv6 DNS; classifies transient resolver failures separately; records a SHA-256-bound report; and explicitly forbids proxy/DNS mutation or dependency-lock fabrication. This checkpoint does not deploy or modify either live site.
