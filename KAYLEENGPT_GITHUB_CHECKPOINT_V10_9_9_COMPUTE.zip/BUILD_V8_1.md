# JoshGPT Native Portal V8.1 — Latest Function Routing

V8.1 aligns all six Netlify serverless entry points with Netlify's current Request/default-export function format and adds in-code `config.path` API routing. Legacy redirects remain during this checkpoint as a compatibility bridge; `/api/tools` is now included there as well.

This is a checkpoint, not the final upload artifact. The reproducible dependency release gate remains required.
