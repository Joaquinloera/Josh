# JoshGPT Native Portal v1.2 checkpoint

- Advances active package/runtime to 1.2.0 and Native Core to native-core-0.2.
- Adds provider-independent intent classification for software, security, research, writing, planning, and general tasks.
- Adds deterministic native response synthesis, recent-turn continuity accounting, host-aware output, and explicit capability truthfulness.
- Keeps trained foundation-model inference marked not installed; no external AI provider is substituted.
- Preserves v1.1 identity, server sessions, passkey verification, persistent profiles, and conversation storage.
- Adds v1.2 Native Engine contract tests.
