# JoshGPT Native Portal V3.5 — Semantic Planning (NSF-3)

Additive checkpoint over V3.4. NSF-3 converts verified semantic continuity into an explicit bounded goal plan before agent execution: goal, ordered subgoals, dependencies, constraints, success conditions, and CAP-1 execution intent. Plans are SHA-256 bound to the NSF-2 semantic-context digest and fail verification if altered.

Capability boundary remains unchanged: deterministic JoshGPT-native software; no claim of installed JoshGPT foundation-model weights, biological hardware, or physical quantum hardware.
