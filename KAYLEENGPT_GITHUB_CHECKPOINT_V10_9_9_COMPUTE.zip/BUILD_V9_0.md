# JoshGPT Native Portal V9.0 — Dynamic Passkey Registration Verification

V9.0 extracts the pure WebAuthn registration verifier from account/blob persistence so it can be executed directly without Netlify Blobs. The dynamic contract constructs real P-256 credential material and CBOR attestation data, verifies a valid registration, and fails closed for RP, client-data, flag, credential, COSE algorithm/key-length, and browser-key substitution errors.

This checkpoint does not alter the deployment target and does not deploy either JoshGPT or the corporate site. The reproducible npm dependency lock remains a separate release gate.
