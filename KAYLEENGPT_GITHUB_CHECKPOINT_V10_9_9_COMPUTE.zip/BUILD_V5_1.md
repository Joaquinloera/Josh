# JoshGPT Native Portal V5.1 — NSF-19 Pathway Route Admission

NSF-19 creates a fail-closed admission boundary between persisted adaptive pathway state and learned route execution. A learned route is admitted only when NSF-17 pathway-state attestation, NSF-18 complete-inventory attestation, and the semantic route-confidence decision are bound into one SHA-256-verifiable admission record. Explicit routes remain authoritative; base routes do not depend on learned-state admission. CAP-1 emits WITNESS on admission and GUARD on denial.
