# JoshGPT13 V10.9.2 — Semantic Ledger Persistence Repair

- Preserves V10.9.1 authentication gate/session fix.
- Fixes production chat failure: `Invalid semantic ledger for trust profile`.
- Root cause: persistent memory default/write path serialized semantic state as legacy `NSF-7`, while runtime trust validation requires `NSF-8`.
- New accounts now initialize NSF-8 with `anchor:null`.
- Empty legacy NSF-7 account state migrates to NSF-8 on read.
- NSF-8 anchor and entries persist correctly on write.
- Non-compatible legacy semantic state is not assigned fabricated cryptographic digests.
- Added `tests/v110-semantic-memory-migration-contract.mjs`.
