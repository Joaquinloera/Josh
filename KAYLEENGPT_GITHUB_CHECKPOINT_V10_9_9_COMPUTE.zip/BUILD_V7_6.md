# JoshGPT Native Portal V7.6 — Deployment Hardening VI

Architecture remains frozen at V7.0 / NSF-38.

V7.6 closes a release-gate version-skew defect discovered during hardening: the V7.5 package version had advanced while deployment-preflight.mjs still required V7.4.0. That stale assertion would make the static preflight fail on the current package even when all other production checks were valid.

The package, deployment preflight, and dependency release gate are now aligned on V7.6.0. A dedicated 12-contract regression test prevents silent version skew while preserving the @netlify/blobs 11.1.0 pin, lockfile/resolution requirements, provider-independence scan, exact JoshGPT site target, and corporate-site exclusion.

The dependency release gate remains intentionally fail-closed until a genuine npm-generated package-lock.json can be produced and verified. No lockfile is fabricated in this checkpoint.
