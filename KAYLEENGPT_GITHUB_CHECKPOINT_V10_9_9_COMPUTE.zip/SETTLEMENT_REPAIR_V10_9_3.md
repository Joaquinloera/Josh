
# V10.9.3 settlement repair
- Fixed semantic settlement verifier to validate proof only on required bindings.
- Added required-binding marker to settlement results.
- Added regression coverage for optional null proofs.
