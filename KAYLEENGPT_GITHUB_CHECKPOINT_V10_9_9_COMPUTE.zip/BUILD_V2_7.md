# JoshGPT Native Portal V2.7 — Structured Knowledge Graph

Adds CKG-1: deterministic concepts, semantic relationships, evidence-bound claims, source provenance, CAP-1 representations, evidence-weighted retrieval, and a SHA-256-bound context assembly layer feeding the Native runtime. This is additive to V2.6 cognitive integrity. It does not claim trained foundation-model weights or external AI inference.
