# JoshGPT Native Portal v1.9

Adds bounded iterative Native reasoning: candidate branching, evidence-driven confidence scoring, failed-hypothesis elimination, explicit convergence, and hard cycle/branch execution budgets. No external AI provider is required. JoshGPT foundation-model weights remain not installed at this checkpoint.
