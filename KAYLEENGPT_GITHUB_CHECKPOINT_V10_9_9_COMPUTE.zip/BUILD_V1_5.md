# JoshGPT Native Portal v1.5

Adds a JoshGPT-owned capability registry, authenticated deterministic tool execution, permission gates, and a persistent account-scoped agent work queue.

Native capabilities at this checkpoint: text metrics, JSON validation, SHA-256 hashing, and bounded checklist construction. All are server-side, deterministic, side-effect free, and require an authenticated JoshGPT session. Unknown or side-effect capabilities fail closed. No arbitrary shell/process execution is exposed.

Native Core: native-core-0.5. Portal/runtime package: 1.5.0.
