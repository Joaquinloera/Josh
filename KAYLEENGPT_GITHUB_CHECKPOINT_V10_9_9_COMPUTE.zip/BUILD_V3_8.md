# JoshGPT Native Portal V3.8 — NSF-6 Semantic Feedback Gate

NSF-6 closes the verified semantic outcome into adaptive learning. A BQL-1 pathway may be positively reinforced only when its bound NSF-5 outcome is ACCEPTED. Blocked semantic outcomes remain observable but cannot be treated as verified learning experiences. The feedback receipt binds the outcome digest, BQL-1 receipt hash, plan/settlement/output/knowledge digests, sequence and CAP-1 signal with SHA-256.

CAP-1 feedback signals: ANCESTOR for verified reinforcement, WITNESS for accepted observation without verified learning, VERIFY for blocked/no-reinforcement outcomes.

This remains deterministic software running on conventional hardware. It does not claim trained foundation-model weights, biological hardware, or physical quantum hardware.
