# JoshGPT Native Portal V4.5 — NSF-13 Semantic Route Accountability

NSF-13 binds each governed route decision to its eventual verified semantic outcome and feedback decision. Learned, explicit, and fallback routes receive distinct outcome verdicts. The accountability record binds NSF-12 confidence, NSF-5 outcome, NSF-6 feedback, the routing receipt, selected host/agent, confidence margin, and CAP-1 signal under SHA-256.

This is deterministic software accountability on conventional hardware. It does not claim trained foundation-model weights, biological hardware, or physical quantum hardware.
