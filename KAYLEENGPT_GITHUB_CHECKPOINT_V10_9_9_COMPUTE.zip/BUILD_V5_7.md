# JoshGPT Native Portal V5.7 — NSF-25 Durable Learning Admission

NSF-25 inserts a fail-closed admission boundary between durable execution verification and adaptive learning. A learning receipt may be recorded only when the exact NSF-24 durable execution attestation verifies and the bound NSF-5 semantic outcome is ACCEPTED. The admission binds execution ledger head/sequence, execution entry, semantic outcome, output digest, sequence, and CAP-1 state under SHA-256.

This remains deterministic software architecture. It does not claim trained JoshGPT foundation-model weights, biological hardware, or physical quantum hardware.
