# JoshGPT Native Portal V8.9 — Passkey Browser Compatibility

V8.9 removes a browser-specific enrollment blocker while keeping the server authoritative.

- `PublicKeyCredential.response.getPublicKey()` is now optional on the client.
- The browser always sends the WebAuthn `attestationObject`, credential ID, and client data required for server verification.
- When a browser exposes `getPublicKey()`, the SPKI value is sent only as an additional consistency check.
- The server continues to derive the authoritative ES256 public key from the attested credential data and rejects a supplied browser key if it does not match.
- Existing RP ID, origin, challenge, UP/UV, credential-ID, and signature-counter protections remain unchanged.
- This remains a checkpoint while the genuine npm dependency lock is unavailable.
