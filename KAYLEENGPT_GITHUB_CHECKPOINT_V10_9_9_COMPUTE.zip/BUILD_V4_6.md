# JoshGPT Native Portal V4.6 — NSF-14 Pathway Accountability

Closes the adaptive routing feedback loop. Verified NSF-13 LEARNED_PROVEN outcomes earn bounded pathway confidence; LEARNED_FAILED outcomes lose confidence. Two accumulated verified failures quarantine a learned pathway. Recovery requires two subsequent verified successes. Every adjustment is SHA-256 bound to the NSF-13 accountability record and persisted account-scoped with bounded history. CAP-1 emits WITNESS, VERIFY, GUARD, or ANCESTOR according to the transition.

This remains deterministic software on conventional hardware. No foundation-model weights, biological hardware, or physical quantum hardware are claimed or installed.
