# JoshGPT Native Portal V9.4 — Netlify Node 24 Runtime Attestation

V9.4 closes the previously unverified Node runtime pin. Netlify's current official documentation states that the current build image defaults to Node 24, `.nvmrc` can select Node 24, and Functions use the build Node runtime when valid with Node 24 as the current fallback. JoshGPT now binds its release metadata to Node 24 through `.nvmrc`, `package.json` engines, and a fail-closed runtime requirements verifier.

The verifier also enforces the project's Netlify-specific environment-access rule: active Function runtime JavaScript must not use `process.env`; environment reads remain through the Netlify global environment API.

This does not claim that the local checkpoint runner is Node 24. The verifier records the local Node version separately and treats the release target declaration independently.

The dependency lockfile gate remains mandatory and is not bypassed by this checkpoint.
