# JoshGPT Native Portal v1.1 checkpoint

Additive build from v1.0.0.

## Added
- Authenticated, account-scoped conversation persistence using Netlify Blobs.
- Server-side bounds for conversation/message/content storage.
- Cross-device conversation hydration after sign-in.
- Local cache retained for responsive UI; authenticated server state is the durable copy.
- Authenticated profile-name update.
- Account-wide conversation deletion from Settings.
- `/api/data` protected route.

## Architecture boundary
JoshGPT Native remains independent of OpenAI and Gemini. No external AI provider API is required by the active runtime.

## Production status
This is a checkpoint, not a live deployment. No production deployment was performed by this build.
