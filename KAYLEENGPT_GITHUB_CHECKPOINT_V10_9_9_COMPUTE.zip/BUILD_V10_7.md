# JoshGPT Native Portal V10.7 — Release Decision Integrity Gate

V10.7 binds the final release decision to the current genuine dependency lock, the verified dependency evidence chain, and the existing dependency-lock integrity verifier. A stale or copied decision artifact cannot authorize release. The gate remains fail-closed and does not fabricate lockfiles or mutate DNS, proxy, registry, live Netlify, or corporate-site configuration.

Deployment target remains JoshGPT project `joshgpt13` / site `322db469-6833-4187-b023-60638716b3c7`. Corporate site policy remains `DO_NOT_DEPLOY_OR_MODIFY`.
