# JoshGPT Native Portal V9.3 — ZIP Manifest Binding

V9.3 strengthens the manual deployment artifact boundary. The deployment ZIP verifier now reads and decompresses the ZIP payload itself, parses the embedded release manifest, SHA-256 verifies every manifest-listed file against the bytes actually present in the archive, requires the complete Netlify runtime JavaScript inventory to match the manifest, and binds package version and deployment target to the embedded manifest.

This prevents a structurally valid ZIP from passing if runtime code, release roots, package version, or target metadata were substituted after release-manifest generation.

The dependency release gate remains fail-closed until a genuine package-lock.json resolves the pinned @netlify/blobs 11.1.0 dependency. No lockfile is fabricated.
