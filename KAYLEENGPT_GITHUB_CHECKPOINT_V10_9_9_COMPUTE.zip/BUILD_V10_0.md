# JoshGPT Native Portal V10.0

V10.0 — ZIP Parser Hardening. Adds dependency-free CRC32 verification, explicit ZIP64 fail-closed policy, multi-disk rejection, and local-header filename/method/flag consistency checks while preserving release-manifest content binding and deployment-target isolation.

Live deployment is not authorized by this checkpoint. Corporate site remains excluded.
