# JoshGPT Native Portal V7.8 — Dependency Resolution Retry Gate

V7.8 retries the only outstanding dependency-lock release gate without weakening it.

- Package/release/preflight version synchronized to 7.8.0.
- `@netlify/blobs` remains exactly pinned to 11.1.0.
- A real `npm install --package-lock-only` was attempted and timed out in the build environment.
- No lockfile was fabricated or hand-authored.
- Release readiness therefore remains fail-closed until npm dependency resolution succeeds.
- Deployment target remains JoshGPT `joshgpt13` / `322db469-6833-4187-b023-60638716b3c7` only.
- Corporate project remains excluded from deployment/modification.
