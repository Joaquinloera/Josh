# JoshGPT Native Portal V7.7 — Deployment Hardening VII

V7.7 keeps the V7.0 / NSF-38 cognitive architecture frozen and adds a deterministic release-manifest boundary. Critical deploy files, the exact JoshGPT Netlify target, and the corporate-site exclusion policy are SHA-256 bound into `RELEASE_MANIFEST.json`. The manifest explicitly records whether the npm dependency lock exists; it does not bypass the V7.5/V7.6 fail-closed dependency gate.

Production target remains `joshgpt13` / `322db469-6833-4187-b023-60638716b3c7`. Corporate site remains DO NOT DEPLOY OR MODIFY.
