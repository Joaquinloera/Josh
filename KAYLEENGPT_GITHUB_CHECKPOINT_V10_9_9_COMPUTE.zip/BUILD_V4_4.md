# JoshGPT Native Portal V4.4 — NSF-12 Semantic Route Confidence

Adds a fail-closed confidence gate after NSF-11 stability and before final route governance. Learned routes require mature semantic history, sufficient candidate strength, and a minimum advantage over the deterministic base candidate. Cold, quarantined, or low-confidence learned routes fall back to the base route. Explicit user route selections remain authoritative. Every decision is SHA-256 bound to the NSF-10 trust profile and NSF-11 stability record and emits a CAP-1 WITNESS/GUARD signal.
