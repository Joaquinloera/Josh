# JoshGPT Native Portal V10.1

## Hardened ZIP Attestation Continuity

V10.1 repairs the detached artifact-attestation chain after the V10.0 ZIP verifier advanced from protocol 2 to protocol 3. The attestor now accepts verified protocol 3 evidence while retaining protocol 2 compatibility, and continues binding exact archive SHA-256, package version, manifest inventory, Netlify target identity, and corporate-site exclusion policy.

No live deployment is performed by this checkpoint.
