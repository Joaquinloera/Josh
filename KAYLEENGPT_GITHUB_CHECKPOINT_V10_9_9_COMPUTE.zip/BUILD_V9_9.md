# JoshGPT Native Portal V9.9

Dependency Lock Acquisition Gate. Performs one bounded genuine npm lock-only resolution attempt, validates any result through the strict V9.5 lock verifier, and refuses to retain a newly-created invalid lock. Emits a SHA-256-bound acquisition report. It never fabricates dependency metadata.
