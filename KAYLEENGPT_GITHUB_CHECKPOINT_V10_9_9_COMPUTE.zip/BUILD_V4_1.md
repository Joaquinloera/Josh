# JoshGPT Native Portal V4.1 — NSF-9 Archived Replay Shield

NSF-9 closes the replay gap created by semantic-ledger compaction. Archived feedback digests are accumulated into a SHA-256-bound 4096-bit, six-position replay filter stored in each checkpoint anchor. New semantic feedback is checked against both the retained exact ledger tail and the archived replay shield before commitment. A positive archived-filter match fails closed; false positives can reject a fresh receipt but can never silently authorize a replay. CAP-1 marks checkpoint continuity with ANCESTOR / REPLAY-GUARD.

This remains deterministic conventional software. It does not claim trained foundation-model weights, biological hardware, or physical quantum computation.
