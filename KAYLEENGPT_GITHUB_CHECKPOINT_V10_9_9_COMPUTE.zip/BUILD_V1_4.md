# JoshGPT Native Portal v1.4 checkpoint

Adds an account-scoped JoshGPT Native knowledge/memory layer without external AI providers.

- Native Core 0.4.
- Persistent knowledge notes stored server-side in Netlify Blobs.
- Deterministic lexical retrieval over account-owned knowledge.
- Persistent task-run receipts for authenticated chat requests.
- Agent-to-agent work products persisted and linked to task IDs.
- Authenticated `/api/memory` endpoint for knowledge, tasks, and work products.
- Bounded retention: 240 knowledge records, 120 task receipts, 360 work products.
- Chat runtime retrieves relevant knowledge before Native execution and records task/work-product evidence after execution.

This is retrieval/orchestration software, not a trained foundation model. No OpenAI or Gemini runtime dependency is introduced.
