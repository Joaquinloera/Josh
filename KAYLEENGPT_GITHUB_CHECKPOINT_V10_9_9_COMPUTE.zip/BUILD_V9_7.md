# JoshGPT Native Portal V9.7 — Release Evidence Bundle

V9.7 adds a machine-readable release evidence bundle that independently executes and SHA-256 binds the release-manifest verifier, package-boundary verifier, Netlify runtime verifier, dependency-lock verifier, and release-blocker consensus gate. It distinguishes non-dependency failures from the known genuine package-lock blocker and fails closed. It does not fabricate dependency metadata and does not deploy or modify either live site.
