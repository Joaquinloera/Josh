# JoshGPT Native Portal V10.8 — Final Release Authorization Gate

V10.8 adds a fail-closed final authorization layer over the verified release manifest, exact JoshGPT deployment target, genuine dependency lock, dependency evidence chain, dependency release decision, and release-decision integrity report.

The gate cannot authorize release while `package-lock.json` is missing, malformed, stale, unverified, or not SHA-256-bound through the current release chain. The corporate SonoraPort site remains explicitly excluded from deployment or modification.
