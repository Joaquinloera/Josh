# JoshGPT Native Portal V7.4 — Deployment Hardening IV

V7.4 preserves the frozen V7.0 / NSF-38 architecture and hardens the Netlify production boundary.

- Replaced active `process.env` access with Netlify runtime primitives.
- Production/preview Blob selection now reads `Netlify.context.deploy.context`.
- Optional routing signing key now reads `Netlify.env.get('JOSHGPT_ROUTING_SIGNING_KEY')`.
- WebAuthn expected origin is derived from the same-origin request URL rather than a build/runtime environment variable.
- Added a deployment-target manifest pinned to `joshgpt13` / site ID `322db469-6833-4187-b023-60638716b3c7`.
- Explicitly excludes the separate corporate project from deployment/modification.
- Adds 12 production-boundary contracts and extends deployment preflight.

This is a checkpoint, not the final upload artifact. Dependency installation/bundling and live production smoke validation remain separate gates.
