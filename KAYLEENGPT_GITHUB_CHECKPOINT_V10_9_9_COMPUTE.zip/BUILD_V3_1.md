# JoshGPT Native Portal V3.1 — Evidence Adjudication

Adds CKG-5 evidence adjudication for DISPUTED knowledge retrieved by CKG-4.

- Two distinct agents independently bind findings to the disputed claim, evidence and provenance.
- CAP-1 VERIFY/WITNESS signals travel with findings; reconciliation emits KNOW, VERIFY or SHADOW.
- Reconciliation is SHA-256 bound to both exact finding digests.
- Promotion requires verified independent findings and a bounded evidence/provenance threshold.
- Weak evidence is rejected; unresolved evidence remains disputed.
- Tampering with either finding invalidates reconciliation.
- No external AI provider is introduced.
