# JoshGPT Native Portal V4.2 — NSF-10 Semantic Trust Governor

NSF-10 converts the verified semantic feedback ledger into a bounded, SHA-256-bound trust profile that governs whether learned adaptive routing may influence future execution.

- Recent semantic feedback is scored over a bounded 24-entry window.
- Histories with fewer than four observations remain permissive to avoid cold-start lockout.
- Mature histories below the 0.50 semantic trust threshold fail back to the deterministic base route.
- Explicit host/agent choices remain authoritative overrides.
- The profile binds ledger head, sequence, checkpoint anchor, exact entry digests, counts, score, policy threshold, and CAP-1 signal.
- Route governance is separately SHA-256 bound and verified before execution.
- This is deterministic software policy; it does not imply trained foundation-model weights, biological hardware, or physical quantum hardware.
