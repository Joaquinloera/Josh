# JoshGPT Native Portal V6.7 — NSF-35 Learning-Bound Learning Admission

Closes continuity from learned-route durable execution into the next learning cycle. NSF-35 requires the exact NSF-31-origin learning lineage carried by NSF-24 to remain present and verified before adaptive learning may begin. It binds the execution attestation, execution ledger state, source learning-lineage digest, source learning-ledger head/sequence, and NSF-25 admission. Learned execution with incomplete lineage fails closed. Legacy execution remains compatible through the existing NSF-25 path semantics.
