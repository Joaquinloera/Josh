# JoshGPT Native Portal V9.1 — Package Boundary Attestation

V9.1 adds a fail-closed package boundary gate before manual deployment packaging. It verifies the exact JoshGPT target and corporate-site exclusion, requires release-root files and Netlify runtime code, rejects nested checkpoint roots, and denies `.netlify`, `node_modules`, `.git`, environment files, and private-key-like artifacts from the source package boundary.

This is a checkpoint, not the final upload artifact. The reproducible npm dependency lock remains a separate release gate.
