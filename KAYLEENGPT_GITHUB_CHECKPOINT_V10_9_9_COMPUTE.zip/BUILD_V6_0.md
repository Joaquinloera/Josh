# JoshGPT Native Portal V6.0 — NSF-28 Learning Ledger Checkpointing

NSF-28 removes the NSF-27 live-ledger capacity stop by compacting older verified learning-fulfillment commits into a SHA-256-bound archival checkpoint while preserving monotonic sequence and the retained chain head. A 4096-bit, six-position replay shield covers archived fulfillment digests and BQL receipt hashes. CAP-1 marks archival lineage with ANCESTOR / LEARNING-ARCHIVE.

This is an engineering checkpoint, not the normalized Netlify deployment artifact.
