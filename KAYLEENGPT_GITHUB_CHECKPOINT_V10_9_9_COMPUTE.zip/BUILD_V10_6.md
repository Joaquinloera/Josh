# JoshGPT Native Portal V10.6 — Dependency Release Decision Gate

V10.6 adds a final fail-closed dependency release decision that requires a genuine package-lock.json to be cryptographically bound to the verified V10.5 dependency evidence chain before dependency readiness can become READY. Missing, malformed, stale, or unbound dependency evidence remains blocked. No lockfile is fabricated and no DNS, proxy, registry, live Netlify project, or corporate site setting is modified.

Deployment target remains JoshGPT project `joshgpt13` / site `322db469-6833-4187-b023-60638716b3c7`. Corporate site policy remains `DO_NOT_DEPLOY_OR_MODIFY`.
