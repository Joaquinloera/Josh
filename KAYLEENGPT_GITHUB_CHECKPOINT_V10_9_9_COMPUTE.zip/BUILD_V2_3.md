# JoshGPT Native Portal V2.3 — Adaptive Routing

V2.3 connects BQL-1 learned pathways to live host/agent selection through BQR-1.

- bounded exploitation of verified strong pathways
- deterministic bounded exploration (15%) when multiple qualified routes exist
- confidence threshold before learned routing is eligible
- time decay toward neutral strength with a 30-day half-life
- rollback to the base deterministic route below the rollback threshold
- routing receipts bind request digest, candidate digest, policy, decision, and selected pathway
- HMAC-SHA256 routing signatures activate when `JOSHGPT_ROUTING_SIGNING_KEY` is configured; checkpoint mode explicitly reports unsigned integrity receipts otherwise
- explicit host/agent requests continue to override adaptive routing
- no deployment authority and no autonomous foundation-weight mutation
