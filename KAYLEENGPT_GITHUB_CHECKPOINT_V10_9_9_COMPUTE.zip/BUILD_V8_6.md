# JoshGPT Native Portal V8.6 — Complete Release Inventory Attestation

V8.6 closes the partial-manifest gap in the V8.5 release integrity boundary.

- Release manifest protocol advances to `JOSHGPT-RELEASE-MANIFEST-2`.
- Every JavaScript file under `netlify/functions` is now part of the SHA-256 release inventory, along with the release roots (`index.html`, `netlify.toml`, `package.json`, `DEPLOYMENT_TARGET.json`).
- `package-lock.json` automatically joins the inventory when it exists.
- Verification independently rebuilds the expected inventory and fails closed on omissions, unexpected entries, count drift, digest drift, target drift, or manifest self-digest drift.
- This remains a checkpoint. Missing reproducible dependency lock still blocks deploy-ready status.
- No live Netlify deployment was performed. Corporate project remains excluded.
