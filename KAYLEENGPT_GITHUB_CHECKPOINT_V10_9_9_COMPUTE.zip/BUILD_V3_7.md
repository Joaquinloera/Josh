# JoshGPT Native Portal V3.7 — NSF-5 Semantic Outcome Assurance

NSF-5 closes the semantic execution loop by binding the verified NSF-4 settlement to the exact Native output, semantic-plan success conditions, evaluation consensus, and current epistemic knowledge digest. A response is ACCEPTED only when required execution is satisfied, Native evaluation is READY, output exists, and all bounded success checks pass. Outcome records are SHA-256 bound; CAP-1 emits WITNESS for accepted outcomes and VERIFY for blocked outcomes.
