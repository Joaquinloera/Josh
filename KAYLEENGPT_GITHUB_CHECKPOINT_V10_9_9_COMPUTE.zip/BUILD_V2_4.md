# JoshGPT Native Portal V2.4 — Cognitive Scheduler

Adds BCS-1, a bounded Native cognitive scheduler layered on V2.3.

- Up to 3 deterministic cognitive work lanes and 12 admitted work units per request.
- Priority/attention allocation by intent plus CAP-1 GUARD/VERIFY signal weighting.
- Stable deterministic arbitration when pathways compete.
- Stalled work is requeued once, then fails closed.
- Scheduler state is SHA-256 bound and verified before Native execution proceeds.
- Existing identity, passkeys, memory, tools, task graph, reasoning, CAP-1, BQCA-1, BQL-1 and BQR-1 remain additive.
- No biological or quantum hardware is claimed. No external foundation-model provider is introduced.
