# JoshGPT13 production auth repair — V10.9.1

- Fixed login gate visibility: `[hidden]{display:none!important}` prevents `.authgate{display:grid}` from overriding the authenticated hidden state.
- Added password-login session round-trip verification through `/api/auth?action=me`.
- Added passkey-login session round-trip verification.
- Cache-busted `app.js` to `live-auth-20260926-3`.
- Added V110 regression coverage for gate hiding and session verification.
- Full existing `npm test` suite: PASS.
