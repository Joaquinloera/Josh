# JoshGPT Native Portal v1.3 checkpoint

- Advances active package/runtime to 1.3.0 and Native Core to native-core-0.3.
- Adds a provider-independent native orchestration pipeline: classify -> plan -> bounded working memory -> agent execution -> evaluation/consensus -> synthesis.
- Adds intent-specific five-step playbooks for software, security, research, writing, planning, and general work.
- Exposes structured plans, agent execution receipts, bounded working-memory metadata, and evaluation checks in the authenticated chat result.
- Preserves persistent JoshGPT identity, server sessions, passkey verification, profiles, and conversation storage from v1.0-v1.2.
- Does not claim trained JoshGPT foundation-model weights; foundationModelInstalled remains false.
- OpenAI and Gemini are not active runtime dependencies.
