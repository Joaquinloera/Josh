# JoshGPT Native Portal V5.2 — NSF-20 Pathway Execution Seal

NSF-20 closes the admission-to-execution gap. After NSF-19 admits a route and semantic governance resolves the final runtime route, NSF-20 binds the exact final host/agent set, NSF-19 admission digest, NSF-3 plan digest, NSF-12 confidence digest, request digest, and monotonic execution sequence into a SHA-256-verifiable execution seal. Learned-route substitution after admission fails closed. CAP-1 emits WITNESS for authorized execution and GUARD when the route binding fails.
