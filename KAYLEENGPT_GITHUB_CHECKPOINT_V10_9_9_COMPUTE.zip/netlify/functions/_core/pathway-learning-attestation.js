import crypto from 'node:crypto';
import { verifyPathwayLearningLedger } from './pathway-learning-ledger.js';
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v)}
const digestOf=v=>sha(canonical(v));
export const PATHWAY_LEARNING_ATTESTATION=Object.freeze({protocol:'NSF-29',version:1,mode:'durable-learning-state-attestation',failClosed:true});
export function buildPathwayLearningAttestation({ledger,pathway,key,receipt}){
 const ledgerVerified=verifyPathwayLearningLedger(ledger),entry=ledgerVerified?[...ledger.entries].reverse().find(e=>e.pathwayKey===key):null;
 const checks={ledgerVerified,entryPresent:!!entry,pathwayPresent:!!pathway,keyMatches:!!entry&&entry.pathwayKey===key,headBound:!!entry&&pathway?.lastLearningCommitDigest===entry.digest,receiptBound:!!entry&&pathway?.lastReceiptHash===entry.receiptHash&&receipt?.receiptHash===entry.receiptHash,strengthBound:!!entry&&Number(pathway?.strength)===Number(entry.resultingStrength),sequenceBound:!!entry&&entry.sequence<=ledger.sequence};
 const verified=Object.values(checks).every(Boolean);
 const body={protocol:'NSF-29',version:1,key,ledgerHead:ledger?.head||null,ledgerSequence:ledger?.sequence??null,anchorDigest:ledger?.anchor?.digest||null,entryDigest:entry?.digest||null,receiptHash:receipt?.receiptHash||null,pathwayStrength:pathway?.strength??null,checks,verified,cap1:{signal:verified?'WITNESS':'GUARD',utterance:verified?'STAR WITNESS LEARNING-STATE ATTESTED':'STAR GUARD LEARNING-STATE REJECTED'}};
 return {...body,digest:digestOf(body)};
}
export function verifyPathwayLearningAttestation(a,{ledger,pathway,key,receipt}={}){
 if(!a||a.protocol!=='NSF-29'||a.version!==1||!a.digest)return false;const {digest,...body}=a;if(digest!==digestOf(body))return false;
 if(ledger||pathway||key||receipt){const expected=buildPathwayLearningAttestation({ledger,pathway,key,receipt});return expected.digest===a.digest&&a.verified===true;}
 return a.verified===true&&Object.values(a.checks||{}).every(Boolean);
}
export function pathwayLearningAttestationSummary(a){return {protocol:'NSF-29',verified:!!a?.verified,key:a?.key||null,ledgerSequence:a?.ledgerSequence??null,ledgerHead:a?.ledgerHead||null,entryDigest:a?.entryDigest||null,cap1:a?.cap1||null,digest:a?.digest||null};}
