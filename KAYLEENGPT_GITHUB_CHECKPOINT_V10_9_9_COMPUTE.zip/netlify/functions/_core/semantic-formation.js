import crypto from 'node:crypto';

const STOP = new Set('a an and are as at be by for from has have i in is it me my of on or our please that the this to we what with you your'.split(' '));
const INTENT_RULES = [
  ['BUILD', /\b(build|create|implement|code|develop|make)\b/i],
  ['VERIFY', /\b(verify|check|validate|prove|test|inspect)\b/i],
  ['RESEARCH', /\b(research|investigate|compare|evidence|source|study)\b/i],
  ['PLAN', /\b(plan|roadmap|steps|strategy|organize|next)\b/i],
  ['TRANSFORM', /\b(write|draft|rewrite|summarize|translate)\b/i],
  ['QUERY', /\b(who|what|when|where|why|how|which)\b/i],
];
const RELATIONS = [
  ['USES', /\b(?:use|uses|using|with)\b/i],
  ['REQUIRES', /\b(?:need|needs|require|requires|must)\b/i],
  ['EXCLUDES', /\b(?:without|exclude|excluding|not using|no)\b/i],
  ['BUILDS', /\b(?:build|create|implement|develop)\b/i],
  ['VERIFIES', /\b(?:verify|validate|test|check)\b/i],
];
function sha(value){return crypto.createHash('sha256').update(value).digest('hex');}
function canonical(value){if(Array.isArray(value))return `[${value.map(canonical).join(',')}]`;if(value&&typeof value==='object')return `{${Object.keys(value).sort().map(k=>`${JSON.stringify(k)}:${canonical(value[k])}`).join(',')}}`;return JSON.stringify(value);}
function tokens(text){return String(text||'').normalize('NFKC').toLowerCase().match(/[\p{L}\p{N}][\p{L}\p{N}_'-]*/gu)||[];}
function concepts(text){const counts=new Map();for(const t of tokens(text)){if(t.length<2||STOP.has(t))continue;counts.set(t,(counts.get(t)||0)+1);}return [...counts].sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0])).slice(0,16).map(([label,count],i)=>({id:`c${i+1}`,label,count,digest:sha(label)}));}
function entities(text){const found=[];for(const m of String(text||'').matchAll(/\b(?:[A-Z][A-Za-z0-9_-]{2,})(?:\s+[A-Z][A-Za-z0-9_-]{2,})*/g)){const label=m[0].trim();if(!found.some(x=>x.label===label))found.push({id:`e${found.length+1}`,label,type:/\b(?:JoshGPT|CAP-1|CKG-\d|BQCA-\d)\b/i.test(label)?'SYSTEM':'NAMED'});}return found.slice(0,12);}
function relations(text,cs){const present=RELATIONS.filter(([,rx])=>rx.test(text)).map(([type])=>type);const out=[];for(let i=0;i<Math.min(cs.length-1,6);i++){const type=present[i%Math.max(present.length,1)]||'ASSOCIATED';out.push({id:`r${i+1}`,subject:cs[i].id,predicate:type,object:cs[i+1].id});}return out;}
export function formSemanticFrame(text,{context=[]}={}){
  const raw=String(text||'').trim(); const cs=concepts(raw); const es=entities(raw); const rs=relations(raw,cs);
  const intents=INTENT_RULES.filter(([,rx])=>rx.test(raw)).map(([x])=>x); if(!intents.length)intents.push('CONVERSE');
  const polarity=/\b(no|not|never|without|exclude|excluding)\b/i.test(raw)?'CONSTRAINED':'AFFIRMATIVE';
  const question=/\?|\b(who|what|when|where|why|how|which)\b/i.test(raw);
  const frame={protocol:'NSF-1',intent:intents[0],secondaryIntents:intents.slice(1,4),polarity,question,concepts:cs,entities:es,relations:rs,constraints:{negation:polarity==='CONSTRAINED',bounded:true},contextRefs:context.slice(-4).map((x,i)=>({id:`ctx${i+1}`,role:x.role||'unknown',digest:sha(String(x.content||''))})),cap1:{signal:question?'SEEK':intents[0]==='VERIFY'?'VERIFY':intents[0]==='BUILD'?'PATH':'WITNESS',utterance:`STAR ${question?'SEEK':intents[0]} PATH ${cs.slice(0,4).map(c=>c.label.toUpperCase()).join(' ')} ${polarity==='CONSTRAINED'?'GUARD':''}`.trim()}};
  frame.digest=sha(canonical(frame)); return frame;
}
export function verifySemanticFrame(frame){if(!frame||frame.protocol!=='NSF-1'||!frame.digest)return false;const {digest,...body}=frame;return digest===sha(canonical(body))&&Array.isArray(frame.concepts)&&frame.concepts.length<=16&&Array.isArray(frame.relations)&&frame.relations.length<=6;}
export function semanticSummary(frame){return {protocol:frame.protocol,intent:frame.intent,concepts:frame.concepts.map(x=>x.label),entities:frame.entities.map(x=>x.label),relationCount:frame.relations.length,cap1:frame.cap1.signal,digest:frame.digest};}
