import { getDeployStore, getStore } from '@netlify/blobs';

// JoshGPT production identity/memory persists across production deploys.
// Preview/dev contexts remain deploy-scoped so they cannot mutate production.
// Strong consistency is configured on store creation, per the Netlify Blobs API.
export function openJoshStore(name) {
  if (globalThis.Netlify?.context?.deploy?.context === 'production') return getStore(name, { consistency: 'strong' });
  return getDeployStore({ name, consistency: 'strong' });
}
