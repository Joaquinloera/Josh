import crypto from 'node:crypto';
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v);}
const digestOf=v=>sha(canonical(v));
export const PATHWAY_ROUTE_ADMISSION=Object.freeze({protocol:'NSF-19',version:1,mode:'attested-learned-route-admission',failClosed:true});
export function buildPathwayRouteAdmission({stateAttestation,inventoryAttestation,confidence,selection,explicitRoute=false}={}){
 const learned=selection?.selected?.source==='learned'||selection?.route?.source==='learned'||confidence?.mode==='LEARNED_ACCEPTED';
 const attestationsVerified=stateAttestation?.protocol==='NSF-17'&&stateAttestation?.verified===true&&inventoryAttestation?.protocol==='NSF-18'&&inventoryAttestation?.verified===true;
 const confidenceVerified=!!confidence?.digest&&confidence?.accepted!==false;
 const admitted=explicitRoute||!learned||(attestationsVerified&&confidenceVerified);
 const mode=explicitRoute?'EXPLICIT':learned?(admitted?'LEARNED-ATTESTED':'LEARNED-DENIED'):'BASE';
 const selected={host:selection?.selected?.host||selection?.route?.host?.id||null,agent:selection?.selected?.agent||selection?.route?.agent?.id||null,source:selection?.selected?.source||selection?.route?.source||'base'};
 const body={protocol:'NSF-19',stateAttestationDigest:stateAttestation?.digest||null,inventoryAttestationDigest:inventoryAttestation?.digest||null,confidenceDigest:confidence?.digest||null,attestationsVerified,confidenceVerified,learned,explicitRoute:Boolean(explicitRoute),mode,selected,admitted,cap1:{signal:admitted?'WITNESS':'GUARD',utterance:`STAR ${admitted?'WITNESS':'GUARD'} ROUTE-ADMISSION ${mode}`}};
 return {...body,digest:digestOf(body)};
}
export function verifyPathwayRouteAdmission(a,{stateDigest=null,inventoryDigest=null,confidenceDigest=null}={}){if(!a?.digest||a.protocol!=='NSF-19')return false;const {digest,...body}=a;if(digest!==digestOf(body))return false;if(stateDigest&&a.stateAttestationDigest!==stateDigest)return false;if(inventoryDigest&&a.inventoryAttestationDigest!==inventoryDigest)return false;if(confidenceDigest&&a.confidenceDigest!==confidenceDigest)return false;const expected=a.explicitRoute||!a.learned||(a.attestationsVerified&&a.confidenceVerified);return a.admitted===expected&&a.mode===(a.explicitRoute?'EXPLICIT':a.learned?(expected?'LEARNED-ATTESTED':'LEARNED-DENIED'):'BASE');}
export function pathwayRouteAdmissionSummary(a){return {protocol:a.protocol,digest:a.digest,mode:a.mode,admitted:a.admitted,learned:a.learned,attestationsVerified:a.attestationsVerified,cap1:a.cap1.signal};}
