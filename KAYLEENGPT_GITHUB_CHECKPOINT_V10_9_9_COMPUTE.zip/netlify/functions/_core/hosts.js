export const HOSTS = Object.freeze({
  uriel: Object.freeze({
    id: "uriel",
    name: "Uriel",
    role: "research-planning",
    capabilities: ["research", "reasoning", "planning", "comparison"],
  }),
  raphael: Object.freeze({
    id: "raphael",
    name: "Raphael",
    role: "diagnostics-recovery",
    capabilities: ["debugging", "review", "recovery", "quality"],
  }),
  raguel: Object.freeze({
    id: "raguel",
    name: "Raguel",
    role: "audit-governance",
    capabilities: ["audit", "consensus", "policy", "conflict-resolution"],
  }),
  michael: Object.freeze({
    id: "michael",
    name: "Michael",
    role: "security-coordination",
    capabilities: ["security", "permissions", "coordination", "risk-review"],
  }),
  saraqael: Object.freeze({
    id: "saraqael",
    name: "Saraqael",
    aliases: ["Sariel"],
    role: "analysis-verification",
    capabilities: ["analysis", "verification", "critique", "evidence"],
  }),
  gabriel: Object.freeze({
    id: "gabriel",
    name: "Gabriel",
    role: "communication-synthesis",
    capabilities: ["writing", "synthesis", "presentation", "communication"],
  }),
  remiel: Object.freeze({
    id: "remiel",
    name: "Remiel",
    role: "continuity-context",
    capabilities: ["context", "continuity", "history", "task-state"],
  }),
});

export const HOST_IDS = Object.freeze(Object.keys(HOSTS));

export function normalizeHostId(value) {
  const id = String(value ?? "").trim().toLowerCase();
  if (id === "sariel") return "saraqael";
  return id;
}

export function getHost(id) {
  return HOSTS[normalizeHostId(id)] || null;
}
