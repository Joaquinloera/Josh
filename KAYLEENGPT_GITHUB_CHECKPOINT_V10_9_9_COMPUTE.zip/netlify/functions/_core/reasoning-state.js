import crypto from 'node:crypto';
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
const clip=(v,n=1200)=>String(v??'').trim().slice(0,n);
const MAX_CYCLES=4, MAX_BRANCHES=6, MAX_EVIDENCE=8;

function evidence(intent,text,plan,toolReceipts,retrievedKnowledge){
  const items=[];
  for(const r of toolReceipts.filter(x=>x?.inspected===true&&x?.ok===true).slice(0,3)) items.push({kind:'tool',id:r.capability,verified:true,summary:`Verified ${r.capability} receipt.`});
  for(const k of retrievedKnowledge.slice(0,3)) items.push({kind:'knowledge',id:k.id||sha(k.title||'knowledge').slice(0,12),verified:true,summary:clip(k.title||k.content,180)});
  items.push({kind:'request',id:sha(text).slice(0,16),verified:true,summary:`User request retained for ${intent} reasoning.`});
  items.push({kind:'plan',id:sha(plan.map(x=>x.action).join('|')).slice(0,16),verified:plan.length>0,summary:`${plan.length} bounded plan steps available.`});
  return items.slice(0,MAX_EVIDENCE);
}
function candidate(id,label,claim,support,risks=[]){return{id,label,claim:clip(claim),support:[...new Set(support)],risks,score:0,confidence:0,status:'candidate',revision:0,parentId:null,eliminationReason:null};}
function scoreCandidate(c,evidenceById){
  const verified=c.support.filter(id=>evidenceById.get(id)?.verified).length, unsupported=Math.max(0,c.support.length-verified), riskPenalty=c.risks.length*0.08;
  c.score=Math.max(0,Math.min(1,Number((0.45+verified*0.14-unsupported*0.18-riskPenalty).toFixed(3))));c.confidence=c.score;return c;
}
function contradictions(candidates){const out=[];for(let i=0;i<candidates.length;i++)for(let j=i+1;j<candidates.length;j++){const a=candidates[i],b=candidates[j],pair=`${a.claim} ${b.claim}`;if(/external provider|required provider/i.test(pair)&&/native|no external|provider-independent/i.test(pair))out.push({a:a.id,b:b.id,type:'semantic-conflict',resolved:false});}return out;}
function branchCandidate(parent,cycle,evidenceIds){return{...parent,id:`${parent.id}.b${cycle}`,label:`${parent.label}-branch`,claim:clip(`${parent.claim} Validate the highest-impact unresolved assumption before committing.`),support:[...new Set([...parent.support,...evidenceIds.slice(-1)])],risks:parent.risks.slice(0,2),score:0,confidence:0,status:'candidate',revision:parent.revision+1,parentId:parent.id,eliminationReason:null};}
function runCycles(seed,byId,graphReady){
  let active=seed.map(x=>({...x})), branches=[...active], cycles=[], consumed=0, converged=false, previousWinner=null;
  for(let cycle=1;cycle<=MAX_CYCLES&&!converged;cycle++){
    consumed++; active.forEach(c=>scoreCandidate(c,byId)); active.sort((a,b)=>b.score-a.score||a.id.localeCompare(b.id));
    const eliminated=[]; for(const c of active.slice(1)){if(c.score<0.55||active[0].score-c.score>=0.07){c.status='eliminated';c.eliminationReason=c.score<0.55?'insufficient-evidence':'dominated-by-higher-confidence-candidate';eliminated.push(c.id);}}
    const survivors=active.filter(c=>c.status!=='eliminated'); const winner=survivors[0]||active[0];
    const stable=previousWinner===winner.id, margin=survivors.length>1?Number((winner.score-survivors[1].score).toFixed(3)):winner.score;
    converged=Boolean(graphReady&&(stable||margin>=0.18||survivors.length===1));
    cycles.push({cycle,winnerId:winner.id,winnerConfidence:winner.confidence,active:survivors.map(x=>x.id),eliminated,margin,converged});
    if(converged)break;
    previousWinner=winner.id;
    const child=branchCandidate(winner,cycle,[...byId.keys()]); scoreCandidate(child,byId); branches.push(child); active=[...survivors,child].slice(0,MAX_BRANCHES);
  }
  const viable=branches.filter(x=>x.status!=='eliminated'); viable.forEach(c=>scoreCandidate(c,byId)); viable.sort((a,b)=>b.score-a.score||a.id.localeCompare(b.id));
  return{cycles,branches,selected:viable[0]||branches[0],budget:{maxCycles:MAX_CYCLES,maxBranches:MAX_BRANCHES,cyclesConsumed:consumed,branchesCreated:branches.length,exhausted:consumed>=MAX_CYCLES&&!converged},converged};
}
export function buildReasoningState({intent='general',text='',plan=[],toolReceipts=[],retrievedKnowledge=[],taskGraph}){
  const ev=evidence(intent,text,plan,toolReceipts,retrievedKnowledge),ids=ev.map(x=>x.id),graphReady=taskGraph?.verification?.handoffsVerified===true,byId=new Map(ev.map(x=>[x.id,x]));
  const seeds=[candidate('c1','execute-plan',`Proceed with the bounded ${intent} plan using verified Native evidence.`,ids.slice(0,4),graphReady?[]:['task graph not verified']),candidate('c2','verify-first',`Prioritize verification and resolve unsupported assumptions before advancing the ${intent} task.`,ids.slice(-2),[]),candidate('c3','minimal-change',`Prefer the smallest reversible change that satisfies the request and preserves established JoshGPT boundaries.`,ids.filter(Boolean).slice(0,2),['may underfit complex request'])];
  seeds.forEach(c=>scoreCandidate(c,byId));const conflicts=contradictions(seeds);let revisions=0;for(const conflict of conflicts){const lower=[seeds.find(x=>x.id===conflict.a),seeds.find(x=>x.id===conflict.b)].sort((a,b)=>a.score-b.score)[0];lower.claim=`Revised: ${lower.claim} Only advance where verified evidence supports the step.`;lower.revision++;scoreCandidate(lower,byId);conflict.resolved=true;revisions++;}
  const iterative=runCycles(seeds,byId,graphReady),selected=iterative.selected;selected.status='selected';const allCandidates=iterative.branches.sort((a,b)=>b.score-a.score||a.id.localeCompare(b.id));const seedCandidates=seeds.sort((a,b)=>b.score-a.score||a.id.localeCompare(b.id));
  const conclusion={candidateId:selected.id,claim:selected.claim,score:selected.score,confidence:selected.confidence,evidenceIds:selected.support.filter(id=>byId.get(id)?.verified),evidenceBound:selected.support.every(id=>byId.get(id)?.verified),graphBound:graphReady,converged:iterative.converged};
  return{version:'reasoning-state-0.2',deterministic:true,evidence:ev,candidates:seedCandidates,branches:allCandidates,contradictions:conflicts,revisionPasses:revisions,cycles:iterative.cycles,executionBudget:iterative.budget,conclusion,verification:{candidateCount:seedCandidates.length,allContradictionsResolved:conflicts.every(x=>x.resolved),evidenceBound:conclusion.evidenceBound,graphBound:conclusion.graphBound,converged:conclusion.converged,budgetRespected:iterative.budget.cyclesConsumed<=MAX_CYCLES&&iterative.budget.branchesCreated<=MAX_BRANCHES,ready:Boolean(conclusion.evidenceBound&&conclusion.graphBound&&conflicts.every(x=>x.resolved)&&conclusion.converged)}};
}
