import crypto from 'node:crypto';
import { verifySemanticRouteAccountability } from './semantic-route-accountability.js';
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v);}
const digestOf=v=>sha(canonical(v)); const clamp=n=>Math.max(0,Math.min(1,Number(n)||0)); const round=n=>Number(clamp(n).toFixed(6));
export const PATHWAY_ACCOUNTABILITY=Object.freeze({protocol:'NSF-14',version:1,quarantineFailures:2,recoverySuccesses:2,maxAdjustment:.08});
export function applyPathwayAccountability({accountability,key,previous=null}={}){
 if(!verifySemanticRouteAccountability(accountability))throw new Error('Invalid semantic route accountability');
 const before=clamp(previous?.strength??.5), oldFailures=Math.max(0,Number(previous?.failures)||0), oldSuccesses=Math.max(0,Number(previous?.successes)||0);
 let failures=oldFailures,successes=oldSuccesses,delta=0,reason='OBSERVE',quarantined=Boolean(previous?.quarantined);
 if(accountability.verdict==='LEARNED_PROVEN'){successes++;failures=Math.max(0,failures-1);delta=.04;reason='VERIFIED_SUCCESS';if(quarantined&&successes>=PATHWAY_ACCOUNTABILITY.recoverySuccesses){quarantined=false;failures=0;reason='VERIFIED_RECOVERY';}}
 else if(accountability.verdict==='LEARNED_FAILED'){failures++;successes=0;delta=-.08;reason='VERIFIED_FAILURE';if(failures>=PATHWAY_ACCOUNTABILITY.quarantineFailures){quarantined=true;reason='QUARANTINED';}}
 else {delta=0;reason=accountability.verdict.startsWith('EXPLICIT_')?'EXPLICIT_OBSERVATION':'BASE_OBSERVATION';}
 if(quarantined&&reason!=='VERIFIED_RECOVERY') delta=Math.min(delta,0);
 const afterStrength=round(before+delta);
 const body={protocol:'NSF-14',accountabilityDigest:accountability.digest,key:String(key||''),beforeStrength:round(before),afterStrength,delta:round(afterStrength-before),failures,successes,quarantined,reason,cap1:{signal:quarantined?'GUARD':reason==='VERIFIED_RECOVERY'?'ANCESTOR':reason==='VERIFIED_SUCCESS'?'WITNESS':reason==='VERIFIED_FAILURE'?'VERIFY':'PATH',utterance:`STAR ${quarantined?'GUARD':reason==='VERIFIED_RECOVERY'?'ANCESTOR':reason==='VERIFIED_SUCCESS'?'WITNESS':reason==='VERIFIED_FAILURE'?'VERIFY':'PATH'} PATHWAY ${accountability.digest.slice(0,16)}`}};
 return {...body,digest:digestOf(body)};
}
export function verifyPathwayAccountability(r,{accountabilityDigest=null}={}){if(!r?.digest||r.protocol!=='NSF-14')return false;const {digest,...body}=r;if(digest!==digestOf(body))return false;if(accountabilityDigest&&r.accountabilityDigest!==accountabilityDigest)return false;if(!r.key||r.afterStrength<0||r.afterStrength>1||Math.abs(r.delta)>.080001)return false;if(r.quarantined&&r.failures<2&&r.reason==='QUARANTINED')return false;return true;}
export function pathwayAccountabilitySummary(r){return {protocol:r.protocol,digest:r.digest,key:r.key,reason:r.reason,strength:r.afterStrength,quarantined:r.quarantined,failures:r.failures,successes:r.successes,cap1:r.cap1.signal};}
