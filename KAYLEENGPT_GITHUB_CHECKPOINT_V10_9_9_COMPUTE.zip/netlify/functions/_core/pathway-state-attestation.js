import crypto from 'node:crypto';
import { verifyPathwayLedger } from './pathway-ledger.js';
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v);}
const digestOf=v=>sha(canonical(v));
const round=n=>Number(Math.max(0,Math.min(1,Number(n)||0)).toFixed(6));
export const PATHWAY_STATE_ATTESTATION=Object.freeze({protocol:'NSF-17',version:1,mode:'ledger-bound-pathway-state',failClosed:true});
function latestByKey(ledger){const m=new Map();for(const e of ledger?.entries||[])m.set(e.key,e);return m;}
export function buildPathwayStateAttestation({pathways={},ledger}={}){
 if(!verifyPathwayLedger(ledger)) throw new Error('Invalid pathway accountability ledger');
 const latest=latestByKey(ledger),checks=[];
 for(const [key,entry] of [...latest.entries()].sort((a,b)=>a[0].localeCompare(b[0]))){
   const p=pathways?.[key]||null;
   const strengthMatch=!!p&&round(p.strength)===round(entry.strength);
   const quarantineMatch=!!p&&Boolean(p.quarantined)===Boolean(entry.quarantined);
   checks.push({key,entryDigest:entry.digest,pathwayPresent:!!p,strength:round(p?.strength),expectedStrength:round(entry.strength),quarantined:Boolean(p?.quarantined),expectedQuarantined:Boolean(entry.quarantined),verified:strengthMatch&&quarantineMatch});
 }
 const verified=checks.every(x=>x.verified),body={protocol:'NSF-17',ledgerSequence:ledger.sequence,ledgerHead:ledger.head,anchorDigest:ledger.anchor?.digest||null,pathwaysDigest:digestOf(Object.fromEntries(Object.entries(pathways||{}).sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>[k,{strength:round(v?.strength),quarantined:Boolean(v?.quarantined),failures:Number(v?.failures)||0,successes:Number(v?.successes)||0,lastAccountabilityDigest:v?.lastAccountabilityDigest||null}]))),checks,verified,cap1:{signal:verified?'WITNESS':'GUARD',utterance:`STAR ${verified?'WITNESS':'GUARD'} PATHWAY-STATE ${String(ledger.head||'GENESIS').slice(0,16)}`}};
 return {...body,digest:digestOf(body)};
}
export function verifyPathwayStateAttestation(a,{ledger=null}={}){if(!a?.digest||a.protocol!=='NSF-17')return false;const {digest,...body}=a;if(digest!==digestOf(body))return false;if(!Array.isArray(a.checks)||a.verified!==a.checks.every(x=>x.verified===true))return false;if(ledger){if(!verifyPathwayLedger(ledger)||a.ledgerSequence!==ledger.sequence||a.ledgerHead!==ledger.head||a.anchorDigest!==(ledger.anchor?.digest||null))return false;}return true;}
export function pathwayStateAttestationSummary(a){return {protocol:a.protocol,digest:a.digest,verified:a.verified,checked:a.checks.length,ledgerSequence:a.ledgerSequence,ledgerHead:a.ledgerHead,cap1:a.cap1.signal};}
