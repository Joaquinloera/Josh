import crypto from 'node:crypto';
import { verifySemanticOutcome } from './semantic-outcome.js';
import { verifyLearningReceipt } from './adaptive-learning.js';
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v);}
const digestOf=v=>sha(canonical(v));

export function buildSemanticFeedback({outcome,learningReceipt=null,sequence=1}={}){
  if(!verifySemanticOutcome(outcome)) throw new Error('Invalid semantic outcome');
  if(learningReceipt&&!verifyLearningReceipt(learningReceipt)) throw new Error('Invalid learning receipt');
  const accepted=outcome.status==='ACCEPTED'&&outcome.accepted===true;
  const learningVerified=learningReceipt?.verified===true;
  const reinforce=accepted&&learningVerified;
  const action=reinforce?'REINFORCE':accepted?'OBSERVE':'NO_REINFORCEMENT';
  const body={protocol:'NSF-6',sequence:Number(sequence)||1,outcomeDigest:outcome.digest,outcomeStatus:outcome.status,learningReceiptHash:learningReceipt?.receiptHash||null,learningVerified,reinforce,action,bindings:{planDigest:outcome.planDigest,settlementDigest:outcome.settlementDigest,outputDigest:outcome.outputDigest,knowledgeDigest:outcome.knowledgeDigest||null},cap1:{signal:reinforce?'ANCESTOR':accepted?'WITNESS':'VERIFY',utterance:`STAR ${reinforce?'ANCESTOR':accepted?'WITNESS':'VERIFY'} EXPERIENCE ${outcome.digest.slice(0,16)}`}};
  return {...body,digest:digestOf(body)};
}
export function verifySemanticFeedback(feedback,{outcomeDigest,learningReceiptHash}={}){
  if(!feedback||feedback.protocol!=='NSF-6'||!feedback.digest)return false;
  const {digest,...body}=feedback;if(digest!==digestOf(body))return false;
  if(outcomeDigest&&feedback.outcomeDigest!==outcomeDigest)return false;
  if(learningReceiptHash!==undefined&&feedback.learningReceiptHash!==learningReceiptHash)return false;
  const reinforce=feedback.outcomeStatus==='ACCEPTED'&&feedback.learningVerified===true;
  if(feedback.reinforce!==reinforce)return false;
  if(feedback.action!==(reinforce?'REINFORCE':feedback.outcomeStatus==='ACCEPTED'?'OBSERVE':'NO_REINFORCEMENT'))return false;
  return feedback.cap1?.signal===(reinforce?'ANCESTOR':feedback.outcomeStatus==='ACCEPTED'?'WITNESS':'VERIFY');
}
export function semanticFeedbackSummary(f){return {protocol:'NSF-6',digest:f.digest,action:f.action,reinforce:f.reinforce,outcomeStatus:f.outcomeStatus,cap1:f.cap1.signal};}
