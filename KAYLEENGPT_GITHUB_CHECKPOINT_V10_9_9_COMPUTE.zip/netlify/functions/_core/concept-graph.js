import crypto from 'node:crypto';
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
const tokens=s=>[...new Set(String(s||'').toLowerCase().match(/[a-z0-9]{2,}/g)||[])];
const clip=(s,n=4000)=>String(s??'').trim().slice(0,n);
export const CONCEPT_PROTOCOL='CKG-1';
export function conceptId(label){return `c_${sha(String(label).trim().toLowerCase()).slice(0,20)}`;}
export function claimId(subject,predicate,object){return `k_${sha(`${subject}|${predicate}|${object}`).slice(0,24)}`;}
export function buildConceptGraph(items=[]){
 const concepts=new Map(),claims=[];
 for(const item of items){
  const sourceId=item.id||`src_${sha(item.title||item.content).slice(0,16)}`, provenance={sourceId,title:clip(item.title,160),updatedAt:item.updatedAt||item.createdAt||null,sourceType:'joshgpt-native-memory'};
  const labels=[...(item.tags||[]),...tokens(item.title).slice(0,8)];
  for(const label of labels){const id=conceptId(label);if(!concepts.has(id))concepts.set(id,{id,label:String(label).toLowerCase(),cap1:`STAR:${id.toUpperCase()}`});}
  const unique=[...new Set(labels.map(conceptId))];
  for(let i=0;i<unique.length;i++)for(let j=i+1;j<unique.length;j++){const subject=unique[i],object=unique[j],predicate='RELATED_TO';claims.push({id:claimId(subject,predicate,object),subject,predicate,object,evidence:clip(item.content,1200),provenance,weight:1,cap1:`PATH ${subject} ${predicate} ${object}`});}
 }
 const graph={protocol:CONCEPT_PROTOCOL,concepts:[...concepts.values()],claims};graph.digest=sha(JSON.stringify({protocol:graph.protocol,concepts:graph.concepts,claims:graph.claims}));return graph;
}
export function verifyConceptGraph(graph){if(graph?.protocol!==CONCEPT_PROTOCOL||!Array.isArray(graph.concepts)||!Array.isArray(graph.claims))return false;const copy={protocol:graph.protocol,concepts:graph.concepts,claims:graph.claims};return graph.digest===sha(JSON.stringify(copy))&&graph.claims.every(c=>c.provenance?.sourceId&&c.weight>=0&&c.weight<=1);}
export function rankConceptEvidence(graph,query,{limit=6}={}){const q=new Set(tokens(query));return (graph?.claims||[]).map(c=>{const s=graph.concepts.find(x=>x.id===c.subject),o=graph.concepts.find(x=>x.id===c.object);const terms=[s?.label,o?.label,c.predicate.toLowerCase(),...tokens(c.evidence)];const hits=terms.filter(x=>q.has(x)).length;const score=q.size?Math.min(1,(hits/q.size)*0.7+c.weight*0.3):0;return {...c,score};}).filter(x=>x.score>0.3).sort((a,b)=>b.score-a.score||a.id.localeCompare(b.id)).slice(0,limit);}
export function assembleKnowledgeContext({graph,query,notes=[],limit=6}){if(!verifyConceptGraph(graph))return {protocol:CONCEPT_PROTOCOL,verified:false,claims:[],notes:[],digest:null};const claims=rankConceptEvidence(graph,query,{limit});const selectedNotes=notes.slice(0,limit).map(n=>({id:n.id,title:n.title,score:n.score??0}));const payload={protocol:CONCEPT_PROTOCOL,verified:true,queryDigest:sha(query),claims:claims.map(c=>({id:c.id,subject:c.subject,predicate:c.predicate,object:c.object,score:Number(c.score.toFixed(4)),provenance:c.provenance,cap1:c.cap1})),notes:selectedNotes};return {...payload,digest:sha(JSON.stringify(payload))};}
