import crypto from 'node:crypto';

export const ADAPTIVE_LEARNING = Object.freeze({
  id:'BQL-1', version:'0.1', mode:'deterministic-verified-experience',
  reinforcement:true, decay:true, consolidation:true,
  autonomousWeightMutation:false, biologicalHardware:false, quantumHardware:false,
  maxPathways:64, maxExperiences:96
});
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
const clamp=n=>Math.max(0,Math.min(1,Number(n)||0));
const round=n=>Number(clamp(n).toFixed(6));
export function experienceScore({evaluation,cognitiveState,toolReceipts=[]}={}){
  const evalRatio=(evaluation?.total?evaluation.passed/evaluation.total:0);
  const verified=cognitiveState?.verification?.ready===true?1:0;
  const tools=toolReceipts.length?toolReceipts.filter(x=>x.ok&&x.inspected).length/toolReceipts.length:1;
  return round((evalRatio*.45)+(verified*.4)+(tools*.15));
}
export function pathwayKey({intent='general',host='native',agent='native'}={}){return `${intent}:${host}:${agent}`.toLowerCase();}
export function updatePathway(previous,{score,verified}={}){
  const old=clamp(previous?.strength??.5), decayed=old*.985;
  const delta=verified ? (clamp(score)-.5)*.18 : -.12;
  return {strength:round(decayed+delta),previousStrength:round(old),delta:round((decayed+delta)-old),verified:Boolean(verified)};
}
export function buildLearningReceipt({intent,route,evaluation,cognitiveState,toolReceipts=[],previousPathway=null,sequence=1,semanticOutcome=null}={}){
  const score=experienceScore({evaluation,cognitiveState,toolReceipts});
  const key=pathwayKey({intent,host:route?.host?.id||'native',agent:route?.agent?.id||route?.agents?.[0]?.id||'native'});
  const verified=evaluation?.consensus==='READY'&&cognitiveState?.verification?.ready===true&&(semanticOutcome?semanticOutcome.accepted===true:true);
  const update=updatePathway(previousPathway,{score,verified});
  const core={protocol:'BQL-1',sequence,key,score,verified,update,evidenceHash:sha(JSON.stringify({evaluation:evaluation?.checks||[],cognitive:cognitiveState?.bus?.verification||null,tools:toolReceipts.map(x=>({capability:x.capability,ok:x.ok,inspected:x.inspected})),semanticOutcome:semanticOutcome?{digest:semanticOutcome.digest,status:semanticOutcome.status,accepted:semanticOutcome.accepted}:null}))};
  return {...core,receiptHash:sha(JSON.stringify(core))};
}
export function verifyLearningReceipt(receipt){if(!receipt?.receiptHash)return false;const {receiptHash,...core}=receipt;return receipt.protocol==='BQL-1'&&sha(JSON.stringify(core))===receiptHash&&receipt.update?.strength>=0&&receipt.update?.strength<=1;}
export function consolidateExperiences(experiences=[]){
  const verified=experiences.filter(x=>x.verified&&verifyLearningReceipt(x));
  const avg=verified.length?verified.reduce((s,x)=>s+x.score,0)/verified.length:0;
  return {verifiedExperiences:verified.length,totalExperiences:experiences.length,meanVerifiedScore:Number(avg.toFixed(6)),consolidated:verified.length>=3};
}
