const RAW_AGENT_IDS = [
  "281102", "333", "7777", "4444", "999", "1390", "1290", "13", "23",
  "121", "187", "139013", "1023", "5525", "007", "2222", "55", "88",
  "1111", "420", "18", "32", "44", "9", "67", "76", "144", "1335",
];

export const AGENT_IDS = Object.freeze([...new Set(RAW_AGENT_IDS)]);

const DEFINITIONS = {
  "281102": { name: "Root", host: "michael", role: "orchestration", description: "Coordinates complex multi-host tasks." },
  "333": { name: "Builder", host: "raphael", role: "software", description: "Builds, reviews, and repairs software." },
  "7777": { name: "Research", host: "uriel", role: "research", description: "Research and evidence synthesis." },
  "4444": { name: "Analyst", host: "saraqael", role: "analysis", description: "Analysis, verification, and critique." },
  "999": { name: "Consensus", host: "raguel", role: "consensus", description: "Resolves conflicting candidate results." },
  "1390": { name: "Writer", host: "gabriel", role: "writing", description: "Communication and response synthesis." },
  "1290": { name: "Continuity", host: "remiel", role: "context", description: "Maintains task continuity and context." },
};

const HOST_ORDER = ["uriel", "raphael", "raguel", "michael", "saraqael", "gabriel", "remiel"];
const FALLBACK_ROLES = ["research", "software", "audit", "security", "analysis", "communication", "context"];

export const AGENTS = Object.freeze(Object.fromEntries(AGENT_IDS.map((id, index) => {
  const base = DEFINITIONS[id] || {
    name: `Agent ${id}`,
    host: HOST_ORDER[index % HOST_ORDER.length],
    role: FALLBACK_ROLES[index % FALLBACK_ROLES.length],
    description: "General JoshGPT runtime agent.",
  };

  return [id, Object.freeze({
    id,
    name: base.name,
    host: base.host,
    role: base.role,
    description: base.description,
    modelPolicy: "auto",
    tools: [],
    permissions: ["read"],
    status: "ready",
  })];
})));

export function getAgent(id) {
  return AGENTS[String(id ?? "")] || null;
}

export function agentsForHost(hostId) {
  return AGENT_IDS.map((id) => AGENTS[id]).filter((agent) => agent.host === hostId);
}

export function selectAgents(hostId, { limit = 3 } = {}) {
  return agentsForHost(hostId).slice(0, Math.max(1, limit));
}
