import crypto from 'node:crypto';
import { verifySemanticExecutionSettlement } from './semantic-execution.js';
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v);}
const digestOf=v=>sha(canonical(v));

export function buildSemanticOutcome({plan,settlement,output='',evaluation=null,knowledgeDigest=null}={}){
  if(!verifySemanticExecutionSettlement(settlement)) throw new Error('Invalid semantic execution settlement');
  const successConditions=(plan?.successConditions||[]).slice(0,8);
  const executionReady=settlement.requiredSatisfied===true;
  const evaluationReady=evaluation?.consensus==='READY';
  const outputPresent=String(output).trim().length>0;
  const checks=successConditions.map(condition=>({condition,pass:condition==='verification-status-explicit'?Boolean(evaluation?.consensus):executionReady}));
  checks.push({condition:'execution-settlement-verified',pass:true},{condition:'native-output-present',pass:outputPresent});
  const accepted=executionReady&&evaluationReady&&outputPresent&&checks.every(x=>x.pass);
  const body={protocol:'NSF-5',planDigest:plan?.digest||null,settlementDigest:settlement.digest,outputDigest:sha(String(output)),knowledgeDigest:knowledgeDigest||null,checks,evaluationConsensus:evaluation?.consensus||'BLOCKED',accepted,status:accepted?'ACCEPTED':'BLOCKED',cap1:{signal:accepted?'WITNESS':'VERIFY',utterance:`STAR ${accepted?'WITNESS':'VERIFY'} OUTCOME ${settlement.digest.slice(0,16)}`}};
  return {...body,digest:digestOf(body)};
}
export function verifySemanticOutcome(outcome,{planDigest,settlementDigest,output}={}){
  if(!outcome||outcome.protocol!=='NSF-5'||!outcome.digest||!Array.isArray(outcome.checks))return false;
  const {digest,...body}=outcome;if(digest!==digestOf(body))return false;
  if(planDigest&&outcome.planDigest!==planDigest)return false;if(settlementDigest&&outcome.settlementDigest!==settlementDigest)return false;if(output!==undefined&&outcome.outputDigest!==sha(String(output)))return false;
  const computed=outcome.evaluationConsensus==='READY'&&outcome.checks.every(x=>x.pass===true);
  if(outcome.accepted!==computed||outcome.status!==(computed?'ACCEPTED':'BLOCKED'))return false;
  return outcome.cap1?.signal===(computed?'WITNESS':'VERIFY');
}
export function semanticOutcomeSummary(outcome){return {protocol:'NSF-5',digest:outcome.digest,status:outcome.status,checksPassed:outcome.checks.filter(x=>x.pass).length,checksTotal:outcome.checks.length,outputDigest:outcome.outputDigest,cap1:outcome.cap1.signal};}
