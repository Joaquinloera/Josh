import crypto from 'node:crypto';
import { verifyPathwayExecutionLedger } from './pathway-execution-ledger.js';

const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v)}
const digestOf=v=>sha(canonical(v));

export const PATHWAY_EXECUTION_ATTESTATION=Object.freeze({protocol:'NSF-24',version:1,mode:'durable-execution-commit-attestation',failClosed:true});

export function buildPathwayExecutionAttestation({ledger,entry,fulfillment}){
  if(!verifyPathwayExecutionLedger(ledger)) throw new Error('Invalid NSF-22 execution ledger');
  if(!entry?.digest||entry.protocol!=='NSF-22-COMMIT') throw new Error('Invalid NSF-22 execution commit');
  if(!fulfillment?.digest||fulfillment.protocol!=='NSF-21'||fulfillment.fulfilled!==true) throw new Error('Invalid NSF-21 fulfillment');
  const current=ledger.entries.at(-1);
  const lineageOk=(fulfillment.sealAdmissionProtocol!=='NSF-31')||(entry.sealAdmissionProtocol==='NSF-31'&&entry.learningLineageDigest===fulfillment.learningLineageDigest&&entry.learningLedgerHead===fulfillment.learningLedgerHead&&entry.learningLedgerSequence===fulfillment.learningLedgerSequence);
  const durable=!!current&&ledger.head===entry.digest&&current.digest===entry.digest&&entry.sequence===ledger.sequence&&entry.fulfillmentDigest===fulfillment.digest&&entry.sealDigest===fulfillment.sealDigest&&entry.graphId===fulfillment.graphId&&entry.outputDigest===fulfillment.outputDigest&&lineageOk;
  const body={protocol:'NSF-24',version:1,status:durable?'ATTESTED':'DENIED',durable,ledgerProtocol:ledger.protocol,ledgerSequence:ledger.sequence,ledgerHead:ledger.head,ledgerAnchorDigest:ledger.anchor?.digest||null,entryDigest:entry.digest,entrySequence:entry.sequence,fulfillmentDigest:fulfillment.digest,sealDigest:fulfillment.sealDigest,graphId:fulfillment.graphId,outputDigest:fulfillment.outputDigest,sealAdmissionProtocol:fulfillment.sealAdmissionProtocol||'NSF-19',learningLineageDigest:fulfillment.learningLineageDigest||null,learningLedgerHead:fulfillment.learningLedgerHead||null,learningLedgerSequence:Number(fulfillment.learningLedgerSequence||0),cap1:{signal:durable?'WITNESS':'GUARD',utterance:durable?'STAR WITNESS EXECUTION-COMMIT DURABLE':'STAR GUARD EXECUTION-COMMIT DENIED'}};
  return {...body,digest:digestOf(body)};
}

export function verifyPathwayExecutionAttestation(attestation,{ledger,entry,fulfillment}={}){
  if(!attestation?.digest||attestation.protocol!=='NSF-24'||attestation.version!==1) return false;
  const {digest,...body}=attestation;if(digest!==digestOf(body))return false;
  if(attestation.status!=='ATTESTED'||attestation.durable!==true||attestation.cap1?.signal!=='WITNESS')return false;
  if(ledger){if(!verifyPathwayExecutionLedger(ledger)||attestation.ledgerSequence!==ledger.sequence||attestation.ledgerHead!==ledger.head||attestation.ledgerAnchorDigest!==(ledger.anchor?.digest||null))return false;}
  if(entry){if(attestation.entryDigest!==entry.digest||attestation.entrySequence!==entry.sequence||attestation.ledgerHead!==entry.digest)return false;}
  if(fulfillment){if(attestation.fulfillmentDigest!==fulfillment.digest||attestation.sealDigest!==fulfillment.sealDigest||attestation.graphId!==fulfillment.graphId||attestation.outputDigest!==fulfillment.outputDigest)return false;if(fulfillment.sealAdmissionProtocol==='NSF-31'&&(attestation.sealAdmissionProtocol!=='NSF-31'||attestation.learningLineageDigest!==fulfillment.learningLineageDigest||attestation.learningLedgerHead!==fulfillment.learningLedgerHead||attestation.learningLedgerSequence!==fulfillment.learningLedgerSequence))return false;}
  return true;
}

export function pathwayExecutionAttestationSummary(a){return {protocol:a.protocol,status:a.status,durable:a.durable,sequence:a.ledgerSequence,entryDigest:a.entryDigest,anchorDigest:a.ledgerAnchorDigest,cap1:a.cap1,verified:verifyPathwayExecutionAttestation(a)};}
