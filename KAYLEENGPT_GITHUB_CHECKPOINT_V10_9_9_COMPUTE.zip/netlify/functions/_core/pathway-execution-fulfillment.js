import crypto from 'node:crypto';
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v)}
const digestOf=v=>sha(canonical(v));
const idsFromSeal=seal=>new Set([seal?.route?.agent,...(seal?.route?.agents||[])].filter(Boolean));
export const PATHWAY_EXECUTION_FULFILLMENT=Object.freeze({protocol:'NSF-21',version:1,mode:'sealed-execution-fulfillment',failClosed:true});
export function buildPathwayExecutionFulfillment({seal,taskGraph,evaluation,output='',sequence=0}={}){
 const products=Array.isArray(taskGraph?.products)?taskGraph.products:[];
 const allowed=idsFromSeal(seal);
 const graphAgents=[...new Set(products.map(p=>p?.agentId).filter(Boolean))];
 const routeBound=graphAgents.length>0&&graphAgents.every(id=>allowed.has(id));
 const productsVerified=products.length>0&&products.every(p=>p?.verified===true&&p?.hash===sha(p?.content||'')&&p?.agentLanguageVerified===true);
 const handoffsVerified=taskGraph?.verification?.handoffsVerified===true&&taskGraph?.verification?.consensus==='READY';
 const evaluationReady=evaluation?.consensus==='READY';
 const fulfilled=seal?.protocol==='NSF-20'&&seal?.authorized===true&&!!seal?.digest&&routeBound&&productsVerified&&handoffsVerified&&evaluationReady&&Boolean(output);
 const body={protocol:'NSF-21',sealDigest:seal?.digest||null,sealAdmissionProtocol:seal?.admissionProtocol||null,learningLineageDigest:seal?.learningLineageDigest||null,learningLedgerHead:seal?.learningLedgerHead||null,learningLedgerSequence:seal?.learningLedgerSequence??0,sequence:Number(sequence)||0,graphId:taskGraph?.graph?.id||null,graphAgents,routeBound,productDigests:products.map(p=>({nodeId:p.nodeId,agentId:p.agentId,hash:p.hash,inputHashes:p.inputHashes||[]})),verification:{productsVerified,handoffsVerified,evaluationReady},evaluationDigest:digestOf(evaluation||null),outputDigest:sha(output),fulfilled,cap1:{signal:fulfilled?'WITNESS':'GUARD',utterance:`STAR ${fulfilled?'WITNESS':'GUARD'} EXECUTION-FULFILLMENT ${fulfilled?'COMPLETE':'BLOCKED'}`}};
 return {...body,digest:digestOf(body)};
}
export function verifyPathwayExecutionFulfillment(record,{sealDigest=null,taskGraph=null,evaluation=null,output=null}={}){
 if(!record?.digest||record.protocol!=='NSF-21')return false;const {digest,...body}=record;if(digest!==digestOf(body))return false;
 if(sealDigest&&record.sealDigest!==sealDigest)return false;
 const learningBound=record.sealAdmissionProtocol==='NSF-31';if(learningBound&&!record.learningLineageDigest)return false;
 if(taskGraph){const products=taskGraph?.products||[];const expected=products.map(p=>({nodeId:p.nodeId,agentId:p.agentId,hash:p.hash,inputHashes:p.inputHashes||[]}));if(digestOf(record.productDigests)!==digestOf(expected)||record.graphId!==(taskGraph?.graph?.id||null))return false;}
 if(evaluation&&record.evaluationDigest!==digestOf(evaluation))return false;if(output!==null&&record.outputDigest!==sha(output))return false;
 const v=record.verification||{};const lineageOkay=!learningBound||Boolean(record.learningLineageDigest);return record.fulfilled===Boolean(record.sealDigest&&lineageOkay&&record.routeBound&&v.productsVerified&&v.handoffsVerified&&v.evaluationReady&&record.outputDigest);
}
export function pathwayExecutionFulfillmentSummary(r){return {protocol:r.protocol,digest:r.digest,fulfilled:r.fulfilled,routeBound:r.routeBound,products:r.productDigests?.length||0,cap1:r.cap1?.signal};}
