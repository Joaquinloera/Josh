import crypto from 'node:crypto';
import { verifyPathwayLedger, archivedPathwayReplayPossible } from './pathway-ledger.js';
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v);}
const digestOf=v=>sha(canonical(v));
const round=n=>Number(Math.max(0,Math.min(1,Number(n)||0)).toFixed(6));
export const PATHWAY_INVENTORY_ATTESTATION=Object.freeze({protocol:'NSF-18',version:1,mode:'complete-pathway-inventory-proof',failClosed:true});
function retainedProof(ledger,key,lastDigest){const matches=(ledger.entries||[]).filter(e=>e.key===key);const latest=matches.at(-1)||null;if(!latest)return {latest:null,digestPresent:false};return {latest,digestPresent:matches.some(e=>e.adjustmentDigest===lastDigest)};}
export function buildPathwayInventoryAttestation({pathways={},ledger}={}){
 if(!verifyPathwayLedger(ledger))throw new Error('Invalid pathway accountability ledger');
 const checks=[];
 for(const [key,p] of Object.entries(pathways||{}).sort(([a],[b])=>a.localeCompare(b))){
  const last=p?.lastAccountabilityDigest||null,{latest,digestPresent}=retainedProof(ledger,key,last);
  const archivedProof=!!last&&!digestPresent&&archivedPathwayReplayPossible(ledger,last);
  const provenanceVerified=!!last&&(digestPresent||archivedProof);
  const retainedStateVerified=!latest||(latest.adjustmentDigest!==last)||(
   round(p?.strength)===round(latest.strength)&&Boolean(p?.quarantined)===Boolean(latest.quarantined)
  );
  checks.push({key,lastAccountabilityDigest:last,proof:digestPresent?'RETAINED':archivedProof?'ARCHIVED-SHIELD':'MISSING',retainedEntryDigest:latest?.digest||null,provenanceVerified,retainedStateVerified,verified:provenanceVerified&&retainedStateVerified});
 }
 const retainedKeys=[...new Set((ledger.entries||[]).map(e=>e.key))].sort();
 const missingPathways=retainedKeys.filter(key=>!Object.prototype.hasOwnProperty.call(pathways,key));
 const verified=checks.every(x=>x.verified)&&missingPathways.length===0;
 const inventory=Object.fromEntries(Object.entries(pathways||{}).sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>[k,{strength:round(v?.strength),quarantined:Boolean(v?.quarantined),lastAccountabilityDigest:v?.lastAccountabilityDigest||null}]));
 const body={protocol:'NSF-18',ledgerSequence:ledger.sequence,ledgerHead:ledger.head,anchorDigest:ledger.anchor?.digest||null,inventoryDigest:digestOf(inventory),checks,missingPathways,verified,cap1:{signal:verified?'WITNESS':'GUARD',utterance:`STAR ${verified?'WITNESS':'GUARD'} PATHWAY-INVENTORY ${String(ledger.head||'GENESIS').slice(0,16)}`}};
 return {...body,digest:digestOf(body)};
}
export function verifyPathwayInventoryAttestation(a,{ledger=null}={}){if(!a?.digest||a.protocol!=='NSF-18')return false;const {digest,...body}=a;if(digest!==digestOf(body))return false;if(!Array.isArray(a.checks)||!Array.isArray(a.missingPathways))return false;if(a.verified!==(a.checks.every(x=>x.verified===true)&&a.missingPathways.length===0))return false;if(ledger){if(!verifyPathwayLedger(ledger)||a.ledgerSequence!==ledger.sequence||a.ledgerHead!==ledger.head||a.anchorDigest!==(ledger.anchor?.digest||null))return false;}return true;}
export function pathwayInventoryAttestationSummary(a){return {protocol:a.protocol,digest:a.digest,verified:a.verified,checked:a.checks.length,missing:a.missingPathways.length,ledgerSequence:a.ledgerSequence,ledgerHead:a.ledgerHead,cap1:a.cap1.signal};}
