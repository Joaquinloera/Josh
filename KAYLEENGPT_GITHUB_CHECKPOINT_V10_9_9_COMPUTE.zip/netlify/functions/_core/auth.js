import crypto from 'node:crypto';
import { openJoshStore } from './blob-store.js';

const ACCOUNT_STORE = 'joshgpt-identity-v1';
const SESSION_STORE = 'joshgpt-sessions-v1';
const CHALLENGE_STORE = 'joshgpt-webauthn-v1';
const SESSION_COOKIE = 'jg_session_v1';
const CHALLENGE_COOKIE = 'jg_webauthn_v1';
const SESSION_SECONDS = 60 * 60 * 24 * 30;
const CHALLENGE_SECONDS = 5 * 60;
const b64u = b => Buffer.from(b).toString('base64url');
const unb64u = s => Buffer.from(s, 'base64url');
const safeEq = (a,b) => { try { const x=Buffer.from(a), y=Buffer.from(b); return x.length===y.length && crypto.timingSafeEqual(x,y); } catch { return false; } };
const digest = value => crypto.createHash('sha256').update(value).digest('hex');
const accountKey = email => `account/${digest(String(email).trim().toLowerCase())}`;
const token = bytes => b64u(crypto.randomBytes(bytes));
function cookies(req){ const out={}; for(const p of (req.headers.get('cookie')||'').split(';')){ const i=p.indexOf('='); if(i>0) out[p.slice(0,i).trim()]=decodeURIComponent(p.slice(i+1).trim()); } return out; }
function cookie(name,value,{maxAge=SESSION_SECONDS}={}){ return `${name}=${encodeURIComponent(value)}; Path=/; Max-Age=${maxAge}; SameSite=Strict; Secure; HttpOnly`; }
export function clearCookies(){ return [cookie(SESSION_COOKIE,'',{maxAge:0}),cookie(CHALLENGE_COOKIE,'',{maxAge:0})]; }
export function publicAccount(a){ return a ? {email:a.email,name:a.name,passkeyEnrolled:!!a.passkey} : null; }
export async function getAccount(email){ if(!email) return null; return openJoshStore(ACCOUNT_STORE).get(accountKey(email),{type:'json'}); }
export async function createAccount(account){ const store=openJoshStore(ACCOUNT_STORE), key=accountKey(account.email); if(await store.get(key,{type:'json'})) return false; await store.setJSON(key,account); const saved=await store.get(key,{type:'json'}); return !!saved && saved.email===account.email && safeEq(saved.passwordHash||'',account.passwordHash||''); }
export async function saveAccount(account){ await openJoshStore(ACCOUNT_STORE).setJSON(accountKey(account.email),account); }
export async function makeSession(account){ const raw=token(32), now=Date.now(), record={kind:'session',email:account.email,name:account.name,createdAt:now,expiresAt:now+SESSION_SECONDS*1000}; await openJoshStore(SESSION_STORE).setJSON(`session/${digest(raw)}`,record); return cookie(SESSION_COOKIE,raw); }
export async function readSession(req){ const raw=cookies(req)[SESSION_COOKIE]; if(!raw) return null; const key=`session/${digest(raw)}`, store=openJoshStore(SESSION_STORE), s=await store.get(key,{type:'json'}); if(!s||s.kind!=='session'||s.expiresAt<Date.now()){ if(s) await store.delete(key); return null; } return s; }
export async function revokeSession(req){ const raw=cookies(req)[SESSION_COOKIE]; if(raw) await openJoshStore(SESSION_STORE).delete(`session/${digest(raw)}`); }
export async function requireSession(req){ const s=await readSession(req); if(!s) throw Object.assign(new Error('AUTH_REQUIRED'),{status:401}); return s; }
export async function makeChallenge(kind,email){ const id=token(24), challenge=token(32), now=Date.now(); await openJoshStore(CHALLENGE_STORE).setJSON(`challenge/${digest(id)}`,{kind,email,challenge,createdAt:now,expiresAt:now+CHALLENGE_SECONDS*1000}); return {challenge,cookie:cookie(CHALLENGE_COOKIE,id,{maxAge:CHALLENGE_SECONDS})}; }
export async function takeChallenge(req){ const id=cookies(req)[CHALLENGE_COOKIE]; if(!id) return null; const key=`challenge/${digest(id)}`, store=openJoshStore(CHALLENGE_STORE), c=await store.get(key,{type:'json'}); await store.delete(key); return c&&c.expiresAt>=Date.now()?c:null; }
export function hashPassword(password,salt=b64u(crypto.randomBytes(16))){ const hash=crypto.pbkdf2Sync(password,salt,310000,32,'sha256').toString('base64url'); return {salt,hash}; }
export function passwordMatches(password,account){ if(!account?.salt||!account?.passwordHash) return false; const x=crypto.pbkdf2Sync(password,account.salt,310000,32,'sha256').toString('base64url'); return safeEq(x,account.passwordHash); }
export function expectedOrigin(req){ const u=new URL(req.url); return `${u.protocol}//${u.host}`; }
export function rpId(req){ return new URL(expectedOrigin(req)).hostname; }
export function verifyClientData(clientDataB64, expectedChallenge, expectedType, origin){ const raw=unb64u(clientDataB64); const data=JSON.parse(raw.toString('utf8')); if(data.type!==expectedType||data.challenge!==expectedChallenge||data.origin!==origin) throw new Error('WEBAUTHN_CLIENT_DATA_INVALID'); return raw; }
export function verifyAssertion({account,clientDataJSON,authenticatorData,signature,challenge,origin,rp}){ if(!account?.passkey?.publicKeySpki) throw new Error('PASSKEY_NOT_ENROLLED'); const clientRaw=verifyClientData(clientDataJSON,challenge,'webauthn.get',origin); const auth=unb64u(authenticatorData); if(auth.length<37) throw new Error('WEBAUTHN_AUTH_DATA_INVALID'); const rpHash=crypto.createHash('sha256').update(rp).digest(); if(!crypto.timingSafeEqual(auth.subarray(0,32),rpHash)) throw new Error('WEBAUTHN_RP_INVALID'); const flags=auth[32]; if((flags&0x01)===0||(flags&0x04)===0) throw new Error('WEBAUTHN_USER_VERIFICATION_REQUIRED'); const clientHash=crypto.createHash('sha256').update(clientRaw).digest(), signed=Buffer.concat([auth,clientHash]), key=crypto.createPublicKey({key:unb64u(account.passkey.publicKeySpki),format:'der',type:'spki'}); if(!crypto.verify('sha256',signed,key,unb64u(signature))) throw new Error('WEBAUTHN_SIGNATURE_INVALID'); const signCount=auth.readUInt32BE(33), previous=Number(account.passkey.signCount||0); if(previous>0&&signCount>0&&signCount<=previous) throw new Error('WEBAUTHN_SIGN_COUNT_INVALID'); return {signCount}; }

export { verifyRegistration } from './webauthn-registration.js';
