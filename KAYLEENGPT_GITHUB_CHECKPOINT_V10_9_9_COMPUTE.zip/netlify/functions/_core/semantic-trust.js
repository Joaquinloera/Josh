import crypto from 'node:crypto';
import { verifySemanticLedger } from './semantic-ledger.js';
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v);}
const digestOf=v=>sha(canonical(v));
export const SEMANTIC_TRUST=Object.freeze({protocol:'NSF-10',window:24,minObservations:4,learnedRouteThreshold:.5});
export function buildSemanticTrustProfile(ledgerInput,{window=SEMANTIC_TRUST.window,minObservations=SEMANTIC_TRUST.minObservations,threshold=SEMANTIC_TRUST.learnedRouteThreshold}={}){
 const ledger=ledgerInput||{protocol:'NSF-8',sequence:0,head:null,anchor:null,entries:[]};
 if(!verifySemanticLedger(ledger))throw new Error('Invalid semantic ledger for trust profile');
 const entries=ledger.entries.slice(-Math.max(1,Math.min(64,window)));const observations=entries.length;
 const reinforced=entries.filter(e=>e.action==='REINFORCE').length,observed=entries.filter(e=>e.action==='OBSERVE').length,blocked=entries.filter(e=>e.action==='NO_REINFORCEMENT').length;
 const positive=reinforced+(observed*.5),score=observations?Number((positive/observations).toFixed(6)):1;
 const mature=observations>=minObservations,allowLearnedRouting=!mature||score>=threshold;
 const body={protocol:'NSF-10',ledgerHead:ledger.head,ledgerSequence:ledger.sequence,anchorDigest:ledger.anchor?.digest||null,window:entries.length,minObservations,threshold,observations,reinforced,observed,blocked,score,mature,allowLearnedRouting,entryDigests:entries.map(e=>e.digest),cap1:{signal:allowLearnedRouting?'WITNESS':'VERIFY',utterance:`STAR ${allowLearnedRouting?'WITNESS':'VERIFY'} TRUST ${String(ledger.head||'GENESIS').slice(0,16)}`}};
 return {...body,digest:digestOf(body)};
}
export function verifySemanticTrustProfile(profile,{ledger=null}={}){if(!profile||profile.protocol!=='NSF-10'||!profile.digest)return false;const {digest,...body}=profile;if(digest!==digestOf(body))return false;if(profile.observations!==profile.entryDigests.length||profile.reinforced+profile.observed+profile.blocked!==profile.observations)return false;if(profile.score<0||profile.score>1)return false;if(profile.allowLearnedRouting!==(!profile.mature||profile.score>=profile.threshold))return false;if(ledger){if(!verifySemanticLedger(ledger)||profile.ledgerHead!==ledger.head||profile.ledgerSequence!==ledger.sequence||profile.anchorDigest!==(ledger.anchor?.digest||null))return false;}return true;}
export function applySemanticTrustToRoute({baseRoute,selection,profile,explicitRoute=false}={}){if(!verifySemanticTrustProfile(profile))throw new Error('Invalid semantic trust profile');const governed=explicitRoute||profile.allowLearnedRouting?selection.route:baseRoute;const mode=explicitRoute?'EXPLICIT_OVERRIDE':profile.allowLearnedRouting?'LEARNED_ALLOWED':'BASE_ROUTE_FALLBACK';const body={protocol:'NSF-10-ROUTE',profileDigest:profile.digest,selectionReceipt:selection?.decision||null,mode,learnedRouteUsed:mode==='LEARNED_ALLOWED',cap1:{signal:mode==='BASE_ROUTE_FALLBACK'?'VERIFY':'PATH',utterance:`STAR ${mode==='BASE_ROUTE_FALLBACK'?'VERIFY':'PATH'} ROUTE ${profile.digest.slice(0,16)}`}};return {route:governed,governance:{...body,digest:digestOf(body)}};}
export function verifySemanticRouteGovernance(g,{profileDigest}={}){if(!g?.digest||g.protocol!=='NSF-10-ROUTE')return false;const {digest,...body}=g;return digest===digestOf(body)&&(!profileDigest||g.profileDigest===profileDigest)&&['EXPLICIT_OVERRIDE','LEARNED_ALLOWED','BASE_ROUTE_FALLBACK'].includes(g.mode);}
