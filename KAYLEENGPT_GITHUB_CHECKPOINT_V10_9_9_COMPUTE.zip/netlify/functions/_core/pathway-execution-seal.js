import crypto from 'node:crypto';
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
function canonical(v){
 if(Array.isArray(v)) return `[${v.map(canonical).join(',')}]`;
 if(v&&typeof v==='object') return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;
 return JSON.stringify(v);
}
const digestOf=v=>sha(canonical(v));
const routeIdentity=route=>({host:route?.host?.id||null,agent:route?.agent?.id||route?.agents?.[0]?.id||null,agents:(route?.agents||[]).map(a=>a?.id).filter(Boolean)});
export const PATHWAY_EXECUTION_SEAL=Object.freeze({protocol:'NSF-20',version:1,mode:'admission-to-execution-binding',failClosed:true});
export function buildPathwayExecutionSeal({admission,route,plan,confidence,request='',sequence=0}={}){
 const supportedAdmission=admission?.protocol==='NSF-19'||admission?.protocol==='NSF-31';
 const admitted=supportedAdmission&&admission?.admitted===true&&!!admission?.digest;
 const routeId=routeIdentity(route);
 const admissionRoute=admission?.selected||{};
 const learned=admission?.learned===true&&!admission?.explicitRoute;
 const routeMatches=!learned||((!admissionRoute.host||admissionRoute.host===routeId.host)&&(!admissionRoute.agent||admissionRoute.agent===routeId.agent));
 const lineagePresent=admission?.protocol!=='NSF-31'||!!admission?.learningRouteAttestationDigest;
 const authorized=admitted&&lineagePresent&&routeMatches&&!!plan?.digest&&!!confidence?.digest;
 const body={protocol:'NSF-20',admissionProtocol:admission?.protocol||null,admissionDigest:admission?.digest||null,learningLineageDigest:admission?.protocol==='NSF-31'?(admission?.learningRouteAttestationDigest||null):null,learningLedgerHead:admission?.protocol==='NSF-31'?(admission?.learningLedgerHead||null):null,learningLedgerSequence:admission?.protocol==='NSF-31'?(admission?.learningLedgerSequence??0):0,planDigest:plan?.digest||null,confidenceDigest:confidence?.digest||null,requestDigest:sha(request),sequence:Number(sequence)||0,route:routeId,admissionRoute:{host:admissionRoute.host||null,agent:admissionRoute.agent||null,source:admissionRoute.source||null},learned,routeMatches,authorized,cap1:{signal:authorized?'WITNESS':'GUARD',utterance:`STAR ${authorized?'WITNESS':'GUARD'} EXECUTION-SEAL ${learned?'LEARNED':'DIRECT'}`}};
 return {...body,digest:digestOf(body)};
}
export function verifyPathwayExecutionSeal(seal,{admissionDigest=null,planDigest=null,confidenceDigest=null,request=null,route=null}={}){
 if(!seal?.digest||seal.protocol!=='NSF-20')return false;const {digest,...body}=seal;if(digest!==digestOf(body))return false;
 if(admissionDigest&&seal.admissionDigest!==admissionDigest)return false;if(planDigest&&seal.planDigest!==planDigest)return false;if(confidenceDigest&&seal.confidenceDigest!==confidenceDigest)return false;if(request!==null&&seal.requestDigest!==sha(request))return false;
 if(route&&digestOf(seal.route)!==digestOf(routeIdentity(route)))return false;
 const admissionSupported=seal.admissionProtocol==='NSF-19'||seal.admissionProtocol==='NSF-31';
 const lineageOkay=seal.admissionProtocol!=='NSF-31'||Boolean(seal.learningLineageDigest);
 const expected=Boolean(admissionSupported&&lineageOkay&&seal.admissionDigest&&seal.planDigest&&seal.confidenceDigest&&seal.routeMatches);return seal.authorized===expected;
}
export function pathwayExecutionSealSummary(s){return {protocol:s.protocol,digest:s.digest,authorized:s.authorized,routeMatches:s.routeMatches,route:s.route,cap1:s.cap1.signal};}
