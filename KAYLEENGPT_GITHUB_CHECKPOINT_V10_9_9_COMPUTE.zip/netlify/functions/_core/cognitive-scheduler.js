import crypto from 'node:crypto';
const POLICY=Object.freeze({protocol:'BCS-1',maxLanes:3,maxUnits:12,maxRecovery:1,priorities:{security:100,software:90,research:75,planning:65,writing:55,general:50}});
const hash=v=>crypto.createHash('sha256').update(typeof v==='string'?v:JSON.stringify(v)).digest('hex');
export function schedulerPolicy(){return {...POLICY,priorities:{...POLICY.priorities}};}
export function capPriority(intent='general',capSignal=''){const base=POLICY.priorities[intent]||POLICY.priorities.general; const signal=String(capSignal).toUpperCase(); return Math.max(0,Math.min(100,base+(signal.includes('GUARD')?8:0)+(signal.includes('VERIFY')?5:0)));}
export function buildCognitiveSchedule({intent='general',taskGraph={},toolPlan=[],request=''}){
 const nodes=Array.isArray(taskGraph.nodes)?taskGraph.nodes:[]; const units=[];
 for(const n of nodes) units.push({id:n.id||`agent-${units.length+1}`,kind:'agent',dependsOn:n.dependsOn||[],cost:2,status:'queued'});
 for(const [i,t] of toolPlan.entries()) units.push({id:`tool-${i+1}`,kind:'tool',capability:t.capability,dependsOn:[],cost:1,status:'queued'});
 const priority=capPriority(intent,request); const admitted=units.slice(0,POLICY.maxUnits); const lanes=Array.from({length:Math.min(POLICY.maxLanes,Math.max(1,admitted.length))},(_,i)=>({id:`lane-${i+1}`,units:[]}));
 admitted.forEach((u,i)=>lanes[i%lanes.length].units.push(u.id));
 const schedule={protocol:POLICY.protocol,intent,priority,budget:{maxLanes:POLICY.maxLanes,maxUnits:POLICY.maxUnits,admitted:admitted.length,rejected:Math.max(0,units.length-admitted.length)},lanes,units:admitted,arbitration:'PRIORITY_THEN_STABLE_ORDER',recovery:{maxRetries:POLICY.maxRecovery,stalled:'REQUEUE_ONCE_THEN_FAIL_CLOSED'}};
 return {...schedule,digest:hash(schedule)};
}
export function verifyCognitiveSchedule(s){if(!s||s.protocol!==POLICY.protocol||!Array.isArray(s.units)||s.units.length>POLICY.maxUnits||!Array.isArray(s.lanes)||s.lanes.length>POLICY.maxLanes)return false; const {digest,...body}=s; return digest===hash(body);}
export function arbitrateCognitivePaths(paths=[]){return [...paths].map((p,i)=>({...p,_i:i})).sort((a,b)=>(b.priority||0)-(a.priority||0)||a._i-b._i).map(({_i,...p})=>p);}
export function recoverStalledUnit(unit,attempt=0){if(attempt<POLICY.maxRecovery)return {...unit,status:'requeued',recoveryAttempt:attempt+1}; return {...unit,status:'failed-closed',recoveryAttempt:attempt};}
