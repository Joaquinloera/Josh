import crypto from 'node:crypto';
import { verifyPathwayLearningAdmission } from './pathway-learning-admission.js';
import { verifyPathwayExecutionAttestation } from './pathway-execution-attestation.js';

const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v)}
const digestOf=v=>sha(canonical(v));

export const LEARNING_BOUND_LEARNING_ADMISSION=Object.freeze({protocol:'NSF-35',version:1,mode:'learning-lineage-bound-learning-admission',failClosed:true});

export function buildLearningBoundLearningAdmission({admission,attestation}={}){
  const admissionVerified=verifyPathwayLearningAdmission(admission,{attestation});
  const executionVerified=verifyPathwayExecutionAttestation(attestation);
  const learnedExecution=attestation?.sealAdmissionProtocol==='NSF-31';
  const lineageComplete=!learnedExecution||!!(attestation?.learningLineageDigest&&attestation?.learningLedgerHead&&Number(attestation?.learningLedgerSequence)>0);
  const lineageConsistent=!learnedExecution||(admission?.attestationDigest===attestation?.digest&&admission?.executionLedgerHead===attestation?.ledgerHead&&admission?.executionLedgerSequence===attestation?.ledgerSequence);
  const admitted=admissionVerified&&executionVerified&&admission?.admitted===true&&lineageComplete&&lineageConsistent;
  const body={protocol:'NSF-35',version:1,status:admitted?'ADMITTED':'DENIED',admitted,baseAdmissionDigest:admission?.digest||null,executionAttestationDigest:attestation?.digest||null,executionEntryDigest:attestation?.entryDigest||null,executionLedgerHead:attestation?.ledgerHead||null,executionLedgerSequence:Number(attestation?.ledgerSequence||0),sealAdmissionProtocol:attestation?.sealAdmissionProtocol||'NSF-19',learningLineageDigest:attestation?.learningLineageDigest||null,sourceLearningLedgerHead:attestation?.learningLedgerHead||null,sourceLearningLedgerSequence:Number(attestation?.learningLedgerSequence||0),bindings:{admissionVerified,executionVerified,learnedExecution,lineageComplete,lineageConsistent},cap1:{signal:admitted?'ANCESTOR':'GUARD',utterance:admitted?'STAR ANCESTOR LEARNING-LINEAGE ADMISSION VERIFIED':'STAR GUARD LEARNING-LINEAGE ADMISSION DENIED'}};
  return {...body,digest:digestOf(body)};
}

export function verifyLearningBoundLearningAdmission(record,{admission,attestation}={}){
  if(!record?.digest||record.protocol!=='NSF-35'||record.version!==1)return false;
  const {digest,...body}=record;if(digest!==digestOf(body))return false;
  const expected=record.bindings?.admissionVerified===true&&record.bindings?.executionVerified===true&&record.bindings?.lineageComplete===true&&record.bindings?.lineageConsistent===true;
  if(record.admitted!==expected||record.status!==(expected?'ADMITTED':'DENIED')||record.cap1?.signal!==(expected?'ANCESTOR':'GUARD'))return false;
  if(record.bindings?.learnedExecution===true&&(!record.learningLineageDigest||!record.sourceLearningLedgerHead||record.sourceLearningLedgerSequence<=0))return false;
  if(admission&&record.baseAdmissionDigest!==admission.digest)return false;
  if(attestation){if(!verifyPathwayExecutionAttestation(attestation)||record.executionAttestationDigest!==attestation.digest||record.executionEntryDigest!==attestation.entryDigest||record.executionLedgerHead!==attestation.ledgerHead||record.executionLedgerSequence!==attestation.ledgerSequence||record.sealAdmissionProtocol!==(attestation.sealAdmissionProtocol||'NSF-19')||record.learningLineageDigest!==(attestation.learningLineageDigest||null)||record.sourceLearningLedgerHead!==(attestation.learningLedgerHead||null)||record.sourceLearningLedgerSequence!==Number(attestation.learningLedgerSequence||0))return false;}
  return true;
}
export function learningBoundLearningAdmissionSummary(r){return {protocol:r.protocol,status:r.status,admitted:r.admitted,sealAdmissionProtocol:r.sealAdmissionProtocol,learningLineageDigest:r.learningLineageDigest,sourceLearningLedgerHead:r.sourceLearningLedgerHead,sourceLearningLedgerSequence:r.sourceLearningLedgerSequence,cap1:r.cap1,verified:verifyLearningBoundLearningAdmission(r)};}
