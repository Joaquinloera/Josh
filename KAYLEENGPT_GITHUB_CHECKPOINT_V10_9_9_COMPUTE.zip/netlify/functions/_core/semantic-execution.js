import crypto from 'node:crypto';
import { verifySemanticPlan } from './semantic-plan.js';
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v);}
const digestOf=v=>sha(canonical(v));

export function buildSemanticExecutionContract(plan,{route={},schedule=null}={}){
  if(!verifySemanticPlan(plan,{contextDigest:plan?.contextDigest})) throw new Error('Invalid semantic plan');
  const agents=(route.agents||[]).map(a=>a.id).filter(Boolean).slice(0,3);
  const bindings=plan.subgoals.map((g,i)=>({subgoalId:g.id,kind:g.kind,dependsOn:[...g.dependsOn],required:g.required===true,executor:agents[i%Math.max(agents.length,1)]||route.agent?.id||'native',proofRequired:g.required===true?'VERIFIED_WORK_PRODUCT':'EXECUTION_RECEIPT'}));
  const body={protocol:'NSF-4',planDigest:plan.digest,contextDigest:plan.contextDigest,routeBinding:{host:route.host?.id||null,agents},scheduleDigest:schedule?.digest||null,bindings,successConditions:[...plan.successConditions],cap1:{signal:'PATH',utterance:`STAR PATH EXECUTE ${bindings.length} BIND ${plan.digest.slice(0,16)}`}};
  return {...body,digest:digestOf(body)};
}
export function verifySemanticExecutionContract(contract,{planDigest,scheduleDigest}={}){
  if(!contract||contract.protocol!=='NSF-4'||!contract.digest||!Array.isArray(contract.bindings)||contract.bindings.length<1||contract.bindings.length>6)return false;
  const {digest,...body}=contract;if(digest!==digestOf(body))return false;
  if(planDigest&&contract.planDigest!==planDigest)return false;if(scheduleDigest&&contract.scheduleDigest!==scheduleDigest)return false;
  const ids=new Set();for(const b of contract.bindings){if(ids.has(b.subgoalId))return false;ids.add(b.subgoalId);if(!b.executor||!Array.isArray(b.dependsOn))return false;}
  return contract.successConditions?.includes('verification-status-explicit')===true;
}
export function settleSemanticExecution(contract,{taskGraph,evaluation}={}){
  if(!verifySemanticExecutionContract(contract))throw new Error('Invalid semantic execution contract');
  const products=taskGraph?.products||[], ready=taskGraph?.verification?.consensus==='READY', evaluationReady=evaluation?.consensus==='READY';
  const productDigests=products.map(p=>p.hash).filter(Boolean);
  const results=contract.bindings.map((b,i)=>({subgoalId:b.subgoalId,required:b.required===true,status:(ready&&evaluationReady)?'SATISFIED':'BLOCKED',proof:b.required?(productDigests[i%Math.max(productDigests.length,1)]||null):(taskGraph?.id||null)}));
  const requiredSatisfied=results.filter((r,i)=>contract.bindings[i].required).every(r=>r.status==='SATISFIED'&&Boolean(r.proof));
  const body={protocol:'NSF-4-SETTLEMENT',contractDigest:contract.digest,taskGraphId:taskGraph?.id||null,taskGraphConsensus:taskGraph?.verification?.consensus||'BLOCKED',evaluationConsensus:evaluation?.consensus||'BLOCKED',productDigests,results,requiredSatisfied,cap1:{signal:requiredSatisfied?'WITNESS':'VERIFY',utterance:`STAR ${requiredSatisfied?'WITNESS':'VERIFY'} SETTLE ${contract.digest.slice(0,16)}`}};
  return {...body,digest:digestOf(body)};
}
export function verifySemanticExecutionSettlement(settlement,{contractDigest}={}){
  if(!settlement||settlement.protocol!=='NSF-4-SETTLEMENT'||!settlement.digest)return false;const {digest,...body}=settlement;if(digest!==digestOf(body))return false;if(contractDigest&&settlement.contractDigest!==contractDigest)return false;
  if(settlement.requiredSatisfied&&(!settlement.results?.length||settlement.results.some(r=>r.required===true&&(r.status!=='SATISFIED'||!r.proof))))return false;
  return settlement.cap1?.signal===(settlement.requiredSatisfied?'WITNESS':'VERIFY');
}
export function semanticExecutionSummary(contract,settlement){return {protocol:'NSF-4',contractDigest:contract.digest,bindings:contract.bindings.length,settlementDigest:settlement.digest,status:settlement.requiredSatisfied?'SATISFIED':'BLOCKED',cap1:settlement.cap1.signal};}
