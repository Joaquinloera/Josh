import crypto from 'node:crypto';
import { encodeAgentUtterance, verifyAgentUtterance } from './agent-language.js';

const clip=(v,n=1800)=>String(v??'').trim().slice(0,n);
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');

export function buildTaskGraph({intent='general',route,text=''}){
  const agents=(route?.agents?.length?route.agents:(route?.agent?[route.agent]:[])).slice(0,3);
  const lead=agents[0]||{id:'native',name:'Native Core',role:'orchestration'};
  const reviewer=agents[1]||lead;
  const reconciler=agents[2]||reviewer;
  return {
    id:`graph-${sha(`${intent}:${text}`).slice(0,16)}`,
    intent,
    nodes:[
      {id:'g1',kind:'produce',agentId:lead.id,agentName:lead.name,role:lead.role,dependsOn:[],status:'queued'},
      {id:'g2',kind:'review',agentId:reviewer.id,agentName:reviewer.name,role:reviewer.role,dependsOn:['g1'],status:'queued'},
      {id:'g3',kind:'reconcile',agentId:reconciler.id,agentName:reconciler.name,role:reconciler.role,dependsOn:['g1','g2'],status:'queued'},
    ],
  };
}

function product(node,content,inputHashes=[]){
  const body=clip(content);
  return {nodeId:node.id,agentId:node.agentId,agentName:node.agentName,kind:node.kind,content:body,inputHashes,hash:sha(body),verified:true};
}

export function executeTaskGraph({graph,text,intent,plan=[],toolReceipts=[]}){
  const products=[];
  for(const node of graph.nodes){
    const deps=node.dependsOn.map(id=>products.find(p=>p.nodeId===id)).filter(Boolean);
    const dependenciesReady=node.dependsOn.every(id=>deps.some(p=>p.nodeId===id&&p.verified));
    if(!dependenciesReady){node.status='blocked';continue;}
    let content;
    if(node.kind==='produce') content=`Candidate for ${intent}: ${plan.slice(0,3).map(x=>x.action).join(' | ')} Request: ${clip(text,500)}`;
    else if(node.kind==='review') content=`Review accepted ${deps[0]?.hash?.slice(0,12)}. Checks: bounded plan=${plan.length<=12}; inspected tools=${toolReceipts.every(x=>x.inspected===true)}; request retained=${Boolean(text)}.`;
    else {
      const disagreement=deps.some(p=>/reject|conflict|unsafe/i.test(p.content));
      content=disagreement?`Reconciliation blocked: dependency disagreement detected.`:`Reconciliation accepted ${deps.map(p=>p.hash.slice(0,12)).join(' + ')}; verified handoff chain complete.`;
    }
    const out=product(node,content,deps.map(p=>p.hash));
    const previous=deps.at(-1);
    out.agentUtterance=encodeAgentUtterance({from:node.agentId,to:node.kind==='reconcile'?'native-consensus':(graph.nodes.find(n=>n.dependsOn.includes(node.id))?.agentId||'native-consensus'),kind:node.kind,taskId:graph.id,payloadHash:out.hash,sequence:products.length+1});
    out.agentLanguageVerified=verifyAgentUtterance(out.agentUtterance) && (!previous || out.inputHashes.includes(previous.hash));
    products.push(out);node.status='completed';node.outputHash=out.hash;
  }
  const complete=graph.nodes.every(n=>n.status==='completed')&&products.length===graph.nodes.length;
  const hashesValid=products.every(p=>p.hash===sha(p.content));
  const agentLanguageVerified=products.every(p=>p.agentLanguageVerified===true);
  return {graph,products,verification:{complete,hashesValid,agentLanguageVerified,handoffsVerified:complete&&hashesValid&&agentLanguageVerified,consensus:complete&&hashesValid&&agentLanguageVerified?'READY':'BLOCKED'}};
}
