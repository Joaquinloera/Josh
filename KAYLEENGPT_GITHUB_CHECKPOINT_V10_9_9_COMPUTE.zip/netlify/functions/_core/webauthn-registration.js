import crypto from 'node:crypto';
const b64u = b => Buffer.from(b).toString('base64url');
const unb64u = s => Buffer.from(s, 'base64url');
const safeEq = (a,b) => { try { const x=Buffer.from(a), y=Buffer.from(b); return x.length===y.length && crypto.timingSafeEqual(x,y); } catch { return false; } };
function verifyClientData(clientDataB64, expectedChallenge, expectedType, origin){ const raw=unb64u(clientDataB64); const data=JSON.parse(raw.toString('utf8')); if(data.type!==expectedType||data.challenge!==expectedChallenge||data.origin!==origin) throw new Error('WEBAUTHN_CLIENT_DATA_INVALID'); return raw; }

function cborRead(buf, offset=0){
  if(offset>=buf.length) throw new Error('WEBAUTHN_CBOR_INVALID');
  const first=buf[offset++], major=first>>5, ai=first&31;
  let n;
  if(ai<24)n=ai; else if(ai===24){n=buf[offset++];} else if(ai===25){n=buf.readUInt16BE(offset);offset+=2;} else if(ai===26){n=buf.readUInt32BE(offset);offset+=4;} else throw new Error('WEBAUTHN_CBOR_UNSUPPORTED');
  if(major===0)return {value:n,offset};
  if(major===1)return {value:-1-n,offset};
  if(major===2){const end=offset+n;if(end>buf.length)throw new Error('WEBAUTHN_CBOR_INVALID');return {value:buf.subarray(offset,end),offset:end};}
  if(major===3){const end=offset+n;if(end>buf.length)throw new Error('WEBAUTHN_CBOR_INVALID');return {value:buf.subarray(offset,end).toString('utf8'),offset:end};}
  if(major===4){const a=[];for(let i=0;i<n;i++){const r=cborRead(buf,offset);a.push(r.value);offset=r.offset;}return {value:a,offset};}
  if(major===5){const m=new Map();for(let i=0;i<n;i++){let r=cborRead(buf,offset);const k=r.value;offset=r.offset;r=cborRead(buf,offset);m.set(k,r.value);offset=r.offset;}return {value:m,offset};}
  throw new Error('WEBAUTHN_CBOR_UNSUPPORTED');
}

function coseEs256ToSpki(cose){
  if(!(cose instanceof Map)||cose.get(1)!==2||cose.get(3)!==-7||cose.get(-1)!==1) throw new Error('WEBAUTHN_KEY_UNSUPPORTED');
  const x=cose.get(-2), y=cose.get(-3);
  if(!Buffer.isBuffer(x)||!Buffer.isBuffer(y)||x.length!==32||y.length!==32) throw new Error('WEBAUTHN_KEY_INVALID');
  const key=crypto.createPublicKey({key:{kty:'EC',crv:'P-256',x:b64u(x),y:b64u(y)},format:'jwk'});
  return key.export({format:'der',type:'spki'});
}

export function verifyRegistration({clientDataJSON,attestationObject,credentialId,publicKeySpki,challenge,origin,rp}){
  verifyClientData(clientDataJSON,challenge,'webauthn.create',origin);
  const att=cborRead(unb64u(attestationObject)).value;
  if(!(att instanceof Map)) throw new Error('WEBAUTHN_ATTESTATION_INVALID');
  const auth=att.get('authData');
  if(!Buffer.isBuffer(auth)||auth.length<55) throw new Error('WEBAUTHN_AUTH_DATA_INVALID');
  const rpHash=crypto.createHash('sha256').update(rp).digest();
  if(!crypto.timingSafeEqual(auth.subarray(0,32),rpHash)) throw new Error('WEBAUTHN_RP_INVALID');
  const flags=auth[32];
  if((flags&0x01)===0||(flags&0x04)===0||(flags&0x40)===0) throw new Error('WEBAUTHN_REGISTRATION_FLAGS_INVALID');
  let off=37+16;
  if(off+2>auth.length) throw new Error('WEBAUTHN_AUTH_DATA_INVALID');
  const credLen=auth.readUInt16BE(off); off+=2;
  if(credLen<1||off+credLen>auth.length) throw new Error('WEBAUTHN_CREDENTIAL_INVALID');
  const cred=auth.subarray(off,off+credLen); off+=credLen;
  if(!safeEq(cred,unb64u(credentialId))) throw new Error('WEBAUTHN_CREDENTIAL_MISMATCH');
  const parsed=cborRead(auth,off);
  const derivedSpki=coseEs256ToSpki(parsed.value);
  if(publicKeySpki&&!safeEq(derivedSpki,unb64u(publicKeySpki))) throw new Error('WEBAUTHN_PUBLIC_KEY_MISMATCH');
  return {credentialId:b64u(cred),publicKeySpki:b64u(derivedSpki),signCount:auth.readUInt32BE(33)};
}
