import crypto from 'node:crypto';
import { verifyLearningBoundLearningFulfillment } from './learning-bound-learning-fulfillment.js';
import { verifyPathwayLearningLedger } from './pathway-learning-ledger.js';
import { verifyPathwayLearningAttestation } from './pathway-learning-attestation.js';
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v)}
const digestOf=v=>sha(canonical(v));
export const LEARNING_BOUND_DURABLE_LEARNING=Object.freeze({protocol:'NSF-37',version:1,mode:'learning-lineage-bound-durable-learning',failClosed:true});
export function buildLearningBoundDurableLearning({fulfillment,ledger,attestation}){
 const fulfillmentVerified=verifyLearningBoundLearningFulfillment(fulfillment),ledgerVerified=verifyPathwayLearningLedger(ledger),attestationVerified=verifyPathwayLearningAttestation(attestation);
 const entry=ledgerVerified&&attestation?.entryDigest?ledger.entries.find(e=>e.digest===attestation.entryDigest):null;
 const bindings={fulfillmentVerified,ledgerVerified,attestationVerified,entryPresent:!!entry,fulfillmentBound:!!entry&&entry.learningBoundFulfillmentDigest===fulfillment?.digest&&entry.fulfillmentDigest===fulfillment?.baseFulfillmentDigest,receiptBound:!!entry&&entry.receiptHash===fulfillment?.receiptHash,pathwayBound:!!entry&&entry.pathwayKey===fulfillment?.pathwayKey,lineageBound:!!entry&&entry.learningLineageDigest===fulfillment?.learningLineageDigest&&entry.sourceLearningLedgerHead===fulfillment?.sourceLearningLedgerHead&&Number(entry.sourceLearningLedgerSequence)===Number(fulfillment?.sourceLearningLedgerSequence),headBound:!!entry&&attestation?.ledgerHead===ledger?.head&&Number(attestation?.ledgerSequence)===Number(ledger?.sequence)};
 const verified=Object.values(bindings).every(Boolean);
 const body={protocol:'NSF-37',version:1,status:verified?'ATTESTED':'DENIED',verified,learningBoundFulfillmentDigest:fulfillment?.digest||null,durableEntryDigest:entry?.digest||null,durableLearningLedgerHead:ledger?.head||null,durableLearningLedgerSequence:Number(ledger?.sequence||0),learningStateAttestationDigest:attestation?.digest||null,pathwayKey:fulfillment?.pathwayKey||null,learningLineageDigest:fulfillment?.learningLineageDigest||null,sourceLearningLedgerHead:fulfillment?.sourceLearningLedgerHead||null,sourceLearningLedgerSequence:Number(fulfillment?.sourceLearningLedgerSequence||0),bindings,cap1:{signal:verified?'ANCESTOR':'GUARD',utterance:verified?'STAR ANCESTOR LEARNING-LINEAGE DURABLY ATTESTED':'STAR GUARD DURABLE LEARNING-LINEAGE DENIED'}};
 return {...body,digest:digestOf(body)};
}
export function verifyLearningBoundDurableLearning(r){if(!r?.digest||r.protocol!=='NSF-37'||r.version!==1)return false;const {digest,...body}=r;return digest===digestOf(body)&&r.verified===true&&Object.values(r.bindings||{}).every(Boolean);}
export function learningBoundDurableLearningSummary(r){return {protocol:r?.protocol||'NSF-37',status:r?.status||'DENIED',verified:!!r?.verified,pathwayKey:r?.pathwayKey||null,learningLineageDigest:r?.learningLineageDigest||null,durableLearningLedgerHead:r?.durableLearningLedgerHead||null,durableLearningLedgerSequence:r?.durableLearningLedgerSequence||0,cap1:r?.cap1||null,digest:r?.digest||null};}
