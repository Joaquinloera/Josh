import { MAX_MESSAGE_CHARS, MAX_MESSAGES } from "./config.js";

const VALID_ROLES = new Set(["user", "assistant"]);

export function cleanMessages(messages) {
  if (!Array.isArray(messages)) return [];

  return messages
    .slice(-MAX_MESSAGES)
    .map((message) => {
      const role = VALID_ROLES.has(message?.role) ? message.role : "user";
      const content = String(message?.content ?? "").slice(0, MAX_MESSAGE_CHARS).trim();
      return { role, content };
    })
    .filter((message) => message.content);
}

export function latestUserMessage(messages) {
  for (let i = messages.length - 1; i >= 0; i -= 1) {
    if (messages[i]?.role === "user") return messages[i].content;
  }
  return "";
}

export function validateConversation(messages) {
  if (!messages.length) return "A message is required.";
  if (messages.at(-1)?.role !== "user") return "Last message must be from the user.";
  return null;
}
