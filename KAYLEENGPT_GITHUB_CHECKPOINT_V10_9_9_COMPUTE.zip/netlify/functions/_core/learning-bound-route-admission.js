import crypto from 'node:crypto';
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v)}
const digestOf=v=>sha(canonical(v));
export const LEARNING_BOUND_ROUTE_ADMISSION=Object.freeze({protocol:'NSF-31',version:1,mode:'learning-lineage-bound-route-admission',failClosed:true});
export function buildLearningBoundRouteAdmission({routeAdmission,learningRouteAttestation,selection,explicitRoute=false}={}){
 const learned=selection?.selected?.source==='learned'||selection?.route?.source==='learned'||routeAdmission?.learned===true;
 const selected={host:selection?.selected?.host||selection?.route?.host?.id||null,agent:selection?.selected?.agent||selection?.route?.agent?.id||null,source:selection?.selected?.source||selection?.route?.source||'base'};
 const keyCandidates=Object.entries(learningRouteAttestation?.decisions||{}).filter(([,d])=>d?.eligible).map(([k])=>k);
 const routeAdmissionVerified=routeAdmission?.protocol==='NSF-19'&&routeAdmission?.admitted===true&&!!routeAdmission?.digest;
 const learningAttestationVerified=learningRouteAttestation?.protocol==='NSF-30'&&learningRouteAttestation?.ledgerVerified===true&&!!learningRouteAttestation?.digest;
 const learnedEligible=!learned||keyCandidates.some(k=>{const parts=k.split('|');return (!selected.host||parts.includes(selected.host))&&(!selected.agent||parts.includes(selected.agent));});
 const admitted=Boolean(routeAdmissionVerified&&(explicitRoute||!learned||(learningAttestationVerified&&learnedEligible)));
 const mode=explicitRoute?'EXPLICIT':learned?(admitted?'LEARNED-LINEAGE-BOUND':'LEARNED-LINEAGE-DENIED'):'BASE';
 const body={protocol:'NSF-31',version:1,routeAdmissionDigest:routeAdmission?.digest||null,learningRouteAttestationDigest:learningRouteAttestation?.digest||null,learningLedgerHead:learningRouteAttestation?.ledgerHead||null,learningLedgerSequence:learningRouteAttestation?.ledgerSequence??0,routeAdmissionVerified,learningAttestationVerified,learnedEligible,learned,explicitRoute:Boolean(explicitRoute),selected,mode,admitted,cap1:{signal:admitted?'WITNESS':'GUARD',utterance:`STAR ${admitted?'WITNESS':'GUARD'} LEARNING-LINEAGE ROUTE ${mode}`}};
 return {...body,digest:digestOf(body)};
}
export function verifyLearningBoundRouteAdmission(a,{routeAdmissionDigest=null,learningRouteAttestationDigest=null}={}){if(!a?.digest||a.protocol!=='NSF-31'||a.version!==1)return false;const {digest,...body}=a;if(digest!==digestOf(body))return false;if(routeAdmissionDigest&&a.routeAdmissionDigest!==routeAdmissionDigest)return false;if(learningRouteAttestationDigest&&a.learningRouteAttestationDigest!==learningRouteAttestationDigest)return false;const expected=Boolean(a.routeAdmissionVerified&&(a.explicitRoute||!a.learned||(a.learningAttestationVerified&&a.learnedEligible)));return a.admitted===expected&&a.mode===(a.explicitRoute?'EXPLICIT':a.learned?(expected?'LEARNED-LINEAGE-BOUND':'LEARNED-LINEAGE-DENIED'):'BASE');}
export function learningBoundRouteAdmissionSummary(a){return {protocol:'NSF-31',verified:verifyLearningBoundRouteAdmission(a),mode:a?.mode||null,admitted:!!a?.admitted,learned:!!a?.learned,learnedEligible:!!a?.learnedEligible,learningLedgerHead:a?.learningLedgerHead||null,cap1:a?.cap1||null,digest:a?.digest||null};}
