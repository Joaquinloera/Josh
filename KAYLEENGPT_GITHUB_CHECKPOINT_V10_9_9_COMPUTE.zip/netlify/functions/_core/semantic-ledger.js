import crypto from 'node:crypto';
import { verifySemanticFeedback } from './semantic-feedback.js';
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v);}
const digestOf=v=>sha(canonical(v));
const FILTER_BYTES=512,FILTER_HASHES=6;
const blankFilter=()=>Buffer.alloc(FILTER_BYTES);
function decodeFilter(s){if(!s)return blankFilter();try{const b=Buffer.from(s,'base64');return b.length===FILTER_BYTES?b:null;}catch{return null;}}
function positions(d){const h=crypto.createHash('sha256').update(String(d)).digest();const out=[];for(let i=0;i<FILTER_HASHES;i++){const a=h.readUInt32BE((i*4)%28),b=h.readUInt32BE(((i*4)+4)%28);out.push((a+i*b+i*i)% (FILTER_BYTES*8));}return out;}
function addFilter(buf,d){for(const p of positions(d))buf[p>>3]|=1<<(p&7);}
function hasFilter(buf,d){return positions(d).every(p=>(buf[p>>3]&(1<<(p&7)))!==0);}
export function emptySemanticLedger(){return {protocol:'NSF-8',sequence:0,head:null,anchor:null,entries:[]};}
function verifyAnchor(a){if(a===null)return true;if(!a||a.protocol!=='NSF-8-CHECKPOINT'||!a.digest)return false;const {digest,...body}=a;const f=decodeFilter(a.replayFilter);return !!f&&digest===digestOf(body)&&Number.isInteger(a.throughSequence)&&a.throughSequence>0&&typeof a.throughDigest==='string'&&a.throughDigest.length===64&&Number.isInteger(a.archivedEntries)&&a.archivedEntries>0&&a.filterBytes===FILTER_BYTES&&a.filterHashes===FILTER_HASHES;}
export function verifySemanticLedger(ledger){
 if(!ledger||ledger.protocol!=='NSF-8'||!Number.isInteger(ledger.sequence)||ledger.sequence<0||!Array.isArray(ledger.entries)||!verifyAnchor(ledger.anchor))return false;
 let prev=ledger.anchor?.throughDigest||null,seq=ledger.anchor?.throughSequence||0;const seen=new Set();
 for(const e of ledger.entries){if(!e||e.protocol!=='NSF-8'||!e.digest)return false;const {digest,...body}=e;if(digest!==digestOf(body))return false;if(e.sequence!==++seq||e.previousDigest!==prev||seen.has(e.feedbackDigest))return false;if(!['REINFORCE','OBSERVE','NO_REINFORCEMENT'].includes(e.action)||e.reinforce!==(e.action==='REINFORCE'))return false;seen.add(e.feedbackDigest);prev=e.digest;}
 return ledger.sequence===seq&&ledger.head===prev&&(ledger.sequence===0?ledger.head===null:true);
}
export function archivedReplayPossible(ledger,feedbackDigest){if(!verifySemanticLedger(ledger))throw new Error('Invalid semantic ledger');const f=decodeFilter(ledger.anchor?.replayFilter);return ledger.anchor?hasFilter(f,feedbackDigest):false;}
export function compactSemanticLedger(ledgerInput,{retain=48}={}){
 const ledger=structuredClone(ledgerInput);if(!verifySemanticLedger(ledger))throw new Error('Invalid semantic ledger');if(!Number.isInteger(retain)||retain<1)throw new Error('Invalid semantic ledger retention');if(ledger.entries.length<=retain)return {ledger,compacted:false,anchor:ledger.anchor};
 const cut=ledger.entries.length-retain,last=ledger.entries[cut-1],prior=ledger.anchor,filter=decodeFilter(prior?.replayFilter);for(const e of ledger.entries.slice(0,cut))addFilter(filter,e.feedbackDigest);
 const body={protocol:'NSF-8-CHECKPOINT',throughSequence:last.sequence,throughDigest:last.digest,archivedEntries:(prior?.archivedEntries||0)+cut,previousAnchorDigest:prior?.digest||null,firstArchivedSequence:prior?prior.throughSequence+1:1,lastArchivedSequence:last.sequence,archiveDigest:digestOf(ledger.entries.slice(0,cut).map(e=>e.digest)),replayFilter:filter.toString('base64'),filterBytes:FILTER_BYTES,filterHashes:FILTER_HASHES,cap1:{signal:'ANCESTOR',utterance:`STAR ANCESTOR REPLAY-GUARD ${last.digest.slice(0,16)}`}};
 const anchor={...body,digest:digestOf(body)},next={protocol:'NSF-8',sequence:ledger.sequence,head:ledger.head,anchor,entries:ledger.entries.slice(cut)};if(!verifySemanticLedger(next))throw new Error('Semantic ledger compaction verification failed');return {ledger:next,compacted:true,anchor};
}
export function commitSemanticFeedback(ledgerInput,feedback,{maxEntries=96,retain=48}={}){
 if(!verifySemanticFeedback(feedback))throw new Error('Invalid semantic feedback');let ledger=ledgerInput?structuredClone(ledgerInput):emptySemanticLedger();if(!verifySemanticLedger(ledger))throw new Error('Invalid semantic ledger');
 if(ledger.entries.some(e=>e.feedbackDigest===feedback.digest)||archivedReplayPossible(ledger,feedback.digest))throw new Error('Semantic feedback replay rejected');if(ledger.entries.length>=maxEntries)ledger=compactSemanticLedger(ledger,{retain}).ledger;if(archivedReplayPossible(ledger,feedback.digest))throw new Error('Semantic feedback replay rejected');
 const body={protocol:'NSF-8',sequence:ledger.sequence+1,previousDigest:ledger.head,feedbackDigest:feedback.digest,outcomeDigest:feedback.outcomeDigest,learningReceiptHash:feedback.learningReceiptHash||null,action:feedback.action,reinforce:feedback.reinforce===true,cap1:{signal:feedback.reinforce?'ANCESTOR':feedback.action==='OBSERVE'?'WITNESS':'VERIFY',utterance:`STAR ${feedback.reinforce?'ANCESTOR':feedback.action==='OBSERVE'?'WITNESS':'VERIFY'} LEDGER ${feedback.digest.slice(0,16)}`}};
 const entry={...body,digest:digestOf(body)},next={...ledger,sequence:body.sequence,head:entry.digest,entries:[...ledger.entries,entry]};if(!verifySemanticLedger(next))throw new Error('Semantic ledger commit verification failed');return {ledger:next,entry};
}
export function semanticLedgerSummary(ledger){return {protocol:'NSF-8',sequence:ledger.sequence,head:ledger.head,entries:ledger.entries.length,archived:ledger.anchor?.archivedEntries||0,anchorDigest:ledger.anchor?.digest||null,replayShieldProtocol:'NSF-9',replayShield:ledger.anchor?'BLOOM-4096x6':'EMPTY',reinforced:ledger.entries.filter(e=>e.reinforce).length,blocked:ledger.entries.filter(e=>e.action==='NO_REINFORCEMENT').length};}
