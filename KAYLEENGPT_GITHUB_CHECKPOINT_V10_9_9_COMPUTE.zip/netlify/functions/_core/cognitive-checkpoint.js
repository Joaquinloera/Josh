import crypto from 'node:crypto';
const POLICY=Object.freeze({protocol:'BCC-1',schema:1,maxCheckpoints:64,maxReplayNonces:128,states:['PREPARED','COMPLETED','FAILED'],rollback:'LAST_VERIFIED'});
const stable=v=>JSON.stringify(v,Object.keys(v).sort());
const hash=v=>crypto.createHash('sha256').update(typeof v==='string'?v:stable(v)).digest('hex');
export function checkpointPolicy(){return {...POLICY,states:[...POLICY.states]};}
export function createCognitiveCheckpoint({taskId=null,request='',intent='general',sequence=1,phase='PREPARED',scheduleDigest='',routingReceiptHash='',parentHash=null,nonce=null,state={}}={}){
 const body={protocol:POLICY.protocol,schema:POLICY.schema,taskId:taskId||crypto.randomUUID(),requestHash:hash(request),intent,sequence:Number(sequence)||1,phase:POLICY.states.includes(phase)?phase:'FAILED',scheduleDigest:String(scheduleDigest||''),routingReceiptHash:String(routingReceiptHash||''),parentHash:parentHash||null,nonce:nonce||crypto.randomBytes(32).toString('hex'),state,createdAt:Date.now()};
 return {...body,checkpointHash:hash(body)};
}
export function verifyCognitiveCheckpoint(cp,{expectedParentHash=undefined,seenNonces=[]}={}){if(!cp||cp.protocol!==POLICY.protocol||cp.schema!==1||!POLICY.states.includes(cp.phase)||!/^[a-f0-9]{64}$/.test(cp.nonce||''))return false; if(seenNonces.includes(cp.nonce))return false; if(expectedParentHash!==undefined&&cp.parentHash!==expectedParentHash)return false; const {checkpointHash,...body}=cp; return checkpointHash===hash(body);}
export function selectRecoveryCheckpoint(checkpoints=[]){const seen=[];let parent=null,last=null;for(const cp of checkpoints){if(!verifyCognitiveCheckpoint(cp,{expectedParentHash:parent,seenNonces:seen}))break;seen.push(cp.nonce);parent=cp.checkpointHash;if(cp.phase==='PREPARED'||cp.phase==='COMPLETED')last=cp;}return last;}
export function buildExecutionLineage(checkpoints=[]){const valid=[];const seen=[];let parent=null;for(const cp of checkpoints){if(!verifyCognitiveCheckpoint(cp,{expectedParentHash:parent,seenNonces:seen}))break;valid.push(cp.checkpointHash);seen.push(cp.nonce);parent=cp.checkpointHash;}return {protocol:POLICY.protocol,verified:valid.length===checkpoints.length,count:valid.length,head:valid.at(-1)||null,hash:hash(valid.join(':'))};}
