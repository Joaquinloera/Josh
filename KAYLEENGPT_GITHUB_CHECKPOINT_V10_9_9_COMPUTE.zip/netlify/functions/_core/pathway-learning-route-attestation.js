import crypto from 'node:crypto';
import { verifyPathwayLearningLedger } from './pathway-learning-ledger.js';
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v)}
const digestOf=v=>sha(canonical(v));
export const PATHWAY_LEARNING_ROUTE_ATTESTATION=Object.freeze({protocol:'NSF-30',version:1,mode:'verified-learning-route-eligibility',failClosed:true});
export function buildPathwayLearningRouteAttestation({pathways={},ledger}={}){
 const safeLedger=ledger||{protocol:'NSF-27',version:1,sequence:0,head:null,anchor:null,entries:[]};
 const ledgerVerified=verifyPathwayLearningLedger(safeLedger), entries=ledgerVerified?(safeLedger.entries||[]):[];
 const decisions={},eligiblePathways={};
 for(const key of Object.keys(pathways||{}).sort()){
  const p=pathways[key]||{}, entry=entries.find(e=>e.digest===p.lastLearningCommitDigest&&e.pathwayKey===key);
  const checks={ledgerVerified,commitPresent:!!entry,commitMatches:!!entry&&entry.digest===p.lastLearningCommitDigest,receiptMatches:!!entry&&entry.receiptHash===p.lastReceiptHash,strengthMatches:!!entry&&Number(entry.resultingStrength)===Number(p.strength),sequenceBound:!!entry&&entry.sequence<=safeLedger.sequence};
  const eligible=Object.values(checks).every(Boolean);
  decisions[key]={eligible,entryDigest:entry?.digest||null,receiptHash:p.lastReceiptHash||null,strength:p.strength??null,checks};
  if(eligible) eligiblePathways[key]=p;
 }
 const body={protocol:'NSF-30',version:1,ledgerVerified,ledgerHead:safeLedger.head||null,ledgerSequence:safeLedger.sequence??0,anchorDigest:safeLedger.anchor?.digest||null,pathwayCount:Object.keys(pathways||{}).length,eligibleCount:Object.keys(eligiblePathways).length,decisions,cap1:{signal:ledgerVerified?'WITNESS':'GUARD',utterance:ledgerVerified?'STAR WITNESS LEARNING-LINEAGE ROUTE-ELIGIBLE':'STAR GUARD LEARNING-LINEAGE REJECTED'}};
 const attestation={...body,digest:digestOf(body)};
 return {attestation,eligiblePathways};
}
export function verifyPathwayLearningRouteAttestation(attestation,{pathways={},ledger}={}){
 if(!attestation||attestation.protocol!=='NSF-30'||attestation.version!==1||!attestation.digest)return false;
 const {digest,...body}=attestation;if(digest!==digestOf(body)||attestation.ledgerVerified!==true)return false;
 if(ledger){const expected=buildPathwayLearningRouteAttestation({pathways,ledger}).attestation;return expected.digest===attestation.digest;}
 return true;
}
export function pathwayLearningRouteAttestationSummary(a){return {protocol:'NSF-30',verified:!!a?.ledgerVerified,ledgerHead:a?.ledgerHead||null,ledgerSequence:a?.ledgerSequence??0,pathwayCount:a?.pathwayCount??0,eligibleCount:a?.eligibleCount??0,cap1:a?.cap1||null,digest:a?.digest||null};}
