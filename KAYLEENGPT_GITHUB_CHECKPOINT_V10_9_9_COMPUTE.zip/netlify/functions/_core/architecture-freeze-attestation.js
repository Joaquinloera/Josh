import crypto from 'node:crypto';
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v)}
const digestOf=v=>sha(canonical(v));
export const ARCHITECTURE_FREEZE_ATTESTATION=Object.freeze({protocol:'NSF-38',version:1,mode:'end-to-end-learning-execution-lineage-freeze',failClosed:true});
export function buildArchitectureFreezeAttestation({routeAdmission,executionSeal,executionFulfillment,executionAttestation,learningAdmission,learningFulfillment,durableLearning}){
 const learned=routeAdmission?.learned===true&&!routeAdmission?.explicitRoute;
 const lineage=routeAdmission?.learningRouteAttestationDigest||null;
 const sourceHead=routeAdmission?.learningLedgerHead||null;
 const sourceSeq=Number(routeAdmission?.learningLedgerSequence??0);
 const bindings={
  routeAdmission:routeAdmission?.protocol==='NSF-31'&&routeAdmission?.admitted===true,
  executionSeal:executionSeal?.protocol==='NSF-20'&&executionSeal?.authorized===true&&executionSeal?.admissionDigest===routeAdmission?.digest,
  executionFulfillment:executionFulfillment?.protocol==='NSF-21'&&executionFulfillment?.fulfilled===true&&executionFulfillment?.sealDigest===executionSeal?.digest,
  executionAttestation:executionAttestation?.protocol==='NSF-24'&&executionAttestation?.verified===true,
  learningAdmission:learningAdmission?.protocol==='NSF-35'&&learningAdmission?.admitted===true&&learningAdmission?.executionAttestationDigest===executionAttestation?.digest,
  learningFulfillment:learningFulfillment?.protocol==='NSF-36'&&learningFulfillment?.fulfilled===true&&learningFulfillment?.admissionDigest===learningAdmission?.digest,
  durableLearning:durableLearning?.protocol==='NSF-37'&&durableLearning?.verified===true&&durableLearning?.learningBoundFulfillmentDigest===learningFulfillment?.digest,
  lineageContinuous:!learned||[executionSeal,executionFulfillment,learningAdmission,learningFulfillment,durableLearning].every(x=>x?.learningLineageDigest===lineage),
  sourceContinuous:!learned||[executionSeal,executionFulfillment,learningAdmission,learningFulfillment,durableLearning].every(x=>(x?.sourceLearningLedgerHead??x?.learningLedgerHead)===sourceHead&&Number(x?.sourceLearningLedgerSequence??x?.learningLedgerSequence??0)===sourceSeq)
 };
 const verified=Object.values(bindings).every(Boolean);
 const body={protocol:'NSF-38',version:1,status:verified?'FROZEN':'DENIED',verified,learnedRoute:learned,routeAdmissionDigest:routeAdmission?.digest||null,executionSealDigest:executionSeal?.digest||null,executionFulfillmentDigest:executionFulfillment?.digest||null,executionAttestationDigest:executionAttestation?.digest||null,learningAdmissionDigest:learningAdmission?.digest||null,learningFulfillmentDigest:learningFulfillment?.digest||null,durableLearningDigest:durableLearning?.digest||null,learningLineageDigest:lineage,sourceLearningLedgerHead:sourceHead,sourceLearningLedgerSequence:sourceSeq,bindings,cap1:{signal:verified?'ANCESTOR':'GUARD',utterance:verified?'STAR ANCESTOR END-TO-END LINEAGE FROZEN':'STAR GUARD ARCHITECTURE FREEZE DENIED'}};
 return {...body,digest:digestOf(body)};
}
export function verifyArchitectureFreezeAttestation(r){if(!r?.digest||r.protocol!=='NSF-38'||r.version!==1)return false;const {digest,...body}=r;return digest===digestOf(body)&&r.verified===true&&Object.values(r.bindings||{}).every(Boolean);}
export function architectureFreezeSummary(r){return {protocol:r?.protocol||'NSF-38',status:r?.status||'DENIED',verified:!!r?.verified,learnedRoute:!!r?.learnedRoute,learningLineageDigest:r?.learningLineageDigest||null,sourceLearningLedgerHead:r?.sourceLearningLedgerHead||null,sourceLearningLedgerSequence:r?.sourceLearningLedgerSequence||0,cap1:r?.cap1||null,digest:r?.digest||null};}
