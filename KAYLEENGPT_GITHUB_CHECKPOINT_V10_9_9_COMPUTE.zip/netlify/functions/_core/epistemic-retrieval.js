import crypto from 'node:crypto';
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
const toks=s=>new Set(String(s||'').toLowerCase().match(/[a-z0-9]{2,}/g)||[]);
export const RETRIEVAL_PROTOCOL='CKG-4';
const weight={KNOWN:1,DISPUTED:.45,CANDIDATE:.25,SUPERSEDED:.05,REJECTED:0};
const terms=e=>`${e?.claim?.subject||''} ${e?.claim?.predicate||''} ${e?.claim?.object||''} ${e?.claim?.evidence||''}`;
function relevance(query,e){const q=toks(query),t=toks(terms(e));if(!q.size)return 0;let hits=0;for(const x of q)if(t.has(x))hits++;return hits/q.size;}
export function assembleEpistemicRetrieval(ledger,query,{limit=6}={}){
 const established=ledger?.established||[], rejected=ledger?.rejected||[];
 const all=[...established,...rejected];
 const latest=new Map(); for(const e of all){const prior=latest.get(e.claimId);if(!prior||Number(e.sequence||0)>Number(prior.sequence||0))latest.set(e.claimId,e);}
 const active=[...latest.values()];
 const ranked=active.map(e=>({entry:e,relevance:relevance(query,e),stateWeight:weight[e.status]??0})).map(x=>({...x,score:Number((x.relevance*x.stateWeight).toFixed(4))})).sort((a,b)=>b.score-a.score||Number(b.entry.sequence||0)-Number(a.entry.sequence||0));
 const known=ranked.filter(x=>x.entry.status==='KNOWN'&&x.score>0).slice(0,limit);
 const disputed=ranked.filter(x=>x.entry.status==='DISPUTED'&&x.relevance>0).slice(0,limit);
 const superseded=ranked.filter(x=>x.entry.status==='SUPERSEDED'&&x.relevance>0).slice(0,limit);
 const excludedRejected=ranked.filter(x=>x.entry.status==='REJECTED'&&x.relevance>0).map(x=>x.entry.claimId);
 const context=known.map(x=>({id:x.entry.claimId,status:'KNOWN',score:x.score,claim:x.entry.claim,cap1:x.entry.cap1,ledgerDigest:x.entry.digest}));
 const verificationQueue=disputed.map(x=>({id:x.entry.claimId,status:'DISPUTED',reason:'VERIFY_BEFORE_USE',cap1:'CAP1:VERIFY',ledgerDigest:x.entry.digest,claim:x.entry.claim}));
 const payload={protocol:RETRIEVAL_PROTOCOL,queryDigest:sha(query),context,verificationQueue,excludedRejected,superseded:superseded.map(x=>({id:x.entry.claimId,supersededBy:x.entry.supersededBy||null,cap1:'CAP1:ANCESTOR'})),policy:{KNOWN:'PRIORITIZE',DISPUTED:'VERIFY',REJECTED:'EXCLUDE',SUPERSEDED:'DEPRIORITIZE'}};
 return {...payload,digest:sha(JSON.stringify(payload))};
}
export function verifyEpistemicRetrieval(r){if(r?.protocol!==RETRIEVAL_PROTOCOL)return false;const {digest,...payload}=r;if(digest!==sha(JSON.stringify(payload)))return false;return (r.context||[]).every(x=>x.status==='KNOWN')&&(r.verificationQueue||[]).every(x=>x.status==='DISPUTED')&&!new Set(r.context.map(x=>x.id)).has(r.excludedRejected?.[0]);}
