import crypto from 'node:crypto';
import { openJoshStore } from './blob-store.js';

const STORE='joshgpt-auth-throttle-v1';
const POLICIES=Object.freeze({
  login:{limit:8,windowMs:15*60*1000,blockMs:15*60*1000},
  'passkey-options':{limit:12,windowMs:15*60*1000,blockMs:15*60*1000},
  'passkey-login':{limit:8,windowMs:15*60*1000,blockMs:15*60*1000},
  signup:{limit:5,windowMs:60*60*1000,blockMs:60*60*1000}
});
const digest=s=>crypto.createHash('sha256').update(String(s)).digest('hex');
function clientHint(req){
  // Netlify/CDN supplied address is used only as a throttling hint; email remains part of the key.
  return req.headers.get('x-nf-client-connection-ip')||req.headers.get('x-forwarded-for')?.split(',')[0]?.trim()||'unknown';
}
function keyFor(req,action,email){return `attempt/${action}/${digest(`${String(email||'').toLowerCase()}|${clientHint(req)}`)}`;}
export async function authThrottleCheck(req,action,email){
  const policy=POLICIES[action]; if(!policy)return {allowed:true,retryAfter:0};
  const store=openJoshStore(STORE),key=keyFor(req,action,email),now=Date.now();
  const state=await store.get(key,{type:'json'});
  if(state?.blockedUntil>now)return {allowed:false,retryAfter:Math.max(1,Math.ceil((state.blockedUntil-now)/1000))};
  return {allowed:true,retryAfter:0};
}
export async function authThrottleFailure(req,action,email){
  const policy=POLICIES[action]; if(!policy)return;
  const store=openJoshStore(STORE),key=keyFor(req,action,email),now=Date.now();
  let state=await store.get(key,{type:'json'});
  if(!state||now-state.windowStarted>=policy.windowMs)state={windowStarted:now,count:0,blockedUntil:0};
  state.count=Number(state.count||0)+1;
  if(state.count>=policy.limit)state.blockedUntil=now+policy.blockMs;
  await store.setJSON(key,{schema:1,windowStarted:state.windowStarted,count:state.count,blockedUntil:state.blockedUntil,updatedAt:now});
}
export async function authThrottleSuccess(req,action,email){
  if(!POLICIES[action])return;
  await openJoshStore(STORE).delete(keyFor(req,action,email));
}
export function authThrottleResponse(retryAfter){return new Response(JSON.stringify({ok:false,error:'Too many authentication attempts. Try again later.'}),{status:429,headers:{'content-type':'application/json','cache-control':'no-store','retry-after':String(Math.max(1,retryAfter||1))}});}
export const AUTH_THROTTLE_POLICIES=POLICIES;
