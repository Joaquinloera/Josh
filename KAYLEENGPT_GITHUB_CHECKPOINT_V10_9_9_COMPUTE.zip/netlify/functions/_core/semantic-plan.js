import crypto from 'node:crypto';
import { verifySemanticContext } from './semantic-context.js';

function sha(v){return crypto.createHash('sha256').update(String(v)).digest('hex');}
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v);}
function unique(xs,limit){return [...new Set(xs.filter(Boolean))].slice(0,limit);}

const PLAYBOOKS={
  BUILD:['define-target','design-change','implement-bounded-change','verify-result'],
  VERIFY:['identify-claim','collect-evidence','challenge-claim','resolve-status'],
  RESEARCH:['define-question','retrieve-evidence','compare-evidence','synthesize-findings'],
  WRITE:['identify-audience','shape-message','draft-output','review-output'],
  PLAN:['define-goal','identify-dependencies','order-actions','define-success'],
  GENERAL:['interpret-goal','gather-context','execute-best-path','verify-result']
};

function goalFrom(context){
  const s=context.state, f=context.frame;
  const concepts=s.resolvedConcepts.slice(0,6).join(', ');
  if(s.dialogueAct==='CONTINUE')return `Continue the verified prior objective${concepts?` involving ${concepts}`:''}.`;
  if(s.dialogueAct==='CORRECT')return `Revise the referenced objective using the user's correction${concepts?` for ${concepts}`:''}.`;
  return `${f.intent==='BUILD'?'Build':f.intent==='VERIFY'?'Verify':f.intent==='RESEARCH'?'Research':f.intent==='WRITE'?'Produce':f.intent==='PLAN'?'Plan':'Resolve'} the user's current objective${concepts?` involving ${concepts}`:''}.`;
}

export function buildSemanticPlan(context){
  if(!verifySemanticContext(context))throw new Error('Invalid semantic context');
  const s=context.state, f=context.frame;
  const mode=PLAYBOOKS[f.intent]?f.intent:(f.intent==='TRANSFORM'?'WRITE':(s.dialogueAct==='CONTINUE'&&s.resolvedConcepts.some(x=>/build|building|implement|code|develop/.test(x))?'BUILD':'GENERAL'));
  const steps=PLAYBOOKS[mode].map((kind,i)=>({id:`g${i+1}`,kind,dependsOn:i?[`g${i}`]:[],required:i<2||i===PLAYBOOKS[mode].length-1}));
  const baseConstraints=Array.isArray(f.constraints)?f.constraints.map(x=>typeof x==='string'?x:x?.value||x?.label):Object.entries(f.constraints||{}).filter(([,v])=>v===true).map(([k])=>k);
  const constraints=unique([...baseConstraints,s.dialogueAct==='CORRECT'?'respect-correction':null,s.referenceRequested?'bind-reference':null],8);
  const success=[`all-required-subgoals-complete`,`result-bound-to-semantic-context`,`verification-status-explicit`];
  const plan={protocol:'NSF-3',contextDigest:s.digest,mode,goal:goalFrom(context),subgoals:steps,constraints,successConditions:success,executionIntent:{cap1Signal:mode==='VERIFY'?'VERIFY':s.dialogueAct==='CONTINUE'?'ANCESTOR':'PATH',utterance:`STAR ${mode==='VERIFY'?'VERIFY':s.dialogueAct==='CONTINUE'?'ANCESTOR':'PATH'} GOAL ${mode} STEPS ${steps.length}`}};
  plan.digest=sha(canonical(plan));
  return plan;
}
export function verifySemanticPlan(plan,{contextDigest}={}){if(!plan||plan.protocol!=='NSF-3'||!plan.digest||!Array.isArray(plan.subgoals)||plan.subgoals.length<1||plan.subgoals.length>6)return false;const {digest,...body}=plan;if(digest!==sha(canonical(body)))return false;if(contextDigest&&plan.contextDigest!==contextDigest)return false;for(let i=0;i<plan.subgoals.length;i++){const g=plan.subgoals[i];if(g.id!==`g${i+1}`)return false;if(i===0&&g.dependsOn.length)return false;if(i>0&&JSON.stringify(g.dependsOn)!==JSON.stringify([`g${i}`]))return false;}return plan.successConditions.includes('verification-status-explicit');}
export function semanticPlanSummary(plan){return {protocol:plan.protocol,mode:plan.mode,goal:plan.goal,subgoals:plan.subgoals.length,constraints:plan.constraints,successConditions:plan.successConditions,cap1:plan.executionIntent.cap1Signal,digest:plan.digest};}
