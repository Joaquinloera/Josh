import crypto from 'node:crypto';
import { verifyPathwayLearningAdmission } from './pathway-learning-admission.js';
import { verifyLearningReceipt } from './adaptive-learning.js';

const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v)}
const digestOf=v=>sha(canonical(v));

export const PATHWAY_LEARNING_FULFILLMENT=Object.freeze({protocol:'NSF-26',version:1,mode:'admitted-learning-receipt-fulfillment',failClosed:true});

export function buildPathwayLearningFulfillment({admission,receipt,sequence=0}={}){
  const admissionVerified=verifyPathwayLearningAdmission(admission)&&admission?.admitted===true;
  const receiptVerified=verifyLearningReceipt(receipt)&&receipt?.verified===true;
  const sequenceBound=Number(receipt?.sequence||0)===Number(admission?.sequence||0)&&Number(sequence||0)===Number(admission?.sequence||0);
  const outcomeBound=Boolean(receipt?.evidenceHash)&&Boolean(admission?.outcomeDigest)&&admission?.outcomeStatus==='ACCEPTED';
  const fulfilled=admissionVerified&&receiptVerified&&sequenceBound&&outcomeBound;
  const body={protocol:'NSF-26',version:1,status:fulfilled?'FULFILLED':'DENIED',fulfilled,sequence:Number(sequence)||0,admissionDigest:admission?.digest||null,attestationDigest:admission?.attestationDigest||null,executionEntryDigest:admission?.executionEntryDigest||null,executionLedgerHead:admission?.executionLedgerHead||null,outcomeDigest:admission?.outcomeDigest||null,outputDigest:admission?.outputDigest||null,receiptHash:receipt?.receiptHash||null,pathwayKey:receipt?.key||null,learningScore:Number(receipt?.score||0),resultingStrength:Number(receipt?.update?.strength||0),bindings:{admissionVerified,receiptVerified,sequenceBound,outcomeBound},cap1:{signal:fulfilled?'WITNESS':'GUARD',utterance:fulfilled?'STAR WITNESS LEARNING-FULFILLMENT VERIFIED':'STAR GUARD LEARNING-FULFILLMENT DENIED'}};
  return {...body,digest:digestOf(body)};
}

export function verifyPathwayLearningFulfillment(fulfillment,{admission,receipt}={}){
  if(!fulfillment?.digest||fulfillment.protocol!=='NSF-26'||fulfillment.version!==1)return false;
  const {digest,...body}=fulfillment;if(digest!==digestOf(body))return false;
  const expected=fulfillment.bindings?.admissionVerified===true&&fulfillment.bindings?.receiptVerified===true&&fulfillment.bindings?.sequenceBound===true&&fulfillment.bindings?.outcomeBound===true;
  if(fulfillment.fulfilled!==expected||fulfillment.status!==(expected?'FULFILLED':'DENIED'))return false;
  if(fulfillment.cap1?.signal!==(expected?'WITNESS':'GUARD'))return false;
  if(admission){if(!verifyPathwayLearningAdmission(admission)||!admission.admitted||fulfillment.admissionDigest!==admission.digest||fulfillment.attestationDigest!==admission.attestationDigest||fulfillment.executionEntryDigest!==admission.executionEntryDigest||fulfillment.executionLedgerHead!==admission.executionLedgerHead||fulfillment.outcomeDigest!==admission.outcomeDigest||fulfillment.outputDigest!==admission.outputDigest||fulfillment.sequence!==admission.sequence)return false;}
  if(receipt){if(!verifyLearningReceipt(receipt)||!receipt.verified||fulfillment.receiptHash!==receipt.receiptHash||fulfillment.pathwayKey!==receipt.key||fulfillment.learningScore!==receipt.score||fulfillment.resultingStrength!==receipt.update?.strength||fulfillment.sequence!==receipt.sequence)return false;}
  return true;
}

export function pathwayLearningFulfillmentSummary(x){return {protocol:x.protocol,status:x.status,fulfilled:x.fulfilled,sequence:x.sequence,pathwayKey:x.pathwayKey,learningScore:x.learningScore,resultingStrength:x.resultingStrength,receiptHash:x.receiptHash,admissionDigest:x.admissionDigest,cap1:x.cap1,verified:verifyPathwayLearningFulfillment(x)};}
