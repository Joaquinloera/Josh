export function json(data, status = 200, headers = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      ...headers,
    },
  });
}

export const MAX_JSON_BODY_BYTES = 1024 * 1024;

export async function readJSONBody(req, { maxBytes = MAX_JSON_BODY_BYTES } = {}) {
  const declared = Number(req.headers.get("content-length"));
  if (Number.isFinite(declared) && declared > maxBytes) {
    const error = new Error("Request body is too large."); error.status = 413; throw error;
  }
  if (!req.body) return {};
  const reader = req.body.getReader();
  const decoder = new TextDecoder();
  let size = 0, text = "";
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > maxBytes) {
        try { await reader.cancel(); } catch {}
        const error = new Error("Request body is too large."); error.status = 413; throw error;
      }
      text += decoder.decode(value, { stream: true });
    }
    text += decoder.decode();
  } finally { reader.releaseLock(); }
  if (!text) return {};
  try { return JSON.parse(text); }
  catch { const error = new Error("Request body must be valid JSON."); error.status = 400; throw error; }
}
