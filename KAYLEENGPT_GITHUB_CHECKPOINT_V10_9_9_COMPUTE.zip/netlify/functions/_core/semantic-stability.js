import crypto from 'node:crypto';
import { verifySemanticTrustProfile } from './semantic-trust.js';
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v);}
const digestOf=v=>sha(canonical(v));
export const SEMANTIC_STABILITY=Object.freeze({protocol:'NSF-11',fullTrustThreshold:.70,guardedTrustThreshold:.50});
function baseCandidate(selection,baseRoute){return (selection?.candidates||[]).find(x=>x.source==='base')||{source:'base',host:baseRoute?.host?.id||null,agent:baseRoute?.agent?.id||baseRoute?.agents?.[0]?.id||null,strength:.6,key:null};}
export function applySemanticStability({profile,selection,baseRoute,explicitRoute=false}={}){
 if(!verifySemanticTrustProfile(profile))throw new Error('Invalid semantic trust profile for stability gate');
 let mode,route=selection?.route||baseRoute,nextSelection=selection,explorationAllowed=false;
 if(explicitRoute){mode='EXPLICIT_OVERRIDE';explorationAllowed=false;}
 else if(!profile.mature){mode='COLD_START';explorationAllowed=false;if(selection?.exploration){const selected=baseCandidate(selection,baseRoute);route=baseRoute;nextSelection={...selection,route,selected,decision:'semantic-cold-start-base',exploration:false};}}
 else if(profile.score<SEMANTIC_STABILITY.guardedTrustThreshold){mode='QUARANTINED';route=baseRoute;const selected=baseCandidate(selection,baseRoute);nextSelection={...selection,route,selected,decision:'semantic-quarantine',rolledBack:true,exploration:false};}
 else if(profile.score<SEMANTIC_STABILITY.fullTrustThreshold){mode='GUARDED';explorationAllowed=false;if(selection?.exploration){const selected=baseCandidate(selection,baseRoute);route=baseRoute;nextSelection={...selection,route,selected,decision:'semantic-guarded-base',exploration:false};}}
 else {mode='FULL';explorationAllowed=true;}
 const body={protocol:'NSF-11',profileDigest:profile.digest,profileScore:profile.score,profileMature:profile.mature,selectionDecision:selection?.decision||null,selectionCandidateDigest:digestOf((selection?.candidates||[]).map(x=>({source:x.source,key:x.key,strength:x.strength}))),mode,explorationAllowed,routeHost:route?.host?.id||null,routeAgent:route?.agent?.id||route?.agents?.[0]?.id||null,cap1:{signal:mode==='QUARANTINED'?'GUARD':mode==='FULL'?'PATH':'VERIFY',utterance:`STAR ${mode==='QUARANTINED'?'GUARD':mode==='FULL'?'PATH':'VERIFY'} STABILITY ${profile.digest.slice(0,16)}`}};
 return {selection:nextSelection,route,stability:{...body,digest:digestOf(body)}};
}
export function verifySemanticStability(s,{profileDigest}={}){if(!s?.digest||s.protocol!=='NSF-11')return false;const {digest,...body}=s;if(digest!==digestOf(body))return false;if(profileDigest&&s.profileDigest!==profileDigest)return false;if(!['EXPLICIT_OVERRIDE','COLD_START','QUARANTINED','GUARDED','FULL'].includes(s.mode))return false;if(s.explorationAllowed!==(s.mode==='FULL'))return false;return true;}
