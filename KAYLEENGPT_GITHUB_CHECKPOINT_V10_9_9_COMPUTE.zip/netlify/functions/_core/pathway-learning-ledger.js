import crypto from 'node:crypto';
import { verifyPathwayLearningFulfillment } from './pathway-learning-fulfillment.js';
import { verifyLearningBoundLearningFulfillment } from './learning-bound-learning-fulfillment.js';
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v)}
const digestOf=v=>sha(canonical(v));
const FILTER_BYTES=512,FILTER_HASHES=6;
const blankFilter=()=>Buffer.alloc(FILTER_BYTES);
function decodeFilter(s){if(!s)return blankFilter();try{const b=Buffer.from(s,'base64');return b.length===FILTER_BYTES?b:null;}catch{return null;}}
function positions(d){const h=crypto.createHash('sha256').update(String(d)).digest();const out=[];for(let i=0;i<FILTER_HASHES;i++){const a=h.readUInt32BE((i*4)%28),b=h.readUInt32BE(((i*4)+4)%28);out.push((a+i*b+i*i)%(FILTER_BYTES*8));}return out;}
function addFilter(buf,d){for(const p of positions(d))buf[p>>3]|=1<<(p&7);}
function hasFilter(buf,d){return positions(d).every(p=>(buf[p>>3]&(1<<(p&7)))!==0);}
const empty=()=>({protocol:'NSF-27',version:1,sequence:0,head:null,anchor:null,entries:[]});
export const PATHWAY_LEARNING_LEDGER=Object.freeze({protocol:'NSF-28',ledgerProtocol:'NSF-27',version:1,mode:'checkpointed-learning-fulfillment-ledger',maxEntries:96,retain:48,filterBytes:FILTER_BYTES,filterHashes:FILTER_HASHES,failClosed:true});
function verifyAnchor(a){if(a===null||a===undefined)return true;if(!a||a.protocol!=='NSF-28-CHECKPOINT'||!a.digest)return false;const {digest,...body}=a,f=decodeFilter(a.replayFilter);return !!f&&digest===digestOf(body)&&Number.isInteger(a.throughSequence)&&a.throughSequence>0&&typeof a.throughDigest==='string'&&a.throughDigest.length===64&&Number.isInteger(a.archivedEntries)&&a.archivedEntries>0&&a.filterBytes===FILTER_BYTES&&a.filterHashes===FILTER_HASHES;}
export function verifyPathwayLearningLedger(ledger){
 if(!ledger||ledger.protocol!=='NSF-27'||ledger.version!==1||!Number.isInteger(ledger.sequence)||ledger.sequence<0||!Array.isArray(ledger.entries)||ledger.entries.length>96||!verifyAnchor(ledger.anchor))return false;
 let prev=ledger.anchor?.throughDigest||null,seq=ledger.anchor?.throughSequence||0;const fulfillmentSeen=new Set(),receiptSeen=new Set();
 for(const e of ledger.entries){if(!e?.digest||e.protocol!=='NSF-27-COMMIT'||e.previous!==prev||e.sequence!==seq+1||fulfillmentSeen.has(e.fulfillmentDigest)||receiptSeen.has(e.receiptHash))return false;const {digest,...body}=e;if(digest!==digestOf(body))return false;fulfillmentSeen.add(e.fulfillmentDigest);receiptSeen.add(e.receiptHash);prev=e.digest;seq=e.sequence;}
 return ledger.sequence===seq&&ledger.head===prev&&(seq>0||ledger.head===null);
}
export function archivedLearningReplayPossible(ledger,digest){if(!verifyPathwayLearningLedger(ledger))throw new Error('Invalid NSF-27 learning ledger');if(!ledger.anchor)return false;return hasFilter(decodeFilter(ledger.anchor.replayFilter),digest);}
export function compactPathwayLearningLedger(input,{retain=PATHWAY_LEARNING_LEDGER.retain}={}){
 const ledger=structuredClone(input);if(!verifyPathwayLearningLedger(ledger))throw new Error('Invalid NSF-27 learning ledger');if(!Number.isInteger(retain)||retain<1)throw new Error('Invalid learning ledger retention');if(ledger.entries.length<=retain)return {ledger,compacted:false,anchor:ledger.anchor||null};
 const cut=ledger.entries.length-retain,last=ledger.entries[cut-1],prior=ledger.anchor||null,filter=decodeFilter(prior?.replayFilter);for(const e of ledger.entries.slice(0,cut)){addFilter(filter,e.fulfillmentDigest);addFilter(filter,e.receiptHash);}
 const body={protocol:'NSF-28-CHECKPOINT',throughSequence:last.sequence,throughDigest:last.digest,archivedEntries:(prior?.archivedEntries||0)+cut,previousAnchorDigest:prior?.digest||null,firstArchivedSequence:prior?prior.throughSequence+1:1,lastArchivedSequence:last.sequence,archiveDigest:digestOf(ledger.entries.slice(0,cut).map(e=>e.digest)),replayFilter:filter.toString('base64'),filterBytes:FILTER_BYTES,filterHashes:FILTER_HASHES,cap1:{signal:'ANCESTOR',utterance:`STAR ANCESTOR LEARNING-ARCHIVE ${last.digest.slice(0,16)}`}};
 const anchor={...body,digest:digestOf(body)},next={protocol:'NSF-27',version:1,sequence:ledger.sequence,head:ledger.head,anchor,entries:ledger.entries.slice(cut)};if(!verifyPathwayLearningLedger(next))throw new Error('NSF-28 learning ledger compaction verification failed');return {ledger:next,compacted:true,anchor};
}
export function commitPathwayLearningFulfillment(previous,fulfillment,learningBoundFulfillment=null){
 let ledger=previous?.protocol==='NSF-27'?structuredClone(previous):empty();if(!verifyPathwayLearningLedger(ledger))throw new Error('Invalid NSF-27 learning ledger');
 if(!verifyPathwayLearningFulfillment(fulfillment)||!fulfillment.fulfilled)throw new Error('Only fulfilled NSF-26 learning records may commit');
 if(ledger.entries.some(e=>e.fulfillmentDigest===fulfillment.digest||e.receiptHash===fulfillment.receiptHash)||archivedLearningReplayPossible(ledger,fulfillment.digest)||archivedLearningReplayPossible(ledger,fulfillment.receiptHash))throw new Error('Learning fulfillment replay rejected');
 if(ledger.entries.length>=96)ledger=compactPathwayLearningLedger(ledger).ledger;
 if(archivedLearningReplayPossible(ledger,fulfillment.digest)||archivedLearningReplayPossible(ledger,fulfillment.receiptHash))throw new Error('Learning fulfillment replay rejected');
 if(learningBoundFulfillment&&(!verifyLearningBoundLearningFulfillment(learningBoundFulfillment)||!learningBoundFulfillment.fulfilled||learningBoundFulfillment.baseFulfillmentDigest!==fulfillment.digest||learningBoundFulfillment.receiptHash!==fulfillment.receiptHash||learningBoundFulfillment.pathwayKey!==fulfillment.pathwayKey))throw new Error('Invalid NSF-36 learning-bound fulfillment');
 const lineage=learningBoundFulfillment?{learningBoundFulfillmentDigest:learningBoundFulfillment.digest,learningLineageDigest:learningBoundFulfillment.learningLineageDigest,sourceLearningLedgerHead:learningBoundFulfillment.sourceLearningLedgerHead,sourceLearningLedgerSequence:learningBoundFulfillment.sourceLearningLedgerSequence}:{};
 const body={protocol:'NSF-27-COMMIT',sequence:ledger.sequence+1,previous:ledger.head,fulfillmentDigest:fulfillment.digest,admissionDigest:fulfillment.admissionDigest,receiptHash:fulfillment.receiptHash,pathwayKey:fulfillment.pathwayKey,outcomeDigest:fulfillment.outcomeDigest,executionEntryDigest:fulfillment.executionEntryDigest,resultingStrength:fulfillment.resultingStrength,...lineage,cap1:{signal:'ANCESTOR',utterance:'STAR ANCESTOR LEARNING-FULFILLMENT COMMITTED'}};
 const entry={...body,digest:digestOf(body)};ledger.entries.push(entry);ledger.sequence=entry.sequence;ledger.head=entry.digest;if(!verifyPathwayLearningLedger(ledger))throw new Error('NSF-27 learning ledger commit verification failed');return {ledger,entry};
}
export function pathwayLearningLedgerSummary(l){return {protocol:'NSF-28',ledgerProtocol:l.protocol,sequence:l.sequence,head:l.head,entries:l.entries.length,archived:l.anchor?.archivedEntries||0,anchorDigest:l.anchor?.digest||null,replayShield:l.anchor?'BLOOM-4096x6':'EMPTY',verified:verifyPathwayLearningLedger(l)};}
