import crypto from 'node:crypto';
import { getHost } from './hosts.js';
import { getAgent, selectAgents } from './agents.js';

export const LEARNED_ROUTING = Object.freeze({
  id:'BQR-1', version:'0.1', mode:'bounded-explore-exploit',
  explorationRate:0.15, confidenceThreshold:0.58, rollbackThreshold:0.42,
  decayHalfLifeDays:30, maxCandidates:8, autonomousDeployment:false
});
const clamp=n=>Math.max(0,Math.min(1,Number(n)||0));
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
const round=n=>Number(clamp(n).toFixed(6));
export function decayedStrength(pathway,now=Date.now()){
  const strength=clamp(pathway?.strength??0.5), updated=Number(pathway?.updatedAt||now);
  const ageDays=Math.max(0,(now-updated)/86400000), factor=Math.pow(0.5,ageDays/LEARNED_ROUTING.decayHalfLifeDays);
  return round(0.5+(strength-0.5)*factor);
}
function parseKey(key){const [intent,host,agent]=String(key||'').split(':');return {intent,host,agent};}
export function routingCandidates({intent,baseRoute,pathways={},now=Date.now()}={}){
  const baseAgent=baseRoute?.agent?.id||baseRoute?.agents?.[0]?.id||'native';
  const candidates=[{source:'base',host:baseRoute?.host?.id||'uriel',agent:baseAgent,strength:0.6,key:`${intent}:${baseRoute?.host?.id||'uriel'}:${baseAgent}`}];
  for(const [key,p] of Object.entries(pathways||{})){
    const parsed=parseKey(key); if(parsed.intent!==intent||!getHost(parsed.host)||!getAgent(parsed.agent))continue;
    candidates.push({source:'learned',host:parsed.host,agent:parsed.agent,strength:decayedStrength(p,now),key,lastReceiptHash:p.lastReceiptHash||null});
  }
  return candidates.sort((a,b)=>b.strength-a.strength||a.key.localeCompare(b.key)).slice(0,LEARNED_ROUTING.maxCandidates);
}
function deterministicUnit(seed){return parseInt(sha(seed).slice(0,12),16)/0xffffffffffff;}
export function selectLearnedRoute({intent,baseRoute,pathways={},sequence=1,request='',now=Date.now()}={}){
  const candidates=routingCandidates({intent,baseRoute,pathways,now});
  const learned=candidates.filter(x=>x.source==='learned'&&x.strength>=LEARNED_ROUTING.confidenceThreshold);
  const explore=learned.length>1&&deterministicUnit(`${sequence}:${intent}:${request}`)<LEARNED_ROUTING.explorationRate;
  let selected=learned[0]||candidates[0], decision=learned.length?'exploit':'base';
  if(explore){selected=learned[1];decision='explore';}
  let rolledBack=false;
  if(!selected||selected.strength<LEARNED_ROUTING.rollbackThreshold){selected=candidates.find(x=>x.source==='base')||candidates[0];decision='rollback';rolledBack=true;}
  const host=getHost(selected.host)||baseRoute.host, agent=getAgent(selected.agent)||baseRoute.agent;
  const agents=agent?[agent,...selectAgents(host.id,{limit:3}).filter(x=>x.id!==agent.id)].slice(0,3):selectAgents(host.id,{limit:3});
  return {route:{host,agent:agents[0]||null,agents},decision,rolledBack,selected,candidates,exploration:explore};
}
export function buildRoutingReceipt({intent,selection,sequence=1,request='',signingKey=''}={}){
  const core={protocol:'BQR-1',sequence,intent,decision:selection.decision,rolledBack:selection.rolledBack,selected:selection.selected,candidateDigest:sha(JSON.stringify(selection.candidates)),requestDigest:sha(request),policy:{explorationRate:LEARNED_ROUTING.explorationRate,confidenceThreshold:LEARNED_ROUTING.confidenceThreshold,rollbackThreshold:LEARNED_ROUTING.rollbackThreshold}};
  const receiptHash=sha(JSON.stringify(core));
  const signature=signingKey?crypto.createHmac('sha256',signingKey).update(receiptHash).digest('hex'):null;
  return {...core,receiptHash,signature,signatureAlgorithm:signature?'HMAC-SHA256':'UNSIGNED-CHECKPOINT'};
}
export function verifyRoutingReceipt(receipt,{signingKey=''}={}){
  if(!receipt?.receiptHash||receipt.protocol!=='BQR-1')return false; const {receiptHash,signature,signatureAlgorithm,...core}=receipt;
  if(sha(JSON.stringify(core))!==receiptHash)return false;
  if(signatureAlgorithm==='HMAC-SHA256')return Boolean(signingKey)&&crypto.timingSafeEqual(Buffer.from(signature,'hex'),Buffer.from(crypto.createHmac('sha256',signingKey).update(receiptHash).digest('hex'),'hex'));
  return signatureAlgorithm==='UNSIGNED-CHECKPOINT'&&!signature;
}
