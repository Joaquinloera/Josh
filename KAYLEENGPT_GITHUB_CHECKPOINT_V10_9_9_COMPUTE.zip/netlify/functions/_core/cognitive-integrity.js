import crypto from 'node:crypto';
import { verifyCognitiveCheckpoint, buildExecutionLineage } from './cognitive-checkpoint.js';

const POLICY=Object.freeze({protocol:'BCI-1',schema:1,states:['PREPARED','RUNNING','COMPLETED','FAILED','RECOVERING'],terminal:['COMPLETED','FAILED'],maxResumeAttempts:1});
const stable=v=>JSON.stringify(v,Object.keys(v).sort());
const hash=v=>crypto.createHash('sha256').update(typeof v==='string'?v:stable(v)).digest('hex');
export function integrityPolicy(){return {...POLICY,states:[...POLICY.states],terminal:[...POLICY.terminal]};}
export function validTransition(from,to){const allowed={PREPARED:['RUNNING','FAILED'],RUNNING:['COMPLETED','FAILED'],FAILED:['RECOVERING'],RECOVERING:['RUNNING','FAILED'],COMPLETED:[]};return (allowed[from]||[]).includes(to);}
export function authorizeRecovery({checkpoint,lineage,resumeAttempts=0}={}){return Boolean(checkpoint&&lineage?.verified&&['PREPARED','FAILED'].includes(checkpoint.phase)&&resumeAttempts<POLICY.maxResumeAttempts);}
export function buildIntegrityCommit({checkpoint,from='PREPARED',to='RUNNING',scheduleDigest='',routingReceiptHash='',taskGraphHash='',memoryDigest='',cap1Digest='',resumeOf=null}={}){
 if(!checkpoint||!validTransition(from,to))throw new Error('Invalid cognitive state transition');
 const body={protocol:POLICY.protocol,schema:POLICY.schema,checkpointHash:checkpoint.checkpointHash,from,to,scheduleDigest:String(scheduleDigest||''),routingReceiptHash:String(routingReceiptHash||''),taskGraphHash:String(taskGraphHash||''),memoryDigest:String(memoryDigest||''),cap1Digest:String(cap1Digest||''),resumeOf:resumeOf||null,createdAt:Date.now()};
 return {...body,commitHash:hash(body)};
}
export function verifyIntegrityCommit(commit,{checkpoint}={}){if(!commit||commit.protocol!==POLICY.protocol||commit.schema!==1||!validTransition(commit.from,commit.to)||commit.checkpointHash!==checkpoint?.checkpointHash)return false;const {commitHash,...body}=commit;return commitHash===hash(body);}
export function buildAuditLineage({checkpoints=[],commits=[]}={}){const cp=buildExecutionLineage(checkpoints);let previous=null;const hashes=[];for(const c of commits){if(!c?.commitHash||c.resumeOf&&c.resumeOf!==previous)return{protocol:POLICY.protocol,verified:false,checkpointLineage:cp,commitCount:hashes.length,head:previous,auditHash:hash(hashes.join(':'))};hashes.push(c.commitHash);previous=c.commitHash;}return{protocol:POLICY.protocol,verified:cp.verified&&hashes.length===commits.length,checkpointLineage:cp,commitCount:hashes.length,head:previous,auditHash:hash([cp.hash,...hashes].join(':'))};}
export function deterministicResume({checkpoint,lineage,resumeAttempts=0}={}){if(!authorizeRecovery({checkpoint,lineage,resumeAttempts}))return{authorized:false,mode:'FAIL_CLOSED',checkpointHash:checkpoint?.checkpointHash||null};return{authorized:true,mode:'RESUME_LAST_VERIFIED',checkpointHash:checkpoint.checkpointHash,nextState:'RECOVERING',resumeAttempt:resumeAttempts+1};}
