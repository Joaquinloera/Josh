import crypto from 'node:crypto';

const MAX_INPUT = 24000;
const clip = (v, n = MAX_INPUT) => String(v ?? '').slice(0, n);

export const CAPABILITY_REGISTRY = Object.freeze({
  'text.metrics': { permission: 'compute', sideEffects: false, description: 'Count characters, words, lines, and bytes.' },
  'json.validate': { permission: 'compute', sideEffects: false, description: 'Validate JSON and report its top-level type.' },
  'crypto.sha256': { permission: 'compute', sideEffects: false, description: 'Compute a SHA-256 digest of supplied text.' },
  'plan.checklist': { permission: 'compute', sideEffects: false, description: 'Convert newline-delimited actions into a bounded checklist.' },
});

export function listCapabilities() {
  return Object.entries(CAPABILITY_REGISTRY).map(([id, meta]) => ({ id, ...meta }));
}

export function authorizeCapability(id, context = {}) {
  const capability = CAPABILITY_REGISTRY[id];
  if (!capability) return { allowed: false, reason: 'UNKNOWN_CAPABILITY' };
  if (!context.authenticated) return { allowed: false, reason: 'AUTH_REQUIRED' };
  if (capability.sideEffects) return { allowed: false, reason: 'SIDE_EFFECT_REQUIRES_EXPLICIT_POLICY' };
  return { allowed: true, permission: capability.permission };
}

export function executeCapability(id, input, context = {}) {
  const auth = authorizeCapability(id, context);
  if (!auth.allowed) return { ok: false, capability: id, error: auth.reason };
  const text = clip(input);
  if (id === 'text.metrics') {
    const trimmed = text.trim();
    return { ok: true, capability: id, result: { characters: text.length, bytes: Buffer.byteLength(text), words: trimmed ? trimmed.split(/\s+/).length : 0, lines: text ? text.split(/\r?\n/).length : 0 } };
  }
  if (id === 'json.validate') {
    try { const value = JSON.parse(text); return { ok: true, capability: id, result: { valid: true, type: Array.isArray(value) ? 'array' : value === null ? 'null' : typeof value } }; }
    catch (error) { return { ok: true, capability: id, result: { valid: false, error: String(error.message).slice(0, 240) } }; }
  }
  if (id === 'crypto.sha256') return { ok: true, capability: id, result: { algorithm: 'sha256', digest: crypto.createHash('sha256').update(text).digest('hex') } };
  if (id === 'plan.checklist') {
    const items = text.split(/\r?\n/).map(x => x.trim()).filter(Boolean).slice(0, 20).map((action, i) => ({ id: i + 1, action: action.slice(0, 400), done: false }));
    return { ok: true, capability: id, result: { items } };
  }
  return { ok: false, capability: id, error: 'NOT_IMPLEMENTED' };
}
