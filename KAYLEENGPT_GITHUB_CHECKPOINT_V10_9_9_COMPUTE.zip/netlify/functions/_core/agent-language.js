import crypto from 'node:crypto';

// JoshGPT Celestial Ancestral Protocol (CAP-1).
// This is a JoshGPT-constructed machine language for internal agent handoffs.
// It is NOT represented as a historically attested Maya, Nahua/Aztec, or other Indigenous language.
export const AGENT_LANGUAGE = Object.freeze({
  id: 'CAP-1',
  name: 'Celestial Ancestral Protocol',
  scope: 'internal-agent-handoffs',
  inspiration: 'heavens-stars-ancestral-cosmology',
  historicallyAttested: false,
  userFacingDefault: false,
  encoding: 'UTF-8+canonical-json+sha256',
});

const LEXICON = Object.freeze({
  sky: 'KAA', star: 'TZIN', path: 'BEH', light: 'KINAL', memory: 'NAH',
  truth: 'CHEN', guard: 'BALAM', build: 'PAK', seek: 'IL', join: 'MOL',
  speak: 'TAN', verify: 'TOK', resolve: 'LAM', begin: 'HA', complete: 'TZOL',
});

const sha = value => crypto.createHash('sha256').update(String(value)).digest('hex');
function canonical(value){
  if(Array.isArray(value)) return `[${value.map(canonical).join(',')}]`;
  if(value && typeof value==='object') return `{${Object.keys(value).sort().map(k=>`${JSON.stringify(k)}:${canonical(value[k])}`).join(',')}}`;
  return JSON.stringify(value);
}

export function celestialTerm(concept){ return LEXICON[String(concept||'').toLowerCase()] || 'UN'; }

export function encodeAgentUtterance({from,to,kind='handoff',taskId='',payloadHash='',sequence=1}){
  const body={
    protocol:AGENT_LANGUAGE.id,
    tongue:`${celestialTerm('sky')}-${celestialTerm('star')}`,
    from:String(from||'native'),to:String(to||'native'),kind:String(kind),
    taskId:String(taskId),payloadHash:String(payloadHash),sequence:Number(sequence),
    markers:[celestialTerm('begin'),celestialTerm(kind==='review'?'verify':kind==='reconcile'?'resolve':'speak'),celestialTerm('complete')],
  };
  return Object.freeze({...body,utteranceHash:sha(canonical(body))});
}

export function verifyAgentUtterance(utterance){
  if(!utterance || utterance.protocol!==AGENT_LANGUAGE.id || !utterance.utteranceHash) return false;
  const {utteranceHash,...body}=utterance;
  return utteranceHash===sha(canonical(body));
}

export function languageDescriptor(){
  return {...AGENT_LANGUAGE,lexiconSize:Object.keys(LEXICON).length,privateSemanticProtocol:true};
}
