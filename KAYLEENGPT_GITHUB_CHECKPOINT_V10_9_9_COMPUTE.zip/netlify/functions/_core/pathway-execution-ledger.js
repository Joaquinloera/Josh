import crypto from 'node:crypto';
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v)}
const digestOf=v=>sha(canonical(v));
const FILTER_BYTES=512,FILTER_HASHES=6;
const blankFilter=()=>Buffer.alloc(FILTER_BYTES);
function decodeFilter(s){if(!s)return blankFilter();try{const b=Buffer.from(s,'base64');return b.length===FILTER_BYTES?b:null;}catch{return null;}}
function positions(d){const h=crypto.createHash('sha256').update(String(d)).digest();const out=[];for(let i=0;i<FILTER_HASHES;i++){const a=h.readUInt32BE((i*4)%28),b=h.readUInt32BE(((i*4)+4)%28);out.push((a+i*b+i*i)%(FILTER_BYTES*8));}return out;}
function addFilter(buf,d){for(const p of positions(d))buf[p>>3]|=1<<(p&7);}
function hasFilter(buf,d){return positions(d).every(p=>(buf[p>>3]&(1<<(p&7)))!==0);}
const empty=()=>({protocol:'NSF-22',version:1,sequence:0,head:null,anchor:null,entries:[]});
export const PATHWAY_EXECUTION_LEDGER=Object.freeze({protocol:'NSF-23',ledgerProtocol:'NSF-22',version:1,mode:'checkpointed-fulfillment-ledger',maxEntries:96,retain:48,filterBytes:FILTER_BYTES,filterHashes:FILTER_HASHES,failClosed:true});
function verifyAnchor(a){if(a===null||a===undefined)return true;if(!a||a.protocol!=='NSF-23-CHECKPOINT'||!a.digest)return false;const {digest,...body}=a,f=decodeFilter(a.replayFilter);return !!f&&digest===digestOf(body)&&Number.isInteger(a.throughSequence)&&a.throughSequence>0&&typeof a.throughDigest==='string'&&a.throughDigest.length===64&&Number.isInteger(a.archivedEntries)&&a.archivedEntries>0&&a.filterBytes===FILTER_BYTES&&a.filterHashes===FILTER_HASHES;}
export function verifyPathwayExecutionLedger(ledger){
 if(!ledger||ledger.protocol!=='NSF-22'||!Number.isInteger(ledger.sequence)||ledger.sequence<0||!Array.isArray(ledger.entries)||ledger.entries.length>96||!verifyAnchor(ledger.anchor))return false;
 let prev=ledger.anchor?.throughDigest||null,lastSeq=ledger.anchor?.throughSequence||0;const seen=new Set();
 for(const e of ledger.entries){if(!e?.digest||e.protocol!=='NSF-22-COMMIT'||e.previous!==prev||e.sequence!==lastSeq+1||seen.has(e.fulfillmentDigest))return false;const {digest,...body}=e;if(digest!==digestOf(body))return false;seen.add(e.fulfillmentDigest);prev=e.digest;lastSeq=e.sequence;}
 if(Number(ledger.sequence||0)!==lastSeq||ledger.head!==prev)return false;if(ledger.sequence===0)return ledger.head===null&&!ledger.anchor&&ledger.entries.length===0;return true;
}
export function archivedExecutionReplayPossible(ledger,digest){if(!verifyPathwayExecutionLedger(ledger))throw new Error('Invalid NSF-22 execution ledger');if(!ledger.anchor)return false;return hasFilter(decodeFilter(ledger.anchor.replayFilter),digest);}
export function compactPathwayExecutionLedger(input,{retain=PATHWAY_EXECUTION_LEDGER.retain}={}){
 const ledger=structuredClone(input);if(!verifyPathwayExecutionLedger(ledger))throw new Error('Invalid NSF-22 execution ledger');if(!Number.isInteger(retain)||retain<1)throw new Error('Invalid execution ledger retention');if(ledger.entries.length<=retain)return {ledger,compacted:false,anchor:ledger.anchor||null};
 const cut=ledger.entries.length-retain,last=ledger.entries[cut-1],prior=ledger.anchor||null,filter=decodeFilter(prior?.replayFilter);for(const e of ledger.entries.slice(0,cut)){addFilter(filter,e.fulfillmentDigest);addFilter(filter,e.sealDigest);}
 const body={protocol:'NSF-23-CHECKPOINT',throughSequence:last.sequence,throughDigest:last.digest,archivedEntries:(prior?.archivedEntries||0)+cut,previousAnchorDigest:prior?.digest||null,firstArchivedSequence:prior?prior.throughSequence+1:1,lastArchivedSequence:last.sequence,archiveDigest:digestOf(ledger.entries.slice(0,cut).map(e=>e.digest)),replayFilter:filter.toString('base64'),filterBytes:FILTER_BYTES,filterHashes:FILTER_HASHES,cap1:{signal:'ANCESTOR',utterance:`STAR ANCESTOR EXECUTION-ARCHIVE ${last.digest.slice(0,16)}`}};
 const anchor={...body,digest:digestOf(body)},next={protocol:'NSF-22',version:1,sequence:ledger.sequence,head:ledger.head,anchor,entries:ledger.entries.slice(cut)};if(!verifyPathwayExecutionLedger(next))throw new Error('NSF-23 execution ledger compaction verification failed');return {ledger:next,compacted:true,anchor};
}
export function commitPathwayExecutionFulfillment(previous,fulfillment){
 let ledger=previous?.protocol==='NSF-22'?structuredClone(previous):empty();if(!verifyPathwayExecutionLedger(ledger))throw new Error('Invalid NSF-22 execution ledger');
 if(fulfillment?.protocol!=='NSF-21'||fulfillment?.fulfilled!==true||!fulfillment?.digest)throw new Error('Only fulfilled NSF-21 records may commit');
 if(ledger.entries.some(e=>e.fulfillmentDigest===fulfillment.digest||e.sealDigest===fulfillment.sealDigest)||archivedExecutionReplayPossible(ledger,fulfillment.digest)||archivedExecutionReplayPossible(ledger,fulfillment.sealDigest))throw new Error('Execution fulfillment replay rejected');
 if(ledger.entries.length>=96)ledger=compactPathwayExecutionLedger(ledger).ledger;
 if(archivedExecutionReplayPossible(ledger,fulfillment.digest)||archivedExecutionReplayPossible(ledger,fulfillment.sealDigest))throw new Error('Execution fulfillment replay rejected');
 const body={protocol:'NSF-22-COMMIT',sequence:ledger.sequence+1,previous:ledger.head,fulfillmentDigest:fulfillment.digest,sealDigest:fulfillment.sealDigest,graphId:fulfillment.graphId,outputDigest:fulfillment.outputDigest,productDigest:digestOf(fulfillment.productDigests||[]),sealAdmissionProtocol:fulfillment.sealAdmissionProtocol||'NSF-19',learningLineageDigest:fulfillment.learningLineageDigest||null,learningLedgerHead:fulfillment.learningLedgerHead||null,learningLedgerSequence:Number(fulfillment.learningLedgerSequence||0),cap1:{signal:'ANCESTOR',utterance:'STAR ANCESTOR EXECUTION-FULFILLMENT COMMITTED'}};
 const entry={...body,digest:digestOf(body)};ledger.entries.push(entry);ledger.sequence=entry.sequence;ledger.head=entry.digest;if(!verifyPathwayExecutionLedger(ledger))throw new Error('NSF-22 execution ledger commit verification failed');return {ledger,entry};
}
export function pathwayExecutionLedgerSummary(l){return {protocol:'NSF-23',ledgerProtocol:l.protocol,sequence:l.sequence,head:l.head,entries:l.entries.length,archived:l.anchor?.archivedEntries||0,anchorDigest:l.anchor?.digest||null,replayShield:l.anchor?'BLOOM-4096x6':'EMPTY',verified:verifyPathwayExecutionLedger(l)};}
