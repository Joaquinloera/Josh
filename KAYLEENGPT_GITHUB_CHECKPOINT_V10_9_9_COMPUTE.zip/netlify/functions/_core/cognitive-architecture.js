import crypto from 'node:crypto';
import { encodeAgentUtterance, verifyAgentUtterance } from './agent-language.js';

export const COGNITIVE_ARCHITECTURE = Object.freeze({
  id:'BQCA-1', name:'Bio x Quantum Cognitive Architecture', version:'0.1',
  bioInspiredSoftware:true, quantumInspiredAlgorithms:true,
  biologicalHardwareInstalled:false, quantumHardwareInstalled:false,
  foundationModelInstalled:false, physicalQuantumClaims:false
});
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
const clamp=n=>Math.max(0,Math.min(1,Number(n)||0));

export function buildBioState({taskGraph,memory=[],retrieval=[]}={}){
  const products=taskGraph?.products||[];
  const cells=products.map((p,i)=>({id:`cell-${i+1}`,agentId:p.agentId||p.from||'native',specialization:p.kind||'work-product',signalHash:p.hash||p.payloadHash||sha(JSON.stringify(p)),activation:clamp(.55+(i*.08))}));
  const pathways=cells.slice(1).map((c,i)=>({from:cells[i].id,to:c.id,strength:clamp(.62+(i*.07)),plastic:true}));
  return {version:'bio-state-0.1',metaphor:'bio-inspired-software',cells,pathways,memorySignals:memory.length,retrievalSignals:retrieval.length,homeostasis:{bounded:true,maxCells:8,activeCells:cells.length}};
}

export function buildQuantumInspiredState({reasoningState}={}){
  const candidates=(reasoningState?.branches||reasoningState?.candidates||[]).slice(0,6).map((c,i)=>({id:c.id||`state-${i+1}`,weight:clamp(c.score??c.confidence??(.5-i*.05)),status:c.eliminated?'eliminated':'candidate'}));
  const total=candidates.reduce((s,c)=>s+c.weight,0)||1;
  const normalized=candidates.map(c=>({...c,probability:Number((c.weight/total).toFixed(6))}));
  const winner=normalized.filter(c=>c.status!=='eliminated').sort((a,b)=>b.probability-a.probability)[0]||null;
  return {version:'quantum-inspired-state-0.1',physicalQuantum:false,superpositionAnalogy:true,candidateStates:normalized,collapse:{rule:'verified-highest-weight',selected:winner?.id||null,converged:Boolean(reasoningState?.verification?.ready)}};
}

export function buildCelestialCognitiveBus({taskId='native-task',bioState,quantumState,taskGraph}={}){
  const evidenceHash=sha(JSON.stringify({bioState,quantumState,graph:taskGraph?.verification||null}));
  const signal=encodeAgentUtterance({from:'BIO-CORE',to:'Q-CORE',kind:'handoff',taskId,payloadHash:evidenceHash,sequence:1});
  const returnSignal=encodeAgentUtterance({from:'Q-CORE',to:'RECONCILER',kind:'reconcile',taskId,payloadHash:sha(JSON.stringify({evidenceHash,selected:quantumState?.collapse?.selected||null})),sequence:2});
  return {version:'celestial-bus-0.1',protocol:'CAP-1',signals:[signal,returnSignal],verification:{allSignalsVerified:[signal,returnSignal].every(verifyAgentUtterance),evidenceHash}};
}

export function buildCognitiveState(args={}){
  const bio=buildBioState(args), quantum=buildQuantumInspiredState(args), bus=buildCelestialCognitiveBus({...args,bioState:bio,quantumState:quantum});
  return {architecture:COGNITIVE_ARCHITECTURE,bio,quantum,bus,verification:{ready:bus.verification.allSignalsVerified && bio.homeostasis.bounded && quantum.physicalQuantum===false}};
}
