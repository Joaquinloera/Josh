function env(name){ return globalThis.Netlify?.env?.get?.(name) || process.env?.[name] || ''; }
export const corticalCl1Adapter = {
  id: 'cortical-cl1',
  async available(){ return Boolean(env('CORTICAL_API_KEY') && env('CORTICAL_API_URL')); },
  async execute({workload=null}={}){
    if(!await this.available()) throw new Error('Cortical CL1 is not configured');
    return {ok:true,mode:'bio',provider:'Cortical Labs',status:'configured',workload};
  }
};
