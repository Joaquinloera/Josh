export const classicalAdapter = {
  id: 'classical',
  async available(){ return true; },
  async execute({workload=null}={}){ return {ok:true,mode:'classical',status:'ready',workload}; }
};
