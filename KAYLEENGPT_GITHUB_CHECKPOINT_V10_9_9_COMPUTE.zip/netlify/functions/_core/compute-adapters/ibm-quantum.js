function env(name){ return globalThis.Netlify?.env?.get?.(name) || process.env?.[name] || ''; }
export const ibmQuantumAdapter = {
  id: 'ibm-quantum',
  async available(){ return Boolean(env('IBM_QUANTUM_TOKEN')); },
  async execute({workload=null}={}){
    if(!await this.available()) throw new Error('IBM Quantum is not configured');
    return {ok:true,mode:'quantum',provider:'IBM Quantum',status:'configured',workload};
  }
};
