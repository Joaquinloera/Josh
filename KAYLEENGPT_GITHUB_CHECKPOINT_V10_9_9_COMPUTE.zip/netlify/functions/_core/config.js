export const VERSION = "3.4.0";
export const MAX_MESSAGE_CHARS = 16000;
export const MAX_MESSAGES = 32;
export const NATIVE_ENGINE_VERSION = "native-core-0.9";
