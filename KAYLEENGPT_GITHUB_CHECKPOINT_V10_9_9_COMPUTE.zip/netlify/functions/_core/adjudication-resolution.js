import crypto from 'node:crypto';
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
export const RESOLUTION_PROTOCOL='CKG-6';
const cap1=s=>s==='KNOWN'?'CAP1:KNOW':s==='REJECTED'?'CAP1:SHADOW':'CAP1:VERIFY';
const clone=v=>structuredClone(v||{protocol:'CKG-3',sequence:0,established:[],rejected:[],contradictions:[],history:[]});
const sourceEntry=(ledger,id)=>[...(ledger.established||[]),...(ledger.rejected||[])].filter(x=>x.claimId===id).sort((a,b)=>Number(b.sequence||0)-Number(a.sequence||0))[0]||null;
export function verifyResolutionEntry(entry){if(entry?.protocol!==RESOLUTION_PROTOCOL)return false;const {digest,...payload}=entry;return digest===sha(JSON.stringify(payload));}
export function applyAdjudicationOutcomes(ledgerInput,adjudication){
 const ledger=clone(ledgerInput), resolutions=[]; let sequence=Number(ledger.sequence||0);
 for(const item of adjudication?.adjudications||[]){
  const r=item?.reconciliation; if(!item?.verified||!r?.digest)continue;
  const source=sourceEntry(ledger,item.claimId); if(!source||source.status!=='DISPUTED')continue;
  const decision=r.decision; const status=decision==='PROMOTE'?'KNOWN':decision==='REJECT'?'REJECTED':'DISPUTED';
  sequence++;
  const payload={protocol:RESOLUTION_PROTOCOL,sequence,claimId:item.claimId,status,decision,claim:source.claim,sourceLedgerDigest:source.digest,adjudicationDigest:r.digest,findingDigests:[...(r.findingDigests||[])],score:r.score,cap1:cap1(status),recordedAt:Date.now()};
  const entry={...payload,digest:sha(JSON.stringify(payload))};
  resolutions.push(entry);
  if(status==='KNOWN')ledger.established.push(entry); else if(status==='REJECTED')ledger.rejected.push(entry);
  ledger.history=ledger.history||[]; ledger.history.push({sequence,claimId:item.claimId,status,decision,digest:entry.digest,protocol:RESOLUTION_PROTOCOL});
 }
 ledger.sequence=sequence; ledger.updatedAt=Date.now(); ledger.adjudicationHistory=[...(ledger.adjudicationHistory||[]),...resolutions].slice(-240);
 const payload={protocol:RESOLUTION_PROTOCOL,sequence,resolutionDigests:resolutions.map(x=>x.digest),adjudicationSummaryDigest:adjudication?.summary?.digest||null};
 return {ledger,resolutions,verified:resolutions.every(verifyResolutionEntry),digest:sha(JSON.stringify(payload)),summary:payload};
}
export function verifyAdjudicationResolution(result){return result?.summary?.protocol===RESOLUTION_PROTOCOL&&result.verified===true&&result.digest===sha(JSON.stringify(result.summary))&&(result.resolutions||[]).every(verifyResolutionEntry);}
