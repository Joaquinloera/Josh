import crypto from 'node:crypto';
import { verifySemanticRouteConfidence } from './semantic-route-confidence.js';
import { verifySemanticOutcome } from './semantic-outcome.js';
import { verifySemanticFeedback } from './semantic-feedback.js';
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v);}
const digestOf=v=>sha(canonical(v));
export const SEMANTIC_ROUTE_ACCOUNTABILITY=Object.freeze({protocol:'NSF-13',version:1});
export function buildSemanticRouteAccountability({confidence,outcome,feedback,routingReceipt=null}={}){
 if(!verifySemanticRouteConfidence(confidence))throw new Error('Invalid semantic route confidence');
 if(!verifySemanticOutcome(outcome))throw new Error('Invalid semantic outcome');
 if(!verifySemanticFeedback(feedback,{outcomeDigest:outcome.digest}))throw new Error('Invalid semantic feedback');
 const learned=confidence.mode==='LEARNED_ACCEPTED';
 const explicit=confidence.mode==='EXPLICIT_OVERRIDE';
 const succeeded=outcome.status==='ACCEPTED'&&outcome.accepted===true;
 let verdict='BASE_OBSERVED';
 if(explicit)verdict=succeeded?'EXPLICIT_SUCCEEDED':'EXPLICIT_FAILED';
 else if(learned)verdict=succeeded?'LEARNED_PROVEN':'LEARNED_FAILED';
 else if(succeeded)verdict='FALLBACK_SUCCEEDED';
 else verdict='FALLBACK_FAILED';
 const body={protocol:'NSF-13',confidenceDigest:confidence.digest,outcomeDigest:outcome.digest,feedbackDigest:feedback.digest,routingReceiptDigest:routingReceipt?.receiptHash||routingReceipt?.digest||null,route:{host:confidence.routeHost||null,agent:confidence.routeAgent||null,source:confidence.source||'base'},confidence:{mode:confidence.mode,accepted:confidence.accepted,selectedStrength:confidence.selectedStrength,margin:confidence.margin},outcome:{status:outcome.status,accepted:outcome.accepted===true},feedback:{action:feedback.action,reinforce:feedback.reinforce===true},verdict,learned,succeeded,cap1:{signal:verdict==='LEARNED_PROVEN'?'ANCESTOR':verdict.endsWith('FAILED')?'VERIFY':'WITNESS',utterance:`STAR ${verdict==='LEARNED_PROVEN'?'ANCESTOR':verdict.endsWith('FAILED')?'VERIFY':'WITNESS'} ROUTE ${confidence.digest.slice(0,16)}`}};
 return {...body,digest:digestOf(body)};
}
export function verifySemanticRouteAccountability(record,{confidenceDigest=null,outcomeDigest=null,feedbackDigest=null}={}){
 if(!record?.digest||record.protocol!=='NSF-13')return false;const {digest,...body}=record;if(digest!==digestOf(body))return false;
 if(confidenceDigest&&record.confidenceDigest!==confidenceDigest)return false;if(outcomeDigest&&record.outcomeDigest!==outcomeDigest)return false;if(feedbackDigest&&record.feedbackDigest!==feedbackDigest)return false;
 const allowed=['BASE_OBSERVED','EXPLICIT_SUCCEEDED','EXPLICIT_FAILED','LEARNED_PROVEN','LEARNED_FAILED','FALLBACK_SUCCEEDED','FALLBACK_FAILED'];if(!allowed.includes(record.verdict))return false;
 if(record.learned!==(record.confidence?.mode==='LEARNED_ACCEPTED'))return false;if(record.succeeded!==(record.outcome?.status==='ACCEPTED'&&record.outcome?.accepted===true))return false;
 if(record.verdict==='LEARNED_PROVEN'&&(!record.learned||!record.succeeded))return false;if(record.verdict==='LEARNED_FAILED'&&(!record.learned||record.succeeded))return false;
 return true;
}
export function semanticRouteAccountabilitySummary(r){return {protocol:r.protocol,digest:r.digest,verdict:r.verdict,learned:r.learned,succeeded:r.succeeded,cap1:r.cap1.signal};}
