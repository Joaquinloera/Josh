import { HOSTS, getHost } from "./hosts.js";
import { getAgent, selectAgents } from "./agents.js";

const KEYWORDS = {
  michael: ["security", "permission", "protect", "risk", "credential", "auth"],
  uriel: ["research", "investigate", "compare", "plan", "why", "find", "learn"],
  saraqael: ["verify", "check", "audit", "analyze", "analyse", "fact", "evidence"],
  gabriel: ["write", "draft", "explain", "present", "message", "email", "rewrite"],
  raphael: ["fix", "recover", "debug", "repair", "improve", "review", "code", "software"],
  raguel: ["consensus", "disagree", "conflict", "policy", "decide", "choose"],
  remiel: ["remember", "previous", "continue", "history", "context", "earlier"],
};

export function chooseHost(message, requestedHost) {
  const explicit = getHost(requestedHost);
  if (explicit) return explicit;

  const text = String(message ?? "").toLowerCase();
  let best = "uriel";
  let bestScore = 0;

  for (const [hostId, words] of Object.entries(KEYWORDS)) {
    const score = words.reduce((total, word) => total + (text.includes(word) ? 1 : 0), 0);
    if (score > bestScore) {
      best = hostId;
      bestScore = score;
    }
  }

  return HOSTS[best];
}

export function routeTask({ message, host, agent } = {}) {
  const explicitAgent = getAgent(agent);
  const selectedHost = explicitAgent ? getHost(explicitAgent.host) : chooseHost(message, host);
  const agents = explicitAgent ? [explicitAgent] : selectAgents(selectedHost.id, { limit: 3 });

  return {
    host: selectedHost,
    agent: agents[0] || null,
    agents,
  };
}
