import crypto from 'node:crypto';
import { verifySemanticTrustProfile } from './semantic-trust.js';
import { verifySemanticStability } from './semantic-stability.js';
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v);}
const digestOf=v=>sha(canonical(v));
export const SEMANTIC_ROUTE_CONFIDENCE=Object.freeze({protocol:'NSF-12',minimumLearnedStrength:.60,minimumMargin:.05});
function baseCandidate(selection,baseRoute){return (selection?.candidates||[]).find(x=>x.source==='base')||{source:'base',host:baseRoute?.host?.id||null,agent:baseRoute?.agent?.id||baseRoute?.agents?.[0]?.id||null,strength:.6,key:null};}
export function applySemanticRouteConfidence({profile,stability,selection,route,baseRoute,explicitRoute=false}={}){
 if(!verifySemanticTrustProfile(profile))throw new Error('Invalid semantic trust profile for route confidence gate');
 if(!verifySemanticStability(stability,{profileDigest:profile.digest}))throw new Error('Invalid semantic stability for route confidence gate');
 const selected=selection?.selected||null,base=baseCandidate(selection,baseRoute),source=selected?.source||'base';
 const selectedStrength=Number(selected?.strength||0),baseStrength=Number(base?.strength||0),margin=Number((selectedStrength-baseStrength).toFixed(6));
 const minStrength=SEMANTIC_ROUTE_CONFIDENCE.minimumLearnedStrength;
 let mode='BASE_CONFIRMED',accepted=true,nextSelection=selection,nextRoute=route;
 if(explicitRoute){mode='EXPLICIT_OVERRIDE';}
 else if(source==='learned'){
   if(!profile.mature){mode='COLD_REJECTED';accepted=false;}
   else if(stability.mode==='QUARANTINED'){mode='QUARANTINED_REJECTED';accepted=false;}
   else if(selectedStrength<minStrength||margin<SEMANTIC_ROUTE_CONFIDENCE.minimumMargin){mode='LOW_CONFIDENCE_REJECTED';accepted=false;}
   else mode='LEARNED_ACCEPTED';
 }
 if(!accepted){const fallback=baseCandidate(selection,baseRoute);nextRoute=baseRoute;nextSelection={...selection,route:baseRoute,selected:fallback,decision:'semantic-confidence-base',rolledBack:true,exploration:false};}
 const body={protocol:'NSF-12',profileDigest:profile.digest,stabilityDigest:stability.digest,stabilityMode:stability.mode,source,selectedStrength,baseStrength,margin,minStrength,minimumMargin:SEMANTIC_ROUTE_CONFIDENCE.minimumMargin,mode,accepted,routeHost:nextRoute?.host?.id||null,routeAgent:nextRoute?.agent?.id||nextRoute?.agents?.[0]?.id||null,cap1:{signal:accepted?'WITNESS':'GUARD',utterance:`STAR ${accepted?'WITNESS':'GUARD'} CONFIDENCE ${stability.digest.slice(0,16)}`}};
 return {selection:nextSelection,route:nextRoute,confidence:{...body,digest:digestOf(body)}};
}
export function verifySemanticRouteConfidence(c,{profileDigest=null,stabilityDigest=null}={}){if(!c?.digest||c.protocol!=='NSF-12')return false;const {digest,...body}=c;if(digest!==digestOf(body))return false;if(profileDigest&&c.profileDigest!==profileDigest)return false;if(stabilityDigest&&c.stabilityDigest!==stabilityDigest)return false;if(!['BASE_CONFIRMED','EXPLICIT_OVERRIDE','COLD_REJECTED','QUARANTINED_REJECTED','LOW_CONFIDENCE_REJECTED','LEARNED_ACCEPTED'].includes(c.mode))return false;if(c.accepted!==!c.mode.endsWith('REJECTED'))return false;return true;}
