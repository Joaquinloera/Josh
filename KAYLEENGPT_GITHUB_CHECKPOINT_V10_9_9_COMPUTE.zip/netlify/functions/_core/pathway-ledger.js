import crypto from 'node:crypto';
import { verifyPathwayAccountability } from './pathway-accountability.js';
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v);}
const digestOf=v=>sha(canonical(v));
const FILTER_BYTES=512,FILTER_HASHES=6;
const blankFilter=()=>Buffer.alloc(FILTER_BYTES);
function decodeFilter(s){if(!s)return blankFilter();try{const b=Buffer.from(s,'base64');return b.length===FILTER_BYTES?b:null;}catch{return null;}}
function positions(d){const h=crypto.createHash('sha256').update(String(d)).digest();const out=[];for(let i=0;i<FILTER_HASHES;i++){const a=h.readUInt32BE((i*4)%28),b=h.readUInt32BE(((i*4)+4)%28);out.push((a+i*b+i*i)%(FILTER_BYTES*8));}return out;}
function addFilter(buf,d){for(const p of positions(d))buf[p>>3]|=1<<(p&7);}
function hasFilter(buf,d){return positions(d).every(p=>(buf[p>>3]&(1<<(p&7)))!==0);}
export const PATHWAY_LEDGER=Object.freeze({protocol:'NSF-16',entryProtocol:'NSF-15-COMMIT',version:1,maxEntries:96,retain:48,filterBytes:FILTER_BYTES,filterHashes:FILTER_HASHES});
export function emptyPathwayLedger(){return {protocol:'NSF-15',sequence:0,head:null,anchor:null,entries:[]};}
function verifyAnchor(a){if(a===null||a===undefined)return true;if(!a||a.protocol!=='NSF-16-CHECKPOINT'||!a.digest)return false;const {digest,...body}=a,f=decodeFilter(a.replayFilter);return !!f&&digest===digestOf(body)&&Number.isInteger(a.throughSequence)&&a.throughSequence>0&&typeof a.throughDigest==='string'&&a.throughDigest.length===64&&Number.isInteger(a.archivedEntries)&&a.archivedEntries>0&&a.filterBytes===FILTER_BYTES&&a.filterHashes===FILTER_HASHES;}
export function verifyPathwayLedger(ledger){
 if(!ledger||ledger.protocol!=='NSF-15'||!Number.isInteger(ledger.sequence)||ledger.sequence<0||!Array.isArray(ledger.entries)||ledger.entries.length>PATHWAY_LEDGER.maxEntries||!verifyAnchor(ledger.anchor))return false;
 let previous=ledger.anchor?.throughDigest||null,lastSequence=ledger.anchor?.throughSequence||0;const seen=new Set();
 for(const entry of ledger.entries){if(entry.protocol!=='NSF-15-COMMIT'||entry.sequence!==lastSequence+1||entry.previous!==previous)return false;const {digest,...body}=entry;if(digest!==digestOf(body)||!entry.adjustmentDigest||!entry.key||seen.has(entry.adjustmentDigest))return false;seen.add(entry.adjustmentDigest);previous=digest;lastSequence=entry.sequence;}
 if(lastSequence!==ledger.sequence)return false;if(ledger.sequence===0)return ledger.head===null&&!ledger.anchor&&ledger.entries.length===0;return ledger.head===previous;
}
export function archivedPathwayReplayPossible(ledger,adjustmentDigest){if(!verifyPathwayLedger(ledger))throw new Error('Invalid pathway accountability ledger');if(!ledger.anchor)return false;const f=decodeFilter(ledger.anchor.replayFilter);return hasFilter(f,adjustmentDigest);}
export function compactPathwayLedger(ledgerInput,{retain=PATHWAY_LEDGER.retain}={}){
 const ledger=structuredClone(ledgerInput);if(!verifyPathwayLedger(ledger))throw new Error('Invalid pathway accountability ledger');if(!Number.isInteger(retain)||retain<1)throw new Error('Invalid pathway ledger retention');if(ledger.entries.length<=retain)return {ledger,compacted:false,anchor:ledger.anchor||null};
 const cut=ledger.entries.length-retain,last=ledger.entries[cut-1],prior=ledger.anchor||null,filter=decodeFilter(prior?.replayFilter);for(const e of ledger.entries.slice(0,cut))addFilter(filter,e.adjustmentDigest);
 const archivedDigests=ledger.entries.slice(0,cut).map(e=>e.digest);const body={protocol:'NSF-16-CHECKPOINT',throughSequence:last.sequence,throughDigest:last.digest,archivedEntries:(prior?.archivedEntries||0)+cut,previousAnchorDigest:prior?.digest||null,firstArchivedSequence:prior?prior.throughSequence+1:1,lastArchivedSequence:last.sequence,archiveDigest:digestOf(archivedDigests),replayFilter:filter.toString('base64'),filterBytes:FILTER_BYTES,filterHashes:FILTER_HASHES,cap1:{signal:'ANCESTOR',utterance:`STAR ANCESTOR PATHWAY-ARCHIVE ${last.digest.slice(0,16)}`}};
 const anchor={...body,digest:digestOf(body)},next={protocol:'NSF-15',sequence:ledger.sequence,head:ledger.head,anchor,entries:ledger.entries.slice(cut)};if(!verifyPathwayLedger(next))throw new Error('Pathway ledger compaction verification failed');return {ledger:next,compacted:true,anchor};
}
export function commitPathwayAccountability(ledgerInput,adjustment){
 let prior=ledgerInput?.protocol==='NSF-15'?structuredClone(ledgerInput):emptyPathwayLedger();if(!verifyPathwayLedger(prior))throw new Error('Invalid pathway accountability ledger');if(!verifyPathwayAccountability(adjustment))throw new Error('Invalid pathway accountability adjustment');
 if(prior.entries.some(e=>e.adjustmentDigest===adjustment.digest)||archivedPathwayReplayPossible(prior,adjustment.digest))throw new Error('Pathway accountability replay rejected');if(prior.entries.length>=PATHWAY_LEDGER.maxEntries)prior=compactPathwayLedger(prior).ledger;if(archivedPathwayReplayPossible(prior,adjustment.digest))throw new Error('Pathway accountability replay rejected');
 const sequence=prior.sequence+1,body={protocol:'NSF-15-COMMIT',sequence,previous:prior.head,adjustmentDigest:adjustment.digest,key:adjustment.key,strength:adjustment.afterStrength,quarantined:adjustment.quarantined,reason:adjustment.reason,cap1:{signal:adjustment.quarantined?'GUARD':'ANCESTOR',utterance:`STAR ${adjustment.quarantined?'GUARD':'ANCESTOR'} PATHWAY-COMMIT ${adjustment.digest.slice(0,16)}`}},entry={...body,digest:digestOf(body)};
 const out={...prior,sequence,head:entry.digest,entries:[...prior.entries,entry]};if(!verifyPathwayLedger(out))throw new Error('Pathway accountability ledger commit verification failed');return {ledger:out,entry};
}
export function pathwayLedgerSummary(ledger){return {protocol:'NSF-16',ledgerProtocol:ledger.protocol,sequence:ledger.sequence,head:ledger.head,entries:ledger.entries.length,archived:ledger.anchor?.archivedEntries||0,anchorDigest:ledger.anchor?.digest||null,replayShield:ledger.anchor?'BLOOM-4096x6':'EMPTY'};}
