import crypto from 'node:crypto';
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
const clip=(v,n=1600)=>String(v??'').trim().slice(0,n);
export const ADJUDICATION_PROTOCOL='CKG-5';
function finding({claim,agentId,role,position,sequence}){
  const evidence=clip(claim?.claim?.evidence||'');
  const provenance=claim?.claim?.provenance||null;
  const evidenceStrength=Math.min(1,evidence.length/120);
  const provenanceStrength=provenance?.sourceId?.length?1:0;
  const score=Number((evidenceStrength*.55+provenanceStrength*.45).toFixed(4));
  const payload={protocol:ADJUDICATION_PROTOCOL,claimId:claim.id,ledgerDigest:claim.ledgerDigest,agentId,role,position,sequence,evidenceDigest:sha(evidence),provenanceDigest:sha(JSON.stringify(provenance||{})),score,cap1:position==='CHALLENGE'?'CAP1:VERIFY':'CAP1:WITNESS'};
  return {...payload,digest:sha(JSON.stringify(payload))};
}
export function verifyFinding(f){if(f?.protocol!==ADJUDICATION_PROTOCOL)return false;const {digest,...p}=f;return digest===sha(JSON.stringify(p));}
export function adjudicateDisputedClaim(claim,{agents=['uriel','raphael','saraqael']}={}){
  const pool=[...new Set([...(agents||[]),'uriel','raphael','saraqael','native-reviewer'])];
  const a=finding({claim,agentId:pool[0],role:'independent-evidence-reviewer',position:'CHALLENGE',sequence:1});
  const b=finding({claim,agentId:pool.find(x=>x!==pool[0]),role:'independent-provenance-reviewer',position:'WITNESS',sequence:2});
  const independent=a.agentId!==b.agentId;
  const bothVerified=verifyFinding(a)&&verifyFinding(b);
  const mean=Number(((a.score+b.score)/2).toFixed(4));
  const decision=bothVerified&&independent&&mean>=.72?'PROMOTE':mean<.45?'REJECT':'HOLD_DISPUTED';
  const reconciliationPayload={protocol:ADJUDICATION_PROTOCOL,claimId:claim.id,findingDigests:[a.digest,b.digest],reconciler:pool.find(x=>x!==a.agentId&&x!==b.agentId)||'native-consensus',independent,bothVerified,score:mean,decision,cap1:decision==='PROMOTE'?'CAP1:KNOW':decision==='REJECT'?'CAP1:SHADOW':'CAP1:VERIFY'};
  const reconciliation={...reconciliationPayload,digest:sha(JSON.stringify(reconciliationPayload))};
  return {protocol:ADJUDICATION_PROTOCOL,claimId:claim.id,findings:[a,b],reconciliation,verified:verifyAdjudication({protocol:ADJUDICATION_PROTOCOL,claimId:claim.id,findings:[a,b],reconciliation})};
}
export function verifyAdjudication(a){if(a?.protocol!==ADJUDICATION_PROTOCOL||a.findings?.length!==2)return false;if(!a.findings.every(verifyFinding))return false;const r=a.reconciliation;if(r?.protocol!==ADJUDICATION_PROTOCOL||r.claimId!==a.claimId)return false;const {digest,...p}=r;if(digest!==sha(JSON.stringify(p)))return false;if(new Set(a.findings.map(x=>x.agentId)).size!==2)return false;return r.findingDigests.every((d,i)=>d===a.findings[i].digest)&&r.bothVerified===true&&r.independent===true;}
export function adjudicateVerificationQueue(queue=[],opts={}){const adjudications=queue.slice(0,4).map(c=>adjudicateDisputedClaim(c,opts));const payload={protocol:ADJUDICATION_PROTOCOL,items:adjudications.map(a=>({claimId:a.claimId,decision:a.reconciliation.decision,digest:a.reconciliation.digest})),cap1:'CAP1:VERIFY'};return {adjudications,summary:{...payload,digest:sha(JSON.stringify(payload))},verified:adjudications.every(verifyAdjudication)};}
