import crypto from 'node:crypto';
import { verifyLearningBoundLearningAdmission } from './learning-bound-learning-admission.js';
import { verifyPathwayLearningFulfillment } from './pathway-learning-fulfillment.js';

const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v)}
const digestOf=v=>sha(canonical(v));

export const LEARNING_BOUND_LEARNING_FULFILLMENT=Object.freeze({protocol:'NSF-36',version:1,mode:'learning-lineage-bound-learning-fulfillment',failClosed:true});

export function buildLearningBoundLearningFulfillment({admission,fulfillment,receipt}={}){
  const admissionVerified=verifyLearningBoundLearningAdmission(admission)&&admission?.admitted===true;
  const fulfillmentVerified=verifyPathwayLearningFulfillment(fulfillment)&&fulfillment?.fulfilled===true;
  const receiptBound=Boolean(receipt?.receiptHash)&&fulfillment?.receiptHash===receipt?.receiptHash&&fulfillment?.pathwayKey===receipt?.key;
  const sequenceBound=Number(fulfillment?.sequence||0)===Number(admission?.executionLedgerSequence||0);
  const learnedExecution=admission?.sealAdmissionProtocol==='NSF-31';
  const lineageComplete=!learnedExecution||Boolean(admission?.learningLineageDigest&&admission?.sourceLearningLedgerHead&&Number(admission?.sourceLearningLedgerSequence||0)>0);
  const fulfilled=admissionVerified&&fulfillmentVerified&&receiptBound&&sequenceBound&&lineageComplete;
  const body={protocol:'NSF-36',version:1,status:fulfilled?'FULFILLED':'DENIED',fulfilled,learningAdmissionDigest:admission?.digest||null,baseFulfillmentDigest:fulfillment?.digest||null,receiptHash:receipt?.receiptHash||null,pathwayKey:receipt?.key||null,executionEntryDigest:admission?.executionEntryDigest||null,executionLedgerHead:admission?.executionLedgerHead||null,executionLedgerSequence:Number(admission?.executionLedgerSequence||0),sealAdmissionProtocol:admission?.sealAdmissionProtocol||'NSF-19',learningLineageDigest:admission?.learningLineageDigest||null,sourceLearningLedgerHead:admission?.sourceLearningLedgerHead||null,sourceLearningLedgerSequence:Number(admission?.sourceLearningLedgerSequence||0),bindings:{admissionVerified,fulfillmentVerified,receiptBound,sequenceBound,learnedExecution,lineageComplete},cap1:{signal:fulfilled?'WITNESS':'GUARD',utterance:fulfilled?'STAR WITNESS LEARNING-LINEAGE FULFILLMENT VERIFIED':'STAR GUARD LEARNING-LINEAGE FULFILLMENT DENIED'}};
  return {...body,digest:digestOf(body)};
}

export function verifyLearningBoundLearningFulfillment(record,{admission,fulfillment,receipt}={}){
  if(!record?.digest||record.protocol!=='NSF-36'||record.version!==1)return false;
  const {digest,...body}=record;if(digest!==digestOf(body))return false;
  const b=record.bindings||{};const expected=b.admissionVerified===true&&b.fulfillmentVerified===true&&b.receiptBound===true&&b.sequenceBound===true&&b.lineageComplete===true;
  if(record.fulfilled!==expected||record.status!==(expected?'FULFILLED':'DENIED')||record.cap1?.signal!==(expected?'WITNESS':'GUARD'))return false;
  if(admission){if(!verifyLearningBoundLearningAdmission(admission)||record.learningAdmissionDigest!==admission.digest||record.learningLineageDigest!==admission.learningLineageDigest||record.sourceLearningLedgerHead!==admission.sourceLearningLedgerHead||record.sourceLearningLedgerSequence!==admission.sourceLearningLedgerSequence||record.executionEntryDigest!==admission.executionEntryDigest)return false;}
  if(fulfillment){if(!verifyPathwayLearningFulfillment(fulfillment)||record.baseFulfillmentDigest!==fulfillment.digest||record.receiptHash!==fulfillment.receiptHash||record.pathwayKey!==fulfillment.pathwayKey)return false;}
  if(receipt&&(record.receiptHash!==receipt.receiptHash||record.pathwayKey!==receipt.key))return false;
  return true;
}

export function learningBoundLearningFulfillmentSummary(r){return {protocol:r.protocol,status:r.status,fulfilled:r.fulfilled,pathwayKey:r.pathwayKey,sealAdmissionProtocol:r.sealAdmissionProtocol,learningLineageDigest:r.learningLineageDigest,sourceLearningLedgerHead:r.sourceLearningLedgerHead,sourceLearningLedgerSequence:r.sourceLearningLedgerSequence,cap1:r.cap1,verified:verifyLearningBoundLearningFulfillment(r)};}
