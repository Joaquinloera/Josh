import crypto from 'node:crypto';
import { formSemanticFrame, verifySemanticFrame } from './semantic-formation.js';

function sha(v){return crypto.createHash('sha256').update(String(v)).digest('hex');}
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v);}
const REF=/\b(it|this|that|they|them|those|these|same|previous|earlier|continue)\b/i;
const CORRECTION=/\b(?:actually|instead|correction|change that|not that|rather)\b/i;
const CONTINUATION=/\b(?:continue|next|keep going|keep building|same|again)\b/i;

function priorFrames(messages){return (messages||[]).filter(x=>x?.role==='user'&&String(x.content||'').trim()).slice(-6).map((x,i)=>{const frame=formSemanticFrame(x.content);return {turn:i+1,digest:sha(x.content),intent:frame.intent,concepts:frame.concepts.slice(0,6).map(c=>c.label),entities:frame.entities.slice(0,4).map(e=>e.label)};});}
function unique(xs,limit){return [...new Set(xs.filter(Boolean))].slice(0,limit);}
export function buildSemanticContext(message,{conversation=[]}={}){
  const current=formSemanticFrame(message,{context:conversation});
  if(!verifySemanticFrame(current))throw new Error('Invalid base semantic frame');
  const prior=priorFrames(conversation), last=prior.at(-1)||null;
  const referenceRequested=REF.test(message), continuation=CONTINUATION.test(message), correction=CORRECTION.test(message);
  const inheritedConcepts=(referenceRequested||continuation)&&last?last.concepts:[];
  const inheritedEntities=(referenceRequested||continuation)&&last?last.entities:[];
  const resolvedConcepts=unique([...current.concepts.map(c=>c.label),...inheritedConcepts],16);
  const resolvedEntities=unique([...current.entities.map(e=>e.label),...inheritedEntities],12);
  const dialogueAct=correction?'CORRECT':continuation?'CONTINUE':current.question?'ASK':current.intent==='BUILD'?'DIRECT':'STATE';
  const state={protocol:'NSF-2',baseDigest:current.digest,dialogueAct,referenceRequested,referenceSource:last?.digest||null,resolvedConcepts,resolvedEntities,priorTurnDigests:prior.map(x=>x.digest),cap1:{signal:correction?'VERIFY':continuation?'ANCESTOR':referenceRequested?'WITNESS':current.cap1.signal,utterance:`STAR ${correction?'VERIFY':continuation?'ANCESTOR':referenceRequested?'WITNESS':current.cap1.signal} PATH ${resolvedConcepts.slice(0,5).map(x=>x.toUpperCase()).join(' ')}`.trim()}};
  state.digest=sha(canonical(state));
  return {frame:current,state};
}
export function verifySemanticContext(value){if(!value?.state||value.state.protocol!=='NSF-2'||!value.state.digest||!verifySemanticFrame(value.frame))return false;const {digest,...body}=value.state;return digest===sha(canonical(body))&&value.state.baseDigest===value.frame.digest&&value.state.resolvedConcepts.length<=16&&value.state.resolvedEntities.length<=12&&value.state.priorTurnDigests.length<=6;}
export function semanticContextSummary(value){return {protocol:value.state.protocol,dialogueAct:value.state.dialogueAct,referenceRequested:value.state.referenceRequested,resolvedConcepts:value.state.resolvedConcepts,resolvedEntities:value.state.resolvedEntities,cap1:value.state.cap1.signal,digest:value.state.digest};}
