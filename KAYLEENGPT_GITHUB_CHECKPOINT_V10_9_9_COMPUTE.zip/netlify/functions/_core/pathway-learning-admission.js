import crypto from 'node:crypto';
import { verifyPathwayExecutionAttestation } from './pathway-execution-attestation.js';
import { verifySemanticOutcome } from './semantic-outcome.js';

const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v)}
const digestOf=v=>sha(canonical(v));

export const PATHWAY_LEARNING_ADMISSION=Object.freeze({protocol:'NSF-25',version:1,mode:'durable-execution-learning-admission',failClosed:true});

export function buildPathwayLearningAdmission({attestation,outcome,sequence=0}={}){
  const executionVerified=verifyPathwayExecutionAttestation(attestation)&&attestation?.durable===true;
  const outcomeVerified=verifySemanticOutcome(outcome);
  const outcomeAccepted=outcomeVerified&&outcome?.accepted===true&&outcome?.status==='ACCEPTED';
  const admitted=executionVerified&&outcomeAccepted;
  const body={protocol:'NSF-25',version:1,status:admitted?'ADMITTED':'DENIED',admitted,sequence:Number(sequence)||0,attestationDigest:attestation?.digest||null,executionEntryDigest:attestation?.entryDigest||null,executionLedgerHead:attestation?.ledgerHead||null,executionLedgerSequence:attestation?.ledgerSequence||0,outcomeDigest:outcome?.digest||null,outcomeStatus:outcome?.status||'INVALID',outputDigest:outcome?.outputDigest||null,bindings:{executionVerified,outcomeVerified,outcomeAccepted},cap1:{signal:admitted?'ANCESTOR':'GUARD',utterance:admitted?'STAR ANCESTOR LEARNING-ADMISSION VERIFIED':'STAR GUARD LEARNING-ADMISSION DENIED'}};
  return {...body,digest:digestOf(body)};
}

export function verifyPathwayLearningAdmission(admission,{attestation,outcome}={}){
  if(!admission?.digest||admission.protocol!=='NSF-25'||admission.version!==1)return false;
  const {digest,...body}=admission;if(digest!==digestOf(body))return false;
  const expected=admission.bindings?.executionVerified===true&&admission.bindings?.outcomeVerified===true&&admission.bindings?.outcomeAccepted===true;
  if(admission.admitted!==expected||admission.status!==(expected?'ADMITTED':'DENIED'))return false;
  if(admission.cap1?.signal!==(expected?'ANCESTOR':'GUARD'))return false;
  if(attestation){if(!verifyPathwayExecutionAttestation(attestation)||admission.attestationDigest!==attestation.digest||admission.executionEntryDigest!==attestation.entryDigest||admission.executionLedgerHead!==attestation.ledgerHead||admission.executionLedgerSequence!==attestation.ledgerSequence)return false;}
  if(outcome){if(!verifySemanticOutcome(outcome)||admission.outcomeDigest!==outcome.digest||admission.outcomeStatus!==outcome.status||admission.outputDigest!==outcome.outputDigest)return false;}
  return true;
}

export function pathwayLearningAdmissionSummary(a){return {protocol:a.protocol,status:a.status,admitted:a.admitted,sequence:a.sequence,attestationDigest:a.attestationDigest,outcomeDigest:a.outcomeDigest,cap1:a.cap1,verified:verifyPathwayLearningAdmission(a)};}
