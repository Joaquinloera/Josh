import { json, readJSONBody } from './_core/http.js';
import { requireSession } from './_core/auth.js';
import { readNativeMemory, addKnowledge, retrieveKnowledge, memorySummary } from './_core/knowledge.js';
export default async function handler(req){let session;try{session=await requireSession(req)}catch{return json({ok:false,error:'AUTH_REQUIRED'},401)}
 if(req.method==='GET'){const state=await readNativeMemory(session.email), q=new URL(req.url).searchParams.get('q')||''; return json({ok:true,summary:memorySummary(state),knowledge:q?retrieveKnowledge(state,q,{limit:10}):state.knowledge.slice(-50),tasks:state.tasks.slice(-30),workProducts:state.products.slice(-60)});}
 if(req.method==='POST'){let body;try{body=await readJSONBody(req)}catch(error){return json({ok:false,error:error.message||'Request body must be valid JSON.'},error.status||400)} if(body?.action!=='addKnowledge')return json({ok:false,error:'Unsupported action'},400); if(!String(body?.content||'').trim())return json({ok:false,error:'Knowledge content required'},400); const item=await addKnowledge(session.email,body); return json({ok:true,item},201);}
 return json({ok:false,error:'Method not allowed'},405);}

export const config = { path: "/api/memory" };
