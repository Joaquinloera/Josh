import { AGENTS, AGENT_IDS } from "./_core/agents.js";
import { VERSION, NATIVE_ENGINE_VERSION } from "./_core/config.js";
import { languageDescriptor } from "./_core/agent-language.js";
import { HOSTS } from "./_core/hosts.js";
import { json } from "./_core/http.js";

export default async function handler(req) {
  if (req.method !== "GET") return json({ ok: false, error: "GET required" }, 405);
  return json({
    ok: true,
    name: "JoshGPT",
    version: VERSION,
    runtimeMode: "JOSHGPT_NATIVE",
    externalAIProviders: [],
    inferenceLayer: { id: NATIVE_ENGINE_VERSION, trainedFoundationModelInstalled: false, pipeline: ["classify", "plan", "working-memory", "tool-select", "permission-check", "tool-execute", "inspect", "replan", "task-graph", "agent-produce", "verified-handoff", "agent-review", "reconcile", "evaluate", "synthesize"], externalAIProviders: [], agentLanguage: languageDescriptor() },
    hosts: Object.values(HOSTS),
    agents: AGENT_IDS.map((id) => AGENTS[id]),
    identity: { portal: true, serverSessionGate: true, passkeyVerification: true, accountPersistence: "site-wide-server-store", multiDeviceAccounts: true, sessionStorage: "opaque-server-session", biometricPasskeys: "server-verified" },
  });
}

export const config = { path: "/api/runtime" };
