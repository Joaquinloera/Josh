import { json, readJSONBody } from './_core/http.js';
import { requireSession } from './_core/auth.js';
import { listCapabilities, executeCapability } from './_core/tools.js';
import { enqueueAgentWork, settleAgentWork } from './_core/knowledge.js';

export default async function handler(req) {
  let session; try { session = await requireSession(req); } catch { return json({ ok:false, error:'AUTH_REQUIRED' },401); }
  if (req.method === 'GET') return json({ ok:true, capabilities:listCapabilities() });
  if (req.method !== 'POST') return json({ ok:false,error:'Method not allowed' },405);
  let body; try { body=await readJSONBody(req); } catch (error) { return json({ok:false,error:error.message||'Request body must be valid JSON.'},error.status||400); }
  const capability=String(body?.capability||'');
  const queued=await enqueueAgentWork(session.email,{taskId:body?.taskId||null,agentId:String(body?.agentId||'native').slice(0,80),capability,input:body?.input});
  const receipt=executeCapability(capability,body?.input,{authenticated:true,accountEmail:session.email});
  const settled=await settleAgentWork(session.email,queued.id,{status:receipt.ok?'completed':'rejected',result:receipt.result,error:receipt.error});
  return json({ok:receipt.ok,receipt,queue:{id:settled.id,status:settled.status}},receipt.ok?200:400);
}

export const config = { path: "/api/tools" };
