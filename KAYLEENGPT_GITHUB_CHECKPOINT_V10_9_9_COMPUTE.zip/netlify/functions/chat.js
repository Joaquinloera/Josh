import { AGENT_IDS } from "./_core/agents.js";
import { VERSION } from "./_core/config.js";
import { cleanMessages, validateConversation } from "./_core/conversation.js";
import { HOSTS } from "./_core/hosts.js";
import { json, readJSONBody } from "./_core/http.js";
import { executeJoshGPT } from "./_core/runtime.js";
import { requireSession } from "./_core/auth.js";

export default async function handler(req) {
  if (req.method === "GET") {
    return json({
      ok: true,
      name: "JoshGPT",
      version: VERSION,
      runtimeMode: "JOSHGPT_NATIVE",
      externalProviders: false,
      hosts: Object.values(HOSTS).map((host) => ({ id: host.id, name: host.name, role: host.role })),
      agents: AGENT_IDS,
    });
  }

  if (req.method !== "POST") return json({ ok: false, error: "POST required" }, 405);

  let session; try { session = await requireSession(req); } catch { return json({ ok: false, error: "AUTH_REQUIRED" }, 401); }

  try {
    let body;
    try {
      body = await readJSONBody(req);
    } catch (error) {
      return json({ ok: false, error: error.message || "Request body must be valid JSON." }, error.status || 400);
    }

    const messages = cleanMessages(body?.messages);
    const validationError = validateConversation(messages);
    if (validationError) return json({ ok: false, error: validationError }, 400);

    const result = await executeJoshGPT({
      messages,
      host: body?.host,
      agent: body?.agent,
      accountEmail: session.email,
    });

    return json({ ok: true, ...result });
  } catch (error) {
    const message = error?.name === "AbortError"
      ? "JoshGPT request timed out."
      : String(error?.message || "JoshGPT request failed");

    return json({ ok: false, error: message }, 500);
  }
}

export const config = { path: "/api/chat" };
