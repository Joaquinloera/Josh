import crypto from 'node:crypto';
import { openJoshStore } from './_core/blob-store.js';
import { json, readJSONBody } from './_core/http.js';
import { requireSession } from './_core/auth.js';

const STORE='joshgpt-user-data-v1';
const digest=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
const key=email=>`user/${digest(email)}/state`;
const MAX_CHATS=100, MAX_MESSAGES=200, MAX_CONTENT=100000;
const cleanText=(v,n)=>String(v??'').slice(0,n);
function cleanChats(input){
  if(!Array.isArray(input)) return [];
  return input.slice(0,MAX_CHATS).map(c=>({
    id:cleanText(c?.id,80)||crypto.randomUUID(),
    title:cleanText(c?.title,120)||'New chat',
    updated:Number.isFinite(Number(c?.updated))?Number(c.updated):Date.now(),
    messages:Array.isArray(c?.messages)?c.messages.slice(-MAX_MESSAGES).map(m=>({role:m?.role==='assistant'?'assistant':'user',content:cleanText(m?.content,MAX_CONTENT)})):[]
  }));
}
export default async function handler(req){
  let session; try{session=await requireSession(req)}catch{return json({ok:false,error:'AUTH_REQUIRED'},401)}
  const store=openJoshStore(STORE), k=key(session.email);
  if(req.method==='GET'){
    const state=await store.get(k,{type:'json'});
    return json({ok:true,chats:cleanChats(state?.chats||[]),updatedAt:state?.updatedAt||null});
  }
  if(req.method==='PUT'||req.method==='POST'){
    let body; try{body=await readJSONBody(req)}catch(error){return json({ok:false,error:error.message||'Request body must be valid JSON.'},error.status||400)}
    const chats=cleanChats(body?.chats), updatedAt=Date.now();
    await store.setJSON(k,{schema:1,chats,updatedAt});
    return json({ok:true,chats,updatedAt});
  }
  if(req.method==='DELETE'){
    await store.delete(k); return json({ok:true});
  }
  return json({ok:false,error:'Method not allowed'},405);
}

export const config = { path: "/api/data" };
