# JoshGPT Native Portal V4.7 — NSF-15 Pathway Accountability Ledger

Adds durable, replay-resistant pathway accountability history. NSF-14 adjustments are committed to an SHA-256-bound monotonic ledger before persistence. The memory writer now preserves accountability history and its ledger (fixing the V4.6 persistence gap where those fields could be dropped during normalization). Future runtime state can therefore retain verified pathway strength/quarantine lineage across requests.

This remains a source checkpoint, not the normalized Netlify deployment artifact.
