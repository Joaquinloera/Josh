# JoshGPT Native Portal v1.6

Additive checkpoint over v1.5.

- Native Core advanced to `native-core-0.6`.
- Planner now selects only registered deterministic capabilities for explicit matching requests.
- Selected work is persisted to the account-scoped agent queue before execution.
- Existing capability authorization remains the execution gate.
- Receipts are inspected before synthesis and persisted as completed/failed queue state.
- One bounded JSON replan/retry path is supported; there are no unbounded retry loops.
- Verified tool results feed directly into JoshGPT final synthesis.
- Ordinary conversation does not trigger tools.
- No external AI provider dependency is introduced.

This remains a deterministic native runtime checkpoint; JoshGPT-trained foundation-model weights are not claimed or installed.
