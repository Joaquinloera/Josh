import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { applyPathwayAccountability } from '../netlify/functions/_core/pathway-accountability.js';
import { emptyPathwayLedger,commitPathwayAccountability,compactPathwayLedger } from '../netlify/functions/_core/pathway-ledger.js';
import { buildPathwayInventoryAttestation,verifyPathwayInventoryAttestation,pathwayInventoryAttestationSummary } from '../netlify/functions/_core/pathway-inventory-attestation.js';
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v)}
const digestOf=v=>crypto.createHash('sha256').update(canonical(v)).digest('hex');
function acct(i,verdict='LEARNED_PROVEN'){const body={protocol:'NSF-13',confidenceDigest:'c'+i,outcomeDigest:'o'+i,feedbackDigest:'f'+i,routingReceiptDigest:null,route:{host:'h',agent:'a',source:'learned'},confidence:{mode:'LEARNED_ACCEPTED',accepted:true,selectedStrength:.8,margin:.2},outcome:{status:'ACCEPTED',accepted:true},feedback:{action:'REINFORCE',reinforce:true},verdict,learned:true,succeeded:verdict==='LEARNED_PROVEN',cap1:{signal:'ANCESTOR',utterance:'x'}};return {...body,digest:digestOf(body)}}
const key='general:native:native';let ledger=emptyPathwayLedger();let p={strength:.5};const a=applyPathwayAccountability({accountability:acct(1),key,previous:p});ledger=commitPathwayAccountability(ledger,a).ledger;const pathways={[key]:{strength:a.afterStrength,quarantined:a.quarantined,failures:a.failures,successes:a.successes,lastAccountabilityDigest:a.digest}};
let n=0;const ok=(name,fn)=>{fn();console.log(`PASS ${++n}: ${name}`)};const att=buildPathwayInventoryAttestation({pathways,ledger});
ok('inventory attestation uses NSF-18',()=>assert.equal(att.protocol,'NSF-18'));
ok('complete inventory verifies',()=>assert.equal(att.verified,true));
ok('cryptographic verification passes',()=>assert(verifyPathwayInventoryAttestation(att,{ledger})));
ok('retained accountability proves pathway',()=>assert.equal(att.checks[0].proof,'RETAINED'));
ok('inventory digest is SHA-256 sized',()=>assert.equal(att.inventoryDigest.length,64));
ok('CAP-1 WITNESS marks verified inventory',()=>assert.equal(att.cap1.signal,'WITNESS'));
ok('unaccounted extra pathway fails closed',()=>{const x={...pathways,evil:{strength:.99,quarantined:false,lastAccountabilityDigest:'x'}};assert.equal(buildPathwayInventoryAttestation({pathways:x,ledger}).verified,false)});
ok('missing retained pathway fails closed',()=>assert.equal(buildPathwayInventoryAttestation({pathways:{},ledger}).verified,false));
ok('wrong accountability digest fails closed',()=>{const x=structuredClone(pathways);x[key].lastAccountabilityDigest='0'.repeat(64);assert.equal(buildPathwayInventoryAttestation({pathways:x,ledger}).verified,false)});
ok('retained state drift fails closed',()=>{const x=structuredClone(pathways);x[key].strength=.01;assert.equal(buildPathwayInventoryAttestation({pathways:x,ledger}).verified,false)});
ok('attestation tamper invalidates digest',()=>{const x=structuredClone(att);x.verified=false;assert.equal(verifyPathwayInventoryAttestation(x,{ledger}),false)});
ok('summary exposes inventory checkpoint',()=>{const s=pathwayInventoryAttestationSummary(att);assert.equal(s.protocol,'NSF-18');assert.equal(s.verified,true);assert.equal(s.checked,1)});
console.log(`NSF-18 contracts: ${n}/12 PASS`);
