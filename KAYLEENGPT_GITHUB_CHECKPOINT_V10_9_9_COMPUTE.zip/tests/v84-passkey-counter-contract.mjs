import fs from 'node:fs';
const core=fs.readFileSync('netlify/functions/_core/auth.js','utf8')+'\n'+fs.readFileSync('netlify/functions/_core/webauthn-registration.js','utf8');
const route=fs.readFileSync('netlify/functions/auth.js','utf8');
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const checks=[
 ['package retains V8.4+ feature line',Number(pkg.version.split('.')[0])>8||(Number(pkg.version.split('.')[0])===8&&Number(pkg.version.split('.')[1])>=4)],
 ['registration reads authenticator sign counter',/signCount:auth\.readUInt32BE\(33\)/.test(core)],
 ['registration returns sign counter',/publicKeySpki:b64u\(derivedSpki\),signCount:/.test(core)],
 ['enrollment persists initial counter',/signCount:verified\.signCount/.test(route)],
 ['assertion reads authenticator counter',/const signCount=auth\.readUInt32BE\(33\)/.test(core)],
 ['assertion reads persisted counter',/previous=Number\(account\.passkey\.signCount\|\|0\)/.test(core)],
 ['non-increasing positive counter fails closed',/signCount<=previous\) throw new Error\('WEBAUTHN_SIGN_COUNT_INVALID'\)/.test(core)],
 ['zero-counter authenticators remain compatible',/previous>0&&signCount>0&&signCount<=previous/.test(core)],
 ['verified assertion returns counter',/return \{signCount\};/.test(core)],
 ['login stores verified counter',/a\.passkey\.signCount=assertion\.signCount/.test(route)],
 ['account saved before success response',/signCount=assertion\.signCount;await saveAccount\(a\);await authThrottleSuccess/.test(route)],
 ['V8.4 contract is in preflight',pkg.scripts.preflight.includes('v84-passkey-counter-contract.mjs')]
];
let n=0; for(const [name,ok] of checks){console.log(`${ok?'PASS':'FAIL'}: ${name}`); if(ok)n++;}
console.log(`${n}/${checks.length} V8.4 contracts passed`); if(n!==checks.length)process.exit(1);
