import assert from 'node:assert/strict';
import { runNative } from '../netlify/functions/_core/native-engine.js';
import { routeTask } from '../netlify/functions/_core/orchestrator.js';
const cases = [
  ['debug this javascript api bug','software'],
  ['check passkey security','security'],
  ['research and compare evidence','research'],
  ['draft an email','writing'],
  ['make a roadmap and next steps','planning'],
  ['tell me something','general'],
];
for (const [text,intent] of cases) {
  const messages=[{role:'user',content:text}];
  const r=await runNative({messages,route:routeTask({message:text})});
  assert.equal(r.provider,'JOSHGPT_NATIVE'); assert.match(r.model,/^native-core-0\.[5-9]$/); assert.equal(r.native.intent,intent); assert.equal(r.native.foundationModelInstalled,false); assert.ok(r.output.length>20);
}
const continuity=await runNative({messages:[{role:'user',content:'first'},{role:'assistant',content:'x'},{role:'user',content:'next plan'}],route:routeTask({message:'next plan'})});
assert.equal(continuity.native.contextTurns,2);
console.log('v1.2 native engine contract: 7/7 PASS');
