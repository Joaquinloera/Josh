import { readFileSync } from 'node:fs';
const src=readFileSync('scripts/final-release-authorization.mjs','utf8');
const pkg=JSON.parse(readFileSync('package.json','utf8'));
const checks=[
 ['version',/^10\.(?:8|9)\.\d+$/.test(pkg.version)],
 ['protocol',src.includes('JOSHGPT-FINAL-RELEASE-AUTHORIZATION-1')],
 ['target',src.includes("project:'joshgpt13'")],
 ['site',src.includes('322db469-6833-4187-b023-60638716b3c7')],
 ['corporate exclusion',src.includes('DO_NOT_DEPLOY_OR_MODIFY')],
 ['fail closed',src.includes('failClosed:true')],
 ['no lock fabrication',src.includes('noLockFabrication:true')],
 ['genuine lock required',src.includes('requiresGenuineDependencyLock:true')],
 ['manifest binding',src.includes("manifest?.files?.['package-lock.json'] === lockSha256")],
 ['decision integrity',src.includes('RELEASE_DECISION_INTEGRITY_READY')],
 ['sha256 authorization',src.includes("createHash('sha256')")],
 ['authorization gate',src.includes("status === 'FINAL_RELEASE_AUTHORIZED' ? 0 : 2")]
];
for(const [n,ok] of checks){if(!ok)throw new Error('FAIL '+n)}
console.log(`V10.8 final release authorization contract: ${checks.length}/${checks.length} PASS`);
