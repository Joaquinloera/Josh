import assert from 'node:assert/strict';
import { emptyEpistemicLedger, applyEpistemicCycle, verifyLedgerEntry, ledgerSummary, KNOWLEDGE_STATES } from '../netlify/functions/_core/epistemic-ledger.js';
const claim=(id,status='ESTABLISHED',predicate='SUPPORTS',score=.9)=>({candidateId:id,status,score,challengeDigest:`ch-${id}`,claim:{id,subject:'Raphael',predicate,object:'software',evidence:'verified work product evidence',provenance:{sourceId:`src-${id}`},confidence:.8}});
const cycle=(...decisions)=>({decisions,verified:true});
const tests=[
 ['protocol initializes',()=>assert.equal(emptyEpistemicLedger().protocol,'CKG-3')],
 ['five knowledge states exist',()=>assert.deepEqual(KNOWLEDGE_STATES,['KNOWN','CANDIDATE','DISPUTED','REJECTED','SUPERSEDED'])],
 ['established decision persists as known',()=>{const x=applyEpistemicCycle(emptyEpistemicLedger(),cycle(claim('a')));assert.equal(x.ledger.established[0].status,'KNOWN')}],
 ['rejected decision archives separately',()=>{const x=applyEpistemicCycle(emptyEpistemicLedger(),cycle(claim('r','REJECTED')));assert.equal(x.ledger.rejected.length,1)}],
 ['ledger entry verifies',()=>{const x=applyEpistemicCycle(emptyEpistemicLedger(),cycle(claim('a')));assert.equal(verifyLedgerEntry(x.newEntries[0]),true)}],
 ['tampered entry fails',()=>{const x=applyEpistemicCycle(emptyEpistemicLedger(),cycle(claim('a')));x.newEntries[0].score=.1;assert.equal(verifyLedgerEntry(x.newEntries[0]),false)}],
 ['sequence is monotonic',()=>{let x=applyEpistemicCycle(emptyEpistemicLedger(),cycle(claim('a')));x=applyEpistemicCycle(x.ledger,cycle(claim('b')));assert.equal(x.ledger.sequence,2)}],
 ['history records decisions',()=>{const x=applyEpistemicCycle(emptyEpistemicLedger(),cycle(claim('a'),claim('b','REJECTED')));assert.equal(x.ledger.history.length,2)}],
 ['conflicting predicate becomes disputed',()=>{let x=applyEpistemicCycle(emptyEpistemicLedger(),cycle(claim('a')));x=applyEpistemicCycle(x.ledger,cycle(claim('b','ESTABLISHED','CONTRADICTS')));assert.equal(x.newEntries[0].status,'DISPUTED')}],
 ['contradiction history persists',()=>{let x=applyEpistemicCycle(emptyEpistemicLedger(),cycle(claim('a')));x=applyEpistemicCycle(x.ledger,cycle(claim('b','ESTABLISHED','CONTRADICTS')));assert.equal(x.ledger.contradictions.length,1)}],
 ['CAP-1 state signal attached',()=>{const x=applyEpistemicCycle(emptyEpistemicLedger(),cycle(claim('a')));assert.equal(x.newEntries[0].cap1,'CAP1:KNOW')}],
 ['summary separates epistemic states',()=>{let x=applyEpistemicCycle(emptyEpistemicLedger(),cycle(claim('a'),claim('r','REJECTED')));const s=ledgerSummary(x.ledger);assert.equal(s.known,1);assert.equal(s.rejected,1)}]
];
let pass=0;for(const [name,fn] of tests){try{await fn();pass++;console.log('PASS',name)}catch(e){console.error('FAIL',name,e);process.exitCode=1}}console.log(`${pass}/${tests.length} V2.9 epistemic ledger contracts passed`);if(pass!==tests.length)process.exit(1);
