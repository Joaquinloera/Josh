import crypto from 'node:crypto';
import { verifyRegistration } from '../netlify/functions/_core/webauthn-registration.js';

const b64u=b=>Buffer.from(b).toString('base64url');
function encLen(major,n){if(n<24)return Buffer.from([(major<<5)|n]);if(n<256)return Buffer.from([(major<<5)|24,n]);if(n<65536){const b=Buffer.alloc(3);b[0]=(major<<5)|25;b.writeUInt16BE(n,1);return b;}throw Error('len');}
function cbor(v){
 if(Buffer.isBuffer(v))return Buffer.concat([encLen(2,v.length),v]);
 if(typeof v==='string'){const b=Buffer.from(v);return Buffer.concat([encLen(3,b.length),b]);}
 if(Number.isInteger(v)){return v>=0?encLen(0,v):encLen(1,-1-v);}
 if(v instanceof Map){const parts=[encLen(5,v.size)];for(const [k,x] of v){parts.push(cbor(k),cbor(x));}return Buffer.concat(parts);}
 throw Error('unsupported');
}
const rp='joshgpt13.netlify.app', origin='https://joshgpt13.netlify.app', challenge=b64u(crypto.randomBytes(32)), cred=crypto.randomBytes(32);
const {publicKey}=crypto.generateKeyPairSync('ec',{namedCurve:'P-256'});const jwk=publicKey.export({format:'jwk'});
const cose=new Map([[1,2],[3,-7],[-1,1],[-2,Buffer.from(jwk.x,'base64url')],[-3,Buffer.from(jwk.y,'base64url')]]);
function fixture({rpValue=rp,flags=0x45,credential=cred,coseKey=cose,type='webauthn.create',challengeValue=challenge,originValue=origin}={}){
 const clientDataJSON=b64u(Buffer.from(JSON.stringify({type,challenge:challengeValue,origin:originValue})));
 const head=Buffer.alloc(55);crypto.createHash('sha256').update(rpValue).digest().copy(head,0);head[32]=flags;head.writeUInt32BE(7,33);crypto.randomBytes(16).copy(head,37);head.writeUInt16BE(credential.length,53);
 const authData=Buffer.concat([head,credential,cbor(coseKey)]);const attestationObject=b64u(cbor(new Map([['fmt','none'],['authData',authData],['attStmt',new Map()]])));
 return {clientDataJSON,attestationObject,credentialId:b64u(cred),challenge,origin,rp};
}
const expectThrow=(name,fn,code)=>{let ok=false;try{fn()}catch(e){ok=e.message===code}console.log(`${ok?'PASS':'FAIL'} ${name}`);if(!ok)process.exitCode=1;return ok};
let n=0; const valid=verifyRegistration(fixture()); if(valid.credentialId===b64u(cred)&&valid.publicKeySpki&&valid.signCount===7){console.log('PASS valid-registration');n++;}else{console.log('FAIL valid-registration');process.exitCode=1;}
for(const [name,patch,code] of [
 ['wrong-rp',{rpValue:'evil.example'},'WEBAUTHN_RP_INVALID'],
 ['wrong-type',{type:'webauthn.get'},'WEBAUTHN_CLIENT_DATA_INVALID'],
 ['wrong-challenge',{challengeValue:'wrong'},'WEBAUTHN_CLIENT_DATA_INVALID'],
 ['wrong-origin',{originValue:'https://evil.example'},'WEBAUTHN_CLIENT_DATA_INVALID'],
 ['missing-up',{flags:0x44},'WEBAUTHN_REGISTRATION_FLAGS_INVALID'],
 ['missing-uv',{flags:0x41},'WEBAUTHN_REGISTRATION_FLAGS_INVALID'],
 ['missing-at',{flags:0x05},'WEBAUTHN_REGISTRATION_FLAGS_INVALID'],
 ['credential-mismatch',{credential:crypto.randomBytes(32)},'WEBAUTHN_CREDENTIAL_MISMATCH']]){if(expectThrow(name,()=>verifyRegistration(fixture(patch)),code))n++;}
const badAlg=new Map(cose);badAlg.set(3,-257);if(expectThrow('unsupported-cose-alg',()=>verifyRegistration(fixture({coseKey:badAlg})),'WEBAUTHN_KEY_UNSUPPORTED'))n++;
const badX=new Map(cose);badX.set(-2,crypto.randomBytes(31));if(expectThrow('invalid-key-length',()=>verifyRegistration(fixture({coseKey:badX})),'WEBAUTHN_KEY_INVALID'))n++;
if(expectThrow('browser-key-mismatch',()=>verifyRegistration({...fixture(),publicKeySpki:b64u(crypto.randomBytes(91))}),'WEBAUTHN_PUBLIC_KEY_MISMATCH'))n++;
if(n!==12)process.exit(1);console.log(`PASS: ${n}/12 V9.0 dynamic passkey registration contracts`);
