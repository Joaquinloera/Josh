import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { applyPathwayAccountability } from '../netlify/functions/_core/pathway-accountability.js';
import { emptyPathwayLedger,commitPathwayAccountability } from '../netlify/functions/_core/pathway-ledger.js';
import { buildPathwayStateAttestation,verifyPathwayStateAttestation,pathwayStateAttestationSummary } from '../netlify/functions/_core/pathway-state-attestation.js';
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v)}
const digestOf=v=>crypto.createHash('sha256').update(canonical(v)).digest('hex');
function acct(i,verdict='LEARNED_PROVEN'){const body={protocol:'NSF-13',confidenceDigest:'c'+i,outcomeDigest:'o'+i,feedbackDigest:'f'+i,routingReceiptDigest:null,route:{host:'h',agent:'a',source:'learned'},confidence:{mode:'LEARNED_ACCEPTED',accepted:true,selectedStrength:.8,margin:.2},outcome:{status:'ACCEPTED',accepted:true},feedback:{action:'REINFORCE',reinforce:true},verdict,learned:true,succeeded:verdict==='LEARNED_PROVEN',cap1:{signal:'ANCESTOR',utterance:'x'}};return {...body,digest:digestOf(body)}}
const key='general:native:native';let ledger=emptyPathwayLedger();let prior={strength:.5};const a=applyPathwayAccountability({accountability:acct(1),key,previous:prior});ledger=commitPathwayAccountability(ledger,a).ledger;const pathways={[key]:{strength:a.afterStrength,quarantined:a.quarantined,failures:a.failures,successes:a.successes,lastAccountabilityDigest:a.digest}};
let n=0;const ok=(name,fn)=>{fn();console.log(`PASS ${++n}: ${name}`)};
const att=buildPathwayStateAttestation({pathways,ledger});
ok('attestation uses NSF-17',()=>assert.equal(att.protocol,'NSF-17'));
ok('matching pathway state verifies',()=>assert.equal(att.verified,true));
ok('attestation cryptographic verification passes',()=>assert(verifyPathwayStateAttestation(att,{ledger})));
ok('ledger head is bound',()=>assert.equal(att.ledgerHead,ledger.head));
ok('ledger sequence is bound',()=>assert.equal(att.ledgerSequence,ledger.sequence));
ok('pathway state digest is present',()=>assert.equal(att.pathwaysDigest.length,64));
ok('CAP-1 WITNESS marks verified state',()=>assert.equal(att.cap1.signal,'WITNESS'));
ok('strength drift is detected',()=>{const x=structuredClone(pathways);x[key].strength=.01;assert.equal(buildPathwayStateAttestation({pathways:x,ledger}).verified,false)});
ok('quarantine drift is detected',()=>{const x=structuredClone(pathways);x[key].quarantined=!x[key].quarantined;assert.equal(buildPathwayStateAttestation({pathways:x,ledger}).verified,false)});
ok('missing persisted pathway is detected',()=>assert.equal(buildPathwayStateAttestation({pathways:{},ledger}).verified,false));
ok('attestation tamper invalidates digest',()=>{const x=structuredClone(att);x.verified=false;assert.equal(verifyPathwayStateAttestation(x,{ledger}),false)});
ok('summary exposes verified checkpoint',()=>{const s=pathwayStateAttestationSummary(att);assert.equal(s.protocol,'NSF-17');assert.equal(s.verified,true);assert.equal(s.checked,1)});
console.log(`NSF-17 contracts: ${n}/12 PASS`);
