import fs from 'node:fs'; import assert from 'node:assert/strict';
const k=fs.readFileSync('netlify/functions/_core/knowledge.js','utf8'), r=fs.readFileSync('netlify/functions/_core/runtime.js','utf8'), c=fs.readFileSync('netlify/functions/chat.js','utf8'), m=fs.readFileSync('netlify/functions/memory.js','utf8'), cfg=fs.readFileSync('netlify/functions/_core/config.js','utf8');
const tests=[
 ['engine advanced',()=>assert.match(cfg,/native-core-0\.[5-9]/)],
 ['account scoped memory',()=>assert.match(k,/digest\(String\(email\)/)],
 ['knowledge retrieval',()=>assert.match(k,/retrieveKnowledge/)],
 ['persistent task memory',()=>assert.match(k,/recordTaskRun/)],
 ['agent work products',()=>assert.match(k,/agent-work-product/)],
 ['chat binds account',()=>assert.match(c,/accountEmail: session\.email/)],
 ['runtime retrieves then records',()=>{assert.match(r,/retrieveKnowledge/);assert.match(r,/recordTaskRun/)}],
 ['memory endpoint authenticated',()=>assert.match(m,/requireSession/)],
 ['bounded stores',()=>{assert.match(k,/MAX_KNOWLEDGE=240/);assert.match(k,/MAX_TASKS=120/);assert.match(k,/MAX_PRODUCTS=360/)}],
 ['no external provider dependency',()=>assert.doesNotMatch(k+r+m,/OPENAI_API_KEY|GEMINI_API_KEY|api\.openai\.com|generativelanguage\.googleapis\.com/i)],
]; let pass=0; for(const [n,f] of tests){try{f();pass++;console.log('PASS',n)}catch(e){console.error('FAIL',n,e.message);process.exitCode=1}} console.log(`${pass}/${tests.length} v1.4 native-memory checks passed`);
