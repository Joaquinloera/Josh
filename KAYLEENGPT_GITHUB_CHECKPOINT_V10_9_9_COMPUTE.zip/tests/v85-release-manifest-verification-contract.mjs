import fs from 'node:fs';
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const verify=fs.readFileSync('scripts/verify-release-manifest.mjs','utf8');
const gen=fs.readFileSync('scripts/release-manifest.mjs','utf8');
const checks=[
 ['package version valid',/^\d+\.\d+\.\d+$/.test(pkg.version)],
 ['manifest verifier exposed',pkg.scripts?.['release:verify']==='node scripts/verify-release-manifest.mjs'],
 ['verifier checks protocol',verify.includes('JOSHGPT-RELEASE-MANIFEST-')],
 ['verifier checks package version',verify.includes('manifest.version!==pkg.version')],
 ['verifier checks deployment target',verify.includes('release manifest deployment target mismatch')],
 ['verifier checks corporate exclusion',verify.includes('DO_NOT_DEPLOY_OR_MODIFY')],
 ['verifier checks dependency lock state',verify.includes('dependency lock state is stale')],
 ['verifier checks every file digest',verify.includes('manifest digest mismatch:')],
 ['verifier checks self digest',verify.includes('release manifest self-digest mismatch')],
 ['verifier fails closed',verify.includes('process.exitCode=2')],
 ['generator critical list excludes manifest self hash',!gen.match(/const critical=\[[^\]]*RELEASE_MANIFEST\.json/s)],
 ['preflight invokes manifest verifier',pkg.scripts?.preflight?.includes('node scripts/verify-release-manifest.mjs')]
];
let bad=0; for(const [n,ok] of checks){console.log(`${ok?'PASS':'FAIL'} ${n}`);if(!ok)bad++;} if(bad)process.exit(1); console.log(`PASS: ${checks.length}/${checks.length} V8.5 release-manifest verification contracts`);
