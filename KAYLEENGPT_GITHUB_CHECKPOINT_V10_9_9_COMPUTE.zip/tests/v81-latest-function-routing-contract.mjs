import fs from "node:fs";
const names=["auth","chat","data","memory","runtime","tools"];
let pass=0;
const ok=(v,m)=>{if(!v)throw new Error(m);pass++;console.log(`PASS ${pass}/12 ${m}`)};
for(const n of names){const s=fs.readFileSync(`netlify/functions/${n}.js`,`utf8`);ok(/export default async function handler\(req\)/.test(s),`${n} uses Request-style default handler`);}
for(const n of names){const s=fs.readFileSync(`netlify/functions/${n}.js`,`utf8`);ok(new RegExp(`export const config = \\{ path: [\"']\/api\/${n}[\"'] \\}`).test(s),`${n} has in-code API path`);}
console.log("V8.1 latest function routing contracts PASS");
