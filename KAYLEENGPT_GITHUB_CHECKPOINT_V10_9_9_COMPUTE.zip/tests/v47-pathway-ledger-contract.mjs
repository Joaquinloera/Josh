import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { applyPathwayAccountability } from '../netlify/functions/_core/pathway-accountability.js';
import { emptyPathwayLedger, commitPathwayAccountability, verifyPathwayLedger } from '../netlify/functions/_core/pathway-ledger.js';
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v)}
const digestOf=v=>crypto.createHash('sha256').update(canonical(v)).digest('hex');
function acct(verdict='LEARNED_PROVEN',salt='1'){const succeeded=verdict==='LEARNED_PROVEN';const body={protocol:'NSF-13',confidenceDigest:'c'+salt,outcomeDigest:'o'+salt,feedbackDigest:'f'+salt,routingReceiptDigest:null,route:{host:'h',agent:'a',source:'learned'},confidence:{mode:'LEARNED_ACCEPTED',accepted:true,selectedStrength:.8,margin:.2},outcome:{status:succeeded?'ACCEPTED':'BLOCKED',accepted:succeeded},feedback:{action:succeeded?'REINFORCE':'NO_REINFORCEMENT',reinforce:succeeded},verdict,learned:true,succeeded,cap1:{signal:succeeded?'ANCESTOR':'VERIFY',utterance:'x'}};return {...body,digest:digestOf(body)}}
const adj=(salt='1',prev={strength:.5})=>applyPathwayAccountability({accountability:acct('LEARNED_PROVEN',salt),key:'general|native|native',previous:prev});
let n=0;const ok=(name,fn)=>{fn();console.log(`PASS ${++n}: ${name}`)};
ok('empty ledger verifies',()=>assert(verifyPathwayLedger(emptyPathwayLedger())));
ok('first commit verifies',()=>assert(verifyPathwayLedger(commitPathwayAccountability(null,adj()).ledger)));
ok('sequence increments',()=>assert.equal(commitPathwayAccountability(null,adj()).ledger.sequence,1));
ok('head equals latest digest',()=>{const c=commitPathwayAccountability(null,adj());assert.equal(c.ledger.head,c.entry.digest)});
ok('commit binds adjustment digest',()=>assert.equal(commitPathwayAccountability(null,adj()).entry.adjustmentDigest,adj().digest));
ok('commit binds pathway key',()=>assert.equal(commitPathwayAccountability(null,adj()).entry.key,'general|native|native'));
ok('second commit links previous head',()=>{const a=commitPathwayAccountability(null,adj('1'));const b=commitPathwayAccountability(a.ledger,adj('2',{strength:.54}));assert.equal(b.ledger.entries[1].previous,a.ledger.head)});
ok('duplicate adjustment replay rejected',()=>{const a=commitPathwayAccountability(null,adj());assert.throws(()=>commitPathwayAccountability(a.ledger,adj()),/replay/i)});
ok('entry tamper invalidates',()=>{const a=commitPathwayAccountability(null,adj());a.ledger.entries[0].strength=.99;assert.equal(verifyPathwayLedger(a.ledger),false)});
ok('head tamper invalidates',()=>{const a=commitPathwayAccountability(null,adj());a.ledger.head='bad';assert.equal(verifyPathwayLedger(a.ledger),false)});
ok('quarantine state is committed',()=>{const q=applyPathwayAccountability({accountability:acct('LEARNED_FAILED','q'),key:'x',previous:{strength:.5,failures:1}});assert.equal(commitPathwayAccountability(null,q).entry.quarantined,true)});
ok('CAP-1 commit signal present',()=>assert(['ANCESTOR','GUARD'].includes(commitPathwayAccountability(null,adj()).entry.cap1.signal)));
console.log(`NSF-15 contracts: ${n}/12 PASS`);
