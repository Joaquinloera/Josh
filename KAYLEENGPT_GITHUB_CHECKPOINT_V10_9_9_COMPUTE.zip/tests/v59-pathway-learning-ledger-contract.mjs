import assert from 'node:assert/strict';
import { buildPathwayLearningFulfillment } from '../netlify/functions/_core/pathway-learning-fulfillment.js';
import { commitPathwayLearningFulfillment, verifyPathwayLearningLedger, pathwayLearningLedgerSummary } from '../netlify/functions/_core/pathway-learning-ledger.js';
import { buildPathwayLearningAdmission } from '../netlify/functions/_core/pathway-learning-admission.js';
import { buildLearningReceipt } from '../netlify/functions/_core/adaptive-learning.js';
// Use verified fixture builders with minimal valid upstream records mirroring contracts.
const outcome={protocol:'NSF-5',version:1,status:'ACCEPTED',accepted:true,sequence:7,planDigest:'a'.repeat(64),settlementDigest:'b'.repeat(64),outputDigest:'c'.repeat(64),knowledgeDigest:'d'.repeat(64),successConditions:[],checks:{executionComplete:true,evaluationReady:true,outputPresent:true,conditionsSatisfied:true},cap1:{signal:'WITNESS',utterance:'x'}};
// builders upstream are strict; import existing test fixture strategy instead of forging hashes.
import crypto from 'node:crypto';
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v)}
const digestOf=v=>sha(canonical(v));
// Construct a valid NSF-26 directly: its verifier is self-contained when upstream objects are omitted.
const body={protocol:'NSF-26',version:1,status:'FULFILLED',fulfilled:true,sequence:7,admissionDigest:'1'.repeat(64),attestationDigest:'2'.repeat(64),executionEntryDigest:'3'.repeat(64),executionLedgerHead:'4'.repeat(64),outcomeDigest:'5'.repeat(64),outputDigest:'6'.repeat(64),receiptHash:'7'.repeat(64),pathwayKey:'software|native|producer',learningScore:.8,resultingStrength:.72,bindings:{admissionVerified:true,receiptVerified:true,sequenceBound:true,outcomeBound:true},cap1:{signal:'WITNESS',utterance:'STAR WITNESS LEARNING-FULFILLMENT VERIFIED'}};
const fulfillment={...body,digest:digestOf(body)};
let pass=0;const ok=(name,fn)=>{fn();pass++;console.log('PASS',name)};
ok('empty ledger accepts first fulfillment',()=>{const c=commitPathwayLearningFulfillment(null,fulfillment);assert.equal(c.ledger.sequence,1);assert.equal(c.entry.previous,null)});
const c1=commitPathwayLearningFulfillment(null,fulfillment);
ok('ledger verifies',()=>assert.equal(verifyPathwayLearningLedger(c1.ledger),true));
ok('head binds commit',()=>assert.equal(c1.ledger.head,c1.entry.digest));
ok('commit binds fulfillment',()=>assert.equal(c1.entry.fulfillmentDigest,fulfillment.digest));
ok('commit binds receipt',()=>assert.equal(c1.entry.receiptHash,fulfillment.receiptHash));
ok('commit binds pathway',()=>assert.equal(c1.entry.pathwayKey,fulfillment.pathwayKey));
ok('commit binds outcome',()=>assert.equal(c1.entry.outcomeDigest,fulfillment.outcomeDigest));
ok('commit carries CAP-1 ancestry',()=>assert.equal(c1.entry.cap1.signal,'ANCESTOR'));
ok('replay rejected',()=>assert.throws(()=>commitPathwayLearningFulfillment(c1.ledger,fulfillment),/replay/i));
ok('tampered head fails',()=>{const x=structuredClone(c1.ledger);x.head='0'.repeat(64);assert.equal(verifyPathwayLearningLedger(x),false)});
ok('tampered entry fails',()=>{const x=structuredClone(c1.ledger);x.entries[0].resultingStrength=.1;assert.equal(verifyPathwayLearningLedger(x),false)});
ok('summary reports verified ledger',()=>assert.equal(pathwayLearningLedgerSummary(c1.ledger).verified,true));
console.log(`${pass}/12 NSF-27 contracts passed`);
