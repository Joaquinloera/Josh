import fs from 'node:fs';
const read=p=>fs.readFileSync(new URL(p,import.meta.url),'utf8');
const auth=read('../netlify/functions/_core/auth.js');
const blobStore=read('../netlify/functions/_core/blob-store.js');
const route=read('../netlify/functions/auth.js');
const chat=read('../netlify/functions/chat.js');
const runtime=read('../netlify/functions/runtime.js');
const html=read('../index.html');
const pkg=JSON.parse(read('../package.json'));
const checks=[
 ['Netlify Blobs pinned',pkg.dependencies?.['@netlify/blobs']==='11.1.0'],
 ['site-wide identity store',auth.includes('openJoshStore(ACCOUNT_STORE)')&&blobStore.includes("globalThis.Netlify?.context?.deploy?.context === 'production'")&&blobStore.includes('getStore(name,')],
 ['opaque sessions',auth.includes("token(32)")&&auth.includes("SESSION_STORE")],
 ['no fallback auth secret',!auth.includes('FALLBACK_SECRET')&&!auth.includes('JOSHGPT_AUTH_SECRET')],
 ['strong account store',blobStore.includes("consistency: 'strong'")],
 ['verified account create',auth.includes("if(await store.get(key,{type:'json'})) return false")&&auth.includes('await store.setJSON(key,account)')],
 ['single-use challenges',auth.includes('await store.delete(key)')],
 ['PBKDF2 310k',auth.includes('310000')],
 ['server passkey verify',auth.includes("crypto.verify('sha256'")],
 ['async chat session gate',chat.includes('await requireSession(req)')],
 ['runtime multi-device',runtime.includes('multiDeviceAccounts: true')],
 ['settings passkey enrollment',html.includes('id="enrollPasskey"')],
 ['no external AI keys',![auth,route,chat,runtime,html].join('\n').match(/OPENAI_API_KEY|GEMINI_API_KEY|api\.openai\.com|generativelanguage\.googleapis\.com/)]
];
let fail=0;for(const [n,ok] of checks){console.log(`${ok?'PASS':'FAIL'} ${n}`);if(!ok)fail++;}if(fail)process.exit(1);
