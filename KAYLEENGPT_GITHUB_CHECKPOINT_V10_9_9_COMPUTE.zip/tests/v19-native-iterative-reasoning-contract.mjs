import assert from 'node:assert/strict';
import { buildReasoningState } from '../netlify/functions/_core/reasoning-state.js';
import { buildTaskGraph, executeTaskGraph } from '../netlify/functions/_core/task-graph.js';
import { runNative } from '../netlify/functions/_core/native-engine.js';
const route={host:{id:'raphael',name:'Raphael'},agent:{id:'333',name:'Builder',role:'software'},agents:[{id:'333',name:'Builder',role:'software'},{id:'4444',name:'Analyst',role:'analysis'},{id:'999',name:'Consensus',role:'consensus'}]};
const plan=[{action:'define'},{action:'test'}], graph=executeTaskGraph({graph:buildTaskGraph({intent:'software',route,text:'build it'}),text:'build it',intent:'software',plan,toolReceipts:[]});
const make=()=>buildReasoningState({intent:'software',text:'build it',plan,toolReceipts:[],retrievedKnowledge:[],taskGraph:graph});
const tests=[
 ['reasoning state advances to 0.2',()=>assert.equal(make().version,'reasoning-state-0.2')],
 ['runs controlled reasoning cycles',()=>assert.ok(make().cycles.length>=1&&make().cycles.length<=4)],
 ['hard cycle budget is four',()=>assert.equal(make().executionBudget.maxCycles,4)],
 ['hard branch budget is six',()=>assert.equal(make().executionBudget.maxBranches,6)],
 ['budget is respected',()=>assert.equal(make().verification.budgetRespected,true)],
 ['candidate confidence is bounded',()=>assert.ok(make().branches.every(x=>x.confidence>=0&&x.confidence<=1))],
 ['failed hypotheses can be eliminated',()=>assert.ok(make().branches.some(x=>x.status==='eliminated')||make().cycles.some(x=>x.eliminated.length))],
 ['convergence is explicit',()=>assert.equal(typeof make().verification.converged,'boolean')],
 ['verified graph converges',()=>assert.equal(make().verification.converged,true)],
 ['conclusion records convergence',()=>assert.equal(make().conclusion.converged,true)],
 ['native core advances to 0.9',async()=>{const x=await runNative({messages:[{role:'user',content:'build software'}],route});assert.equal(x.model,'native-core-0.9')}],
 ['native reasoning remains provider independent',async()=>{const x=await runNative({messages:[{role:'user',content:'build software'}],route});assert.equal(x.provider,'JOSHGPT_NATIVE');assert.equal(x.native.foundationModelInstalled,false)}],
];let pass=0;for(const[n,f]of tests){try{await f();pass++;console.log('PASS',n)}catch(e){console.error('FAIL',n,e.message);process.exitCode=1}}console.log(`${pass}/${tests.length} v1.9 native-iterative-reasoning checks passed`);
