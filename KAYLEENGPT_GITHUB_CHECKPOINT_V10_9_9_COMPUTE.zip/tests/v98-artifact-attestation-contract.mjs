import fs from 'node:fs';
const s=fs.readFileSync('scripts/artifact-attestation.mjs','utf8');
const p=JSON.parse(fs.readFileSync('package.json','utf8'));
const checks=[
 ['version',p.version.split('.').length===3],
 ['protocol',s.includes('JOSHGPT-ARTIFACT-ATTESTATION-1')],
 ['zip verifier',s.includes('verify-deployment-zip.mjs')],
 ['zip pass required',s.includes("zipEvidence.status!=='PASS'")],
 ['zip protocol required',s.includes('JOSHGPT-DEPLOYMENT-ZIP-2')],
 ['archive sha256',s.includes('archiveSha256:sha(zip)')],
 ['archive bytes',s.includes('archiveBytes:zip.length')],
 ['target project',s.includes('project:target.project')],
 ['target site',s.includes('siteId:target.siteId')],
 ['corporate exclusion',s.includes('corporateSitePolicy:target.corporateSitePolicy')],
 ['manifest binding',s.includes('manifest.manifestDigest')],
 ['attestation digest',s.includes('attestationDigest=sha')],
];
let n=0; for(const [name,ok] of checks){if(!ok) throw new Error('FAIL '+name); n++;}
console.log(`V9.8 artifact attestation contracts: ${n}/${checks.length} PASS`);
