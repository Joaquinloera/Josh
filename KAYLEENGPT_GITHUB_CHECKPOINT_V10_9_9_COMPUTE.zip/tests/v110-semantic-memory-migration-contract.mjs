import fs from 'node:fs';
const src=fs.readFileSync(new URL('../netlify/functions/_core/knowledge.js',import.meta.url),'utf8');
if(src.includes("semantic:{protocol:'NSF-7'")) throw new Error('legacy NSF-7 persistence remains');
if(!src.includes("protocol:'NSF-8'")) throw new Error('NSF-8 semantic persistence missing');
if(!src.includes("state.semantic.protocol==='NSF-7'")) throw new Error('legacy empty-state migration missing');
if(!src.includes('anchor:state.semantic.anchor||null')) throw new Error('NSF-8 anchor persistence missing');
console.log('v110 semantic memory migration contract: PASS');
