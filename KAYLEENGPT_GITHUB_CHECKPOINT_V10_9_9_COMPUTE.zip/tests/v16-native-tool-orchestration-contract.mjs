import fs from 'node:fs'; import assert from 'node:assert/strict';
import { buildNativeToolPlan, runNative } from '../netlify/functions/_core/native-engine.js';
const rt=fs.readFileSync('netlify/functions/_core/runtime.js','utf8'),cfg=fs.readFileSync('netlify/functions/_core/config.js','utf8');
const route={host:{id:'joshgpt',name:'JoshGPT'},agent:{id:'raphael',name:'Raphael',role:'software'},agents:[{id:'raphael',name:'Raphael',role:'software'}]};
const tests=[
 ['engine advanced',()=>assert.match(cfg,/native-core-0\.[6-9]/)],
 ['hash request selects native hash',()=>assert.equal(buildNativeToolPlan('SHA-256 of abc')[0].capability,'crypto.sha256')],
 ['json request selects validator',()=>assert.equal(buildNativeToolPlan('validate JSON: {"x":1}')[0].capability,'json.validate')],
 ['ordinary chat selects no tool',()=>assert.equal(buildNativeToolPlan('hello there').length,0)],
 ['planner bounded to three tools',()=>assert.ok(buildNativeToolPlan('hash digest sha256 validate json word count checklist').length<=3)],
 ['runtime queues planned work',()=>assert.ok(rt.indexOf('enqueueAgentWork')<rt.indexOf('executeCapability(step.capability'))],
 ['runtime inspects receipts',()=>assert.match(rt,/inspectReceipt/)],
 ['runtime has bounded replan path',()=>{assert.match(rt,/retries=1/);assert.doesNotMatch(rt,/while\s*\(/)}],
 ['runtime settles queue',()=>assert.match(rt,/settleAgentWork/)],
 ['native synthesis consumes receipts',async()=>{const r=await runNative({messages:[{role:'user',content:'SHA-256 of abc'}],route,toolReceipts:[{ok:true,capability:'crypto.sha256',result:{digest:'abc'},inspected:true}]});assert.match(r.output,/SHA-256: abc/)}],
 ['pipeline exposes tool phases',async()=>{const r=await runNative({messages:[{role:'user',content:'hello'}],route});assert.ok(r.native.pipeline.includes('tool-execute'));assert.ok(r.native.pipeline.includes('inspect'));assert.ok(r.native.pipeline.includes('replan'))}],
 ['external providers remain absent',()=>assert.doesNotMatch(rt,/OPENAI_API_KEY|GEMINI_API_KEY|api\.openai\.com|generativelanguage\.googleapis\.com/i)],
];let pass=0;for(const[n,f]of tests){try{await f();pass++;console.log('PASS',n)}catch(err){console.error('FAIL',n,err.message);process.exitCode=1}}console.log(`${pass}/${tests.length} v1.6 native-tool-orchestration checks passed`);
