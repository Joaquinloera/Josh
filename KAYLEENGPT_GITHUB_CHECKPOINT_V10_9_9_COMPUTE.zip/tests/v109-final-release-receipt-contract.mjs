import { readFileSync } from 'node:fs';
const src=readFileSync('scripts/final-release-receipt.mjs','utf8');
const pkg=JSON.parse(readFileSync('package.json','utf8'));
const checks=[
 ['version',pkg.version==='10.9.0'],
 ['protocol',src.includes('JOSHGPT-FINAL-RELEASE-RECEIPT-1')],
 ['target',src.includes("project:'joshgpt13'")],
 ['site',src.includes('322db469-6833-4187-b023-60638716b3c7')],
 ['corporate exclusion',src.includes('DO_NOT_DEPLOY_OR_MODIFY')],
 ['fail closed',src.includes('failClosed:true')],
 ['no fabrication',src.includes('noLockFabrication:true')],
 ['no deploy',src.includes('receiptDoesNotDeploy:true')],
 ['authorization binding',src.includes('authorizationDigestValid')],
 ['manifest binding',src.includes('manifestDigest')],
 ['lock binding',src.includes("manifest?.files?.['package-lock.json']===lockSha256")],
 ['receipt digest',src.includes('receipt.receiptDigest=sha(JSON.stringify(receipt))')]
];
for(const [n,ok] of checks)if(!ok)throw new Error('FAIL '+n);
console.log(`V10.9 final release receipt contract: ${checks.length}/${checks.length} PASS`);
