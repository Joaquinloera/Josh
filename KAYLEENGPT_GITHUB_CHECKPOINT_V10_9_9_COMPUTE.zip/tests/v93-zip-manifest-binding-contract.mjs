import {readFileSync} from 'node:fs';
const s=readFileSync('scripts/verify-deployment-zip.mjs','utf8');
const p=JSON.parse(readFileSync('package.json','utf8'));
const checks=[
 ['V9.3 package version',/^\d+\.\d+\.\d+$/.test(p.version)],
 ['ZIP verifier protocol 3',s.includes("JOSHGPT-DEPLOYMENT-ZIP-3")],
 ['reads manifest from ZIP payload',s.includes("bytes('RELEASE_MANIFEST.json')")],
 ['requires manifest protocol 2',s.includes("JOSHGPT-RELEASE-MANIFEST-2")],
 ['hashes ZIP entry bytes',s.includes("createHash('sha256').update(bytes(name))")],
 ['fails digest mismatch',s.includes('manifest digest mismatch inside ZIP')],
 ['requires manifest listed files',s.includes('manifest-listed ZIP file missing')],
 ['binds runtime inventory',s.includes('ZIP runtime inventory differs from release manifest')],
 ['binds package version',s.includes('ZIP package version differs from release manifest')],
 ['binds deployment target',s.includes('ZIP deployment target differs from release manifest')],
 ['supports deflate verification',s.includes('inflateRawSync')],
 ['retains secret boundary',s.includes('secret-like ZIP file')]
];
let ok=0; for(const [n,v] of checks){console.log(`${v?'PASS':'FAIL'}: ${n}`);if(v)ok++}
console.log(`${ok}/${checks.length} V9.3 ZIP-manifest binding contracts passed`); if(ok!==checks.length)process.exit(1);
