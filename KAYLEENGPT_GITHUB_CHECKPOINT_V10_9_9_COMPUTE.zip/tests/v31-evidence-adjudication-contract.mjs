import assert from 'node:assert/strict';
import {ADJUDICATION_PROTOCOL,adjudicateDisputedClaim,adjudicateVerificationQueue,verifyAdjudication,verifyFinding} from '../netlify/functions/_core/evidence-adjudication.js';
const claim={id:'d1',status:'DISPUTED',ledgerDigest:'ledger-1',claim:{subject:'celestial',predicate:'RELATED_TO',object:'stars',evidence:'verified evidence with sufficient detail and provenance for independent adjudication across the JoshGPT knowledge system',provenance:{sourceId:'src-1'}}};
const a=adjudicateDisputedClaim(claim,{agents:['uriel','raphael','saraqael']});
assert.equal(a.protocol,ADJUDICATION_PROTOCOL);assert.equal(a.findings.length,2);assert.notEqual(a.findings[0].agentId,a.findings[1].agentId);assert.equal(a.findings.every(verifyFinding),true);assert.equal(verifyAdjudication(a),true);assert.equal(a.reconciliation.bothVerified,true);assert.equal(a.reconciliation.independent,true);assert.equal(a.reconciliation.decision,'PROMOTE');assert.equal(a.reconciliation.cap1,'CAP1:KNOW');
const q=adjudicateVerificationQueue([claim],{agents:['uriel','raphael','saraqael']});assert.equal(q.verified,true);assert.equal(q.adjudications.length,1);assert.equal(q.summary.items[0].claimId,'d1');
const tampered=structuredClone(a);tampered.findings[0].score=.01;assert.equal(verifyAdjudication(tampered),false);
console.log('V3.1 evidence adjudication contract: 12/12 PASS');
