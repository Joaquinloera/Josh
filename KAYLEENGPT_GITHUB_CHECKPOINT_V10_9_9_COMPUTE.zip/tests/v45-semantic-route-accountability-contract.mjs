import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { buildSemanticRouteAccountability,verifySemanticRouteAccountability } from '../netlify/functions/_core/semantic-route-accountability.js';
const sha=v=>crypto.createHash('sha256').update(String(v)).digest('hex');function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v)}const dg=v=>sha(canonical(v));
function confidence(mode='LEARNED_ACCEPTED'){const accepted=!mode.endsWith('REJECTED'),b={protocol:'NSF-12',profileDigest:sha('p'),stabilityDigest:sha('s'),stabilityMode:'STABLE',source:mode==='LEARNED_ACCEPTED'?'learned':'base',selectedStrength:.8,baseStrength:.6,margin:.2,minStrength:.6,minimumMargin:.05,mode,accepted,routeHost:'h',routeAgent:'a',cap1:{signal:accepted?'WITNESS':'GUARD',utterance:'STAR'}};return {...b,digest:dg(b)}}
function outcome(ok=true){const b={protocol:'NSF-5',planDigest:sha('plan'),settlementDigest:sha('set'),outputDigest:sha('out'),knowledgeDigest:sha('k'),status:ok?'ACCEPTED':'BLOCKED',accepted:ok,successConditions:[],checks:[],evaluationConsensus:ok?'READY':'BLOCKED',cap1:{signal:ok?'WITNESS':'VERIFY',utterance:'STAR'}};return {...b,digest:dg(b)}}
function feedback(o){const b={protocol:'NSF-6',sequence:1,outcomeDigest:o.digest,outcomeStatus:o.status,learningReceiptHash:null,learningVerified:false,reinforce:false,action:o.accepted?'OBSERVE':'NO_REINFORCEMENT',bindings:{planDigest:o.planDigest,settlementDigest:o.settlementDigest,outputDigest:o.outputDigest,knowledgeDigest:o.knowledgeDigest},cap1:{signal:o.accepted?'WITNESS':'VERIFY',utterance:'STAR'}};return {...b,digest:dg(b)}}
let n=0;const t=(name,fn)=>{fn();n++;console.log(`ok ${n} - ${name}`)};
const c=confidence(),o=outcome(true),f=feedback(o),r=buildSemanticRouteAccountability({confidence:c,outcome:o,feedback:f,routingReceipt:{receiptHash:sha('rr')}});
t('protocol NSF-13',()=>assert.equal(r.protocol,'NSF-13'));
t('learned success is proven',()=>assert.equal(r.verdict,'LEARNED_PROVEN'));
t('learned flag true',()=>assert.equal(r.learned,true));
t('success flag true',()=>assert.equal(r.succeeded,true));
t('proven route emits ANCESTOR',()=>assert.equal(r.cap1.signal,'ANCESTOR'));
t('record verifies',()=>assert.equal(verifySemanticRouteAccountability(r,{confidenceDigest:c.digest,outcomeDigest:o.digest,feedbackDigest:f.digest}),true));
const of=outcome(false),ff=feedback(of),rf=buildSemanticRouteAccountability({confidence:c,outcome:of,feedback:ff});
t('learned failure recorded',()=>assert.equal(rf.verdict,'LEARNED_FAILED'));
t('failed route emits VERIFY',()=>assert.equal(rf.cap1.signal,'VERIFY'));
const cb=confidence('BASE_CONFIRMED'),rb=buildSemanticRouteAccountability({confidence:cb,outcome:o,feedback:f});
t('base success is fallback success',()=>assert.equal(rb.verdict,'FALLBACK_SUCCEEDED'));
const ce=confidence('EXPLICIT_OVERRIDE'),re=buildSemanticRouteAccountability({confidence:ce,outcome:o,feedback:f});
t('explicit success distinguished',()=>assert.equal(re.verdict,'EXPLICIT_SUCCEEDED'));
t('tampering invalidates',()=>{const x=structuredClone(r);x.verdict='LEARNED_FAILED';assert.equal(verifySemanticRouteAccountability(x),false)});
t('wrong binding invalidates',()=>assert.equal(verifySemanticRouteAccountability(r,{outcomeDigest:sha('wrong')}),false));
console.log(`1..${n}`);
