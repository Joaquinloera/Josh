import fs from 'node:fs';
const data=fs.readFileSync('netlify/functions/data.js','utf8');
const auth=fs.readFileSync('netlify/functions/auth.js','utf8');
const html=fs.readFileSync('index.html','utf8');
const browser=html+'\n'+fs.readFileSync('app.js','utf8');
const toml=fs.readFileSync('netlify.toml','utf8');
const checks=[
 ['data requires authenticated session',data.includes('requireSession(req)')],
 ['data is account scoped',data.includes('key(session.email)')],
 ['data uses persistent blobs',data.includes("openJoshStore(STORE)")],
 ['conversation count bounded',data.includes('MAX_CHATS=100')],
 ['message count bounded',data.includes('MAX_MESSAGES=200')],
 ['message content bounded',data.includes('MAX_CONTENT=100000')],
 ['profile update authenticated',auth.includes("action==='profile'")&&auth.includes("AUTH_REQUIRED")],
 ['data API routed',toml.includes('from = "/api/data"')],
 ['browser loads server chats',browser.includes("api('/api/data')")],
 ['browser persists server chats',browser.includes("fetch('/api/data'")],
 ['browser can update profile',browser.includes("action=profile")],
 ['browser clear removes server data',browser.includes("method:'DELETE'")],
];
let fail=0;for(const [n,ok] of checks){console.log(`${ok?'PASS':'FAIL'} ${n}`);if(!ok)fail++}if(fail)process.exit(1);console.log(`PASS v1.1 user-data contract ${checks.length}/${checks.length}`);
