import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { applyPathwayAccountability } from '../netlify/functions/_core/pathway-accountability.js';
import { emptyPathwayLedger,commitPathwayAccountability,verifyPathwayLedger,compactPathwayLedger,archivedPathwayReplayPossible,pathwayLedgerSummary } from '../netlify/functions/_core/pathway-ledger.js';
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v)}
const digestOf=v=>crypto.createHash('sha256').update(canonical(v)).digest('hex');
function acct(i){const body={protocol:'NSF-13',confidenceDigest:'c'+i,outcomeDigest:'o'+i,feedbackDigest:'f'+i,routingReceiptDigest:null,route:{host:'h',agent:'a',source:'learned'},confidence:{mode:'LEARNED_ACCEPTED',accepted:true,selectedStrength:.8,margin:.2},outcome:{status:'ACCEPTED',accepted:true},feedback:{action:'REINFORCE',reinforce:true},verdict:'LEARNED_PROVEN',learned:true,succeeded:true,cap1:{signal:'ANCESTOR',utterance:'x'}};return {...body,digest:digestOf(body)}}
function adj(i){return applyPathwayAccountability({accountability:acct(i),key:'general|native|native',previous:{strength:.5}})}
let n=0;const ok=(name,fn)=>{fn();console.log(`PASS ${++n}: ${name}`)};
let ledger=emptyPathwayLedger();const adjustments=[];for(let i=1;i<=97;i++){const a=adj(i);adjustments.push(a);ledger=commitPathwayAccountability(ledger,a).ledger;}
ok('ledger remains valid past old 96-entry boundary',()=>assert(verifyPathwayLedger(ledger)));
ok('checkpoint anchor is created',()=>assert.equal(ledger.anchor?.protocol,'NSF-16-CHECKPOINT'));
ok('retained tail is bounded',()=>assert(ledger.entries.length<=96));
ok('archive count records compacted entries',()=>assert(ledger.anchor.archivedEntries>0));
ok('anchor binds archived through sequence',()=>assert(ledger.anchor.throughSequence>0));
ok('anchor carries CAP-1 ANCESTOR signal',()=>assert.equal(ledger.anchor.cap1.signal,'ANCESTOR'));
ok('archived replay shield detects old adjustment',()=>assert.equal(archivedPathwayReplayPossible(ledger,adjustments[0].digest),true));
ok('archived adjustment replay is rejected',()=>assert.throws(()=>commitPathwayAccountability(ledger,adjustments[0]),/replay/i));
ok('anchor tamper invalidates ledger',()=>{const x=structuredClone(ledger);x.anchor.archivedEntries++;assert.equal(verifyPathwayLedger(x),false)});
ok('replay-filter tamper invalidates ledger',()=>{const x=structuredClone(ledger);x.anchor.replayFilter=x.anchor.replayFilter.slice(0,-2)+'AA';assert.equal(verifyPathwayLedger(x),false)});
ok('explicit compaction preserves head and sequence',()=>{let x=emptyPathwayLedger();for(let i=200;i<260;i++)x=commitPathwayAccountability(x,adj(i)).ledger;const c=compactPathwayLedger(x,{retain:24});assert.equal(c.ledger.head,x.head);assert.equal(c.ledger.sequence,x.sequence);assert(verifyPathwayLedger(c.ledger))});
ok('summary exposes NSF-16 checkpoint state',()=>{const s=pathwayLedgerSummary(ledger);assert.equal(s.protocol,'NSF-16');assert(s.archived>0);assert.equal(s.replayShield,'BLOOM-4096x6')});
console.log(`NSF-16 contracts: ${n}/12 PASS`);
