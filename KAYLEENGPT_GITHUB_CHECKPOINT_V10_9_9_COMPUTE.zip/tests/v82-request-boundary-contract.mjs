import fs from "node:fs";
let pass=0; const ok=(v,m)=>{if(!v)throw new Error(m);pass++;console.log(`PASS ${pass}/12 ${m}`)};
const http=fs.readFileSync("netlify/functions/_core/http.js","utf8");
ok(http.includes("MAX_JSON_BODY_BYTES = 1024 * 1024")&&!http.includes("requestJSON("),"shared JSON boundary is 1 MiB and unused outbound helper removed");
ok(http.includes('req.headers.get("content-length")'),"declared body length checked");
ok(http.includes("reader.read()"),"stream body is measured while reading");
ok(http.includes("size > maxBytes"),"stream overrun fails closed");
ok(http.includes("error.status = 413"),"oversize body maps to HTTP 413");
ok(http.includes("error.status = 400"),"malformed JSON maps to HTTP 400");
for(const n of ["auth","chat","data","memory","tools"]){const s=fs.readFileSync(`netlify/functions/${n}.js`,`utf8`);ok(s.includes("readJSONBody"),`${n} uses bounded JSON parser`);}
const pre=fs.readFileSync("scripts/deployment-preflight.mjs","utf8");ok(pre.includes("'runtime','tools'"),"preflight covers tools API redirect");
console.log("V8.2 request boundary contracts PASS");
