import { readFileSync } from 'node:fs';
const pkg=JSON.parse(readFileSync('package.json','utf8'));
const s=readFileSync('scripts/acquire-dependency-lock.mjs','utf8');
const checks=[
 ['version semver',/^\d+\.\d+\.\d+$/.test(pkg.version)],
 ['protocol',s.includes('JOSHGPT-DEPENDENCY-LOCK-ACQUISITION-1')],
 ['package-lock-only',s.includes("'--package-lock-only'")],
 ['ignore scripts',s.includes("'--ignore-scripts'")],
 ['bounded fetch retry',s.includes("'--fetch-retries=1'")],
 ['bounded fetch timeout',s.includes("'--fetch-timeout=20000'")],
 ['strict verifier imported',s.includes("verifyDependencyLock")],
 ['invalid new lock removed',s.includes("rmSync('package-lock.json')")],
 ['dns classified',s.includes('NPM_DNS_UNAVAILABLE')],
 ['verified state',s.includes('ACQUIRED_VERIFIED')],
 ['report digest',s.includes('reportDigest')],
 ['npm script wired',pkg.scripts['dependency:acquire']==='node scripts/acquire-dependency-lock.mjs']
];
for(const [n,ok] of checks){ console.log(`${ok?'PASS':'FAIL'} ${n}`); if(!ok) process.exitCode=1; }
console.log(`${checks.filter(x=>x[1]).length}/${checks.length} V9.9 contracts passed`);
