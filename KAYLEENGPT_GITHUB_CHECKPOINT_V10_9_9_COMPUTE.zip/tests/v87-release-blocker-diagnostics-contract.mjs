import fs from 'node:fs';
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const src=fs.readFileSync('scripts/release-status.mjs','utf8');
const gate=fs.readFileSync('scripts/release-readiness.mjs','utf8');
const checks=[
 ['package version is semver',/^\d+\.\d+\.\d+$/.test(pkg.version)],
 ['release status protocol exists',src.includes('JOSHGPT-RELEASE-STATUS-1')],
 ['status targets JoshGPT only',src.includes('target.project')&&src.includes('corporateSitePolicy')],
 ['status checks real lockfile presence',src.includes("existsSync('package-lock.json')")],
 ['status verifies pinned blobs dependency',src.includes("rootPin==='11.1.0'")],
 ['status requires resolved blobs package',src.includes("node_modules/@netlify/blobs")],
 ['missing lock has explicit blocker code',src.includes('DEPENDENCY_LOCK_UNAVAILABLE')],
 ['no dependency metadata fabrication',src.includes('do not fabricate dependency metadata')],
 ['blocked status exits nonzero',src.includes('process.exitCode=2')],
 ['release gate still fail closed',gate.includes("package-lock.json is missing")],
 ['release status script registered',pkg.scripts?.['release:status']==='node scripts/release-status.mjs'],
 ['preflight includes v87 contract',pkg.scripts?.preflight?.includes('v87-release-blocker-diagnostics-contract.mjs')]
];
let bad=0;for(const [n,ok] of checks){console.log(`${ok?'PASS':'FAIL'} ${n}`);if(!ok)bad++;}if(bad)process.exit(1);console.log(`PASS: ${checks.length}/${checks.length} V8.7 release-blocker diagnostics contracts`);
