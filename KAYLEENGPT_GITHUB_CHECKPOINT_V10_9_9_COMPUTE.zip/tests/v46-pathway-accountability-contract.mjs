import assert from 'node:assert/strict';
import { applyPathwayAccountability, verifyPathwayAccountability } from '../netlify/functions/_core/pathway-accountability.js';
// Use minimal valid records by importing fixtures is brittle; construct valid accountability record through a locally signed body helper instead.
import crypto from 'node:crypto';
function canonical(v){if(Array.isArray(v))return `[${v.map(canonical).join(',')}]`;if(v&&typeof v==='object')return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;return JSON.stringify(v)}
const digestOf=v=>crypto.createHash('sha256').update(canonical(v)).digest('hex');
function acct(verdict){const learned=verdict.startsWith('LEARNED_'),succeeded=verdict==='LEARNED_PROVEN';const body={protocol:'NSF-13',confidenceDigest:'c',outcomeDigest:'o',feedbackDigest:'f',routingReceiptDigest:null,route:{host:'h',agent:'a',source:'learned'},confidence:{mode:learned?'LEARNED_ACCEPTED':'BASE_FALLBACK',accepted:learned,selectedStrength:.8,margin:.2},outcome:{status:succeeded?'ACCEPTED':'BLOCKED',accepted:succeeded},feedback:{action:succeeded?'REINFORCE':'NO_REINFORCEMENT',reinforce:succeeded},verdict,learned,succeeded,cap1:{signal:succeeded?'ANCESTOR':'VERIFY',utterance:'x'}};return {...body,digest:digestOf(body)}}
let n=0;const ok=(name,fn)=>{fn();console.log(`PASS ${++n}: ${name}`)};
ok('proven raises bounded confidence',()=>{const r=applyPathwayAccountability({accountability:acct('LEARNED_PROVEN'),key:'x',previous:{strength:.5}});assert.equal(r.afterStrength,.54);assert(verifyPathwayAccountability(r));});
ok('failure reduces confidence',()=>{const r=applyPathwayAccountability({accountability:acct('LEARNED_FAILED'),key:'x',previous:{strength:.5}});assert.equal(r.afterStrength,.42)});
ok('first failure not quarantined',()=>assert.equal(applyPathwayAccountability({accountability:acct('LEARNED_FAILED'),key:'x',previous:{strength:.5}}).quarantined,false));
ok('second failure quarantines',()=>assert.equal(applyPathwayAccountability({accountability:acct('LEARNED_FAILED'),key:'x',previous:{strength:.5,failures:1}}).quarantined,true));
ok('quarantine records guard',()=>assert.equal(applyPathwayAccountability({accountability:acct('LEARNED_FAILED'),key:'x',previous:{strength:.5,failures:1}}).cap1.signal,'GUARD'));
ok('one success does not recover',()=>assert.equal(applyPathwayAccountability({accountability:acct('LEARNED_PROVEN'),key:'x',previous:{strength:.4,quarantined:true,failures:2,successes:0}}).quarantined,true));
ok('two verified successes recover',()=>assert.equal(applyPathwayAccountability({accountability:acct('LEARNED_PROVEN'),key:'x',previous:{strength:.4,quarantined:true,failures:1,successes:1}}).quarantined,false));
ok('recovery emits ancestor',()=>assert.equal(applyPathwayAccountability({accountability:acct('LEARNED_PROVEN'),key:'x',previous:{strength:.4,quarantined:true,failures:1,successes:1}}).cap1.signal,'ANCESTOR'));
ok('strength clamps high',()=>assert.equal(applyPathwayAccountability({accountability:acct('LEARNED_PROVEN'),key:'x',previous:{strength:.99}}).afterStrength,1));
ok('strength clamps low',()=>assert.equal(applyPathwayAccountability({accountability:acct('LEARNED_FAILED'),key:'x',previous:{strength:.02}}).afterStrength,0));
ok('tampering invalidates',()=>{const r=applyPathwayAccountability({accountability:acct('LEARNED_PROVEN'),key:'x'});r.afterStrength=.9;assert.equal(verifyPathwayAccountability(r),false)});
ok('accountability digest binding enforced',()=>{const r=applyPathwayAccountability({accountability:acct('LEARNED_PROVEN'),key:'x'});assert.equal(verifyPathwayAccountability(r,{accountabilityDigest:'wrong'}),false)});
console.log(`NSF-14 contracts: ${n}/12 PASS`);
