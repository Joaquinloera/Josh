import { readFileSync } from 'node:fs';
const src=readFileSync('scripts/dependency-resolution-diagnostic.mjs','utf8');
const pkg=JSON.parse(readFileSync('package.json','utf8'));
const checks=[
 ['version',/^\d+\.\d+\.\d+$/.test(pkg.version)],
 ['script-wired',pkg.scripts['dependency:diagnose']==='node scripts/dependency-resolution-diagnostic.mjs'],
 ['pinned-package',src.includes("const expected='11.1.0'")],
 ['lock-only',src.includes("'--package-lock-only'")],
 ['ignore-scripts',src.includes("'--ignore-scripts'")],
 ['bounded-timeout',src.includes('timeout:90000')],
 ['dns-classification',src.includes("code='NPM_DNS_UNAVAILABLE'")],
 ['timeout-classification',src.includes("code='NPM_NETWORK_TIMEOUT'")],
 ['no-lock-fabrication',!src.includes('lockfileVersion:')&&!src.includes('resolved:')],
 ['lock-verification',src.includes("lock.packages?.['node_modules/@netlify/blobs']")],
 ['machine-report',src.includes('DEPENDENCY_RESOLUTION_STATUS.json')],
 ['blocked-exit',src.includes('process.exitCode=lockValid?0:2')]
];
let n=0; for(const [name,ok] of checks){console.log(`${ok?'PASS':'FAIL'} ${name}`); if(ok)n++;}
if(n!==checks.length) process.exit(1); console.log(`PASS: ${n}/${checks.length} V8.8 dependency diagnostic contracts`);
