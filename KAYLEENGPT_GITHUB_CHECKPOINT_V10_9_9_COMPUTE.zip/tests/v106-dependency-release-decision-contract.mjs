import { readFileSync } from 'node:fs';
const src=readFileSync('scripts/dependency-release-decision.mjs','utf8');
const pkg=JSON.parse(readFileSync('package.json','utf8'));
const checks=[
 ['version',/^10\.(?:6|7|8|9)\.\d+$/.test(pkg.version)],['protocol',src.includes('JOSHGPT-DEPENDENCY-RELEASE-DECISION-1')],['target',src.includes("project:'joshgpt13'")],['site',src.includes('322db469-6833-4187-b023-60638716b3c7')],['corporate',src.includes('DO_NOT_DEPLOY_OR_MODIFY')],['fail closed',src.includes('failClosed:true')],['no fabrication',src.includes('noLockFabrication:true')],['evidence binding',src.includes('requiresEvidenceBoundLock:true')],['sha256',src.includes("createHash('sha256')")],['missing lock blocker',src.includes('MISSING_GENUINE_PACKAGE_LOCK')],['unbound lock blocker',src.includes('PACKAGE_LOCK_NOT_BOUND_TO_VERIFIED_EVIDENCE')],['decision digest',src.includes('decisionDigest')]];
for(const [n,ok] of checks){if(!ok)throw new Error('FAIL '+n)} console.log(`V10.6 dependency release decision contract: ${checks.length}/${checks.length} PASS`);
