import assert from 'node:assert/strict';
import { runNative } from '../netlify/functions/_core/native-engine.js';
import { routeTask } from '../netlify/functions/_core/orchestrator.js';

const cases = [
  ['software','Build and debug this software API'],
  ['security','Protect biometric authentication'],
  ['research','Research and compare the evidence'],
  ['writing','Draft a message for the team'],
  ['planning','Plan the next roadmap steps'],
  ['general','Tell me something useful'],
];
let passed=0;
for (const [intent,text] of cases) {
  const route=routeTask({message:text});
  const r=await runNative({messages:[{role:'user',content:'Earlier context'},{role:'assistant',content:'ack'},{role:'user',content:text}],route});
  assert.equal(r.provider,'JOSHGPT_NATIVE');
  assert.match(r.model,/^native-core-0\.[5-9]$/);
  assert.equal(r.native.intent,intent);
  for (const phase of ['classify','plan','working-memory','agent-execute','evaluate','synthesize']) assert.ok(r.native.pipeline.includes(phase));
  assert.ok(r.native.plan.length>=5);
  assert.ok(r.native.executions.length>=1);
  assert.equal(r.native.evaluation.consensus,'READY');
  assert.equal(r.native.foundationModelInstalled,false);
  passed++;
}
assert.match((await runNative({messages:[{role:'user',content:'hello'}],route:routeTask({message:'hello'})})).output,/native-core-0\.[5-9]/);
passed++;
console.log(`v1.3 native orchestration contract: ${passed}/7 PASS`);
