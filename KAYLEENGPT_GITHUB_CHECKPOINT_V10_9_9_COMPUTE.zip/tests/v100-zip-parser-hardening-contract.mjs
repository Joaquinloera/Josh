import fs from 'node:fs';
const s=fs.readFileSync('scripts/verify-deployment-zip.mjs','utf8');
const checks=[
 ['protocol v3',s.includes("JOSHGPT-DEPLOYMENT-ZIP-3")],
 ['crc table',s.includes('crcTable')],['crc verification',s.includes('ZIP CRC32 mismatch')],
 ['zip64 fail closed',s.includes('ZIP64 archive unsupported/fail-closed')],['zip64 entry fail closed',s.includes('ZIP64 entry unsupported/fail-closed')],
 ['multi disk denied',s.includes('multi-disk ZIP forbidden')],['local filename match',s.includes('local/central ZIP filename mismatch')],
 ['local method match',s.includes('local/central compression method mismatch')],['local flags match',s.includes('local/central ZIP flags mismatch')],
 ['encryption denied',s.includes('encrypted local ZIP entry forbidden')],['payload bounds',s.includes('ZIP payload bounds invalid')],['manifest binding preserved',s.includes('manifest digest mismatch inside ZIP')]
];
for(const [n,ok] of checks)console.log(`${ok?'PASS':'FAIL'} ${n}`);if(checks.some(x=>!x[1]))process.exit(1);console.log(`V10.0 contracts ${checks.length}/${checks.length} PASS`);
