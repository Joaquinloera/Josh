import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';
const s=readFileSync('scripts/dependency-environment-readiness.mjs','utf8');
const p=JSON.parse(readFileSync('package.json','utf8'));
const checks=[
 ['version',()=>assert.match(p.version,/^10\.(?:[2-9]|[1-9]\d+)\.\d+$/)],
 ['protocol',()=>assert.match(s,/JOSHGPT-DEPENDENCY-ENVIRONMENT-READINESS-1/)],
 ['dependency',()=>assert.match(s,/@netlify\/blobs/)],
 ['pin',()=>assert.match(s,/11\.1\.0/)],
 ['registry host',()=>assert.match(s,/registry\.npmjs\.org/)],
 ['dns lookup',()=>assert.match(s,/dns\.lookup/)],
 ['npm registry inspection',()=>assert.match(s,/config','get','registry/)],
 ['lock presence',()=>assert.match(s,/package-lock\.json/)],
 ['lock sha',()=>assert.match(s,/lockSha256/)],
 ['no fabrication',()=>assert.match(s,/noLockFabrication:true/)],
 ['digest',()=>assert.match(s,/reportDigest/)],
 ['script wired',()=>assert.equal(p.scripts['dependency:environment'],'node scripts/dependency-environment-readiness.mjs')],
];
let pass=0; for (const [n,f] of checks){f();pass++;} console.log(`V10.2 dependency environment readiness contract: ${pass}/${checks.length} PASS`);
