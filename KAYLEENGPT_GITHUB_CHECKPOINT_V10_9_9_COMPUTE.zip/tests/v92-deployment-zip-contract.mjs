import {readFileSync} from 'node:fs';
const src=readFileSync('scripts/verify-deployment-zip.mjs','utf8');
const pkg=JSON.parse(readFileSync('package.json','utf8'));
const checks=[
 ['version',pkg.version.split('.').length===3],
 ['protocol',src.includes('JOSHGPT-DEPLOYMENT-ZIP-')],
 ['eocd',src.includes('0x06054b50')],
 ['central-directory',src.includes('0x02014b50')],
 ['path-traversal',src.includes("includes('..')")],
 ['absolute-path',src.includes("name.startsWith('/')")],
 ['encryption-denied',src.includes('encrypted ZIP entry forbidden')],
 ['symlink-denied',src.includes('symlink ZIP entry forbidden')],
 ['forbidden-dirs',src.includes('node_modules')&&src.includes('\\.netlify')&&src.includes('\\.git')],
 ['secret-deny',src.includes('secret-like ZIP file')],
 ['release-roots',src.includes("'RELEASE_MANIFEST.json'")],
 ['runtime-required',src.includes('no Netlify runtime JavaScript in ZIP')]
];
let n=0;for(const [name,ok] of checks){if(!ok) throw new Error(`FAIL ${name}`);console.log(`PASS ${++n}/12 ${name}`)}
