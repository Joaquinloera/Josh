import { readFileSync } from 'node:fs';
const src=readFileSync('scripts/release-decision-integrity.mjs','utf8');
const pkg=JSON.parse(readFileSync('package.json','utf8'));
const checks=[
 ['version',/^10\.(?:7|8|9)\.\d+$/.test(pkg.version)],['protocol',src.includes('JOSHGPT-RELEASE-DECISION-INTEGRITY-1')],['target',src.includes("project:'joshgpt13'")],['site',src.includes('322db469-6833-4187-b023-60638716b3c7')],['corporate',src.includes('DO_NOT_DEPLOY_OR_MODIFY')],['fail closed',src.includes('failClosed:true')],['no fabrication',src.includes('noLockFabrication:true')],['current lock binding',src.includes('requiresCurrentLockBinding:true')],['evidence chain',src.includes('requiresVerifiedEvidenceChain:true')],['lock verifier',src.includes('verifyDependencyLock')],['sha256',src.includes("createHash('sha256')")],['bound gate',src.includes("status==='RELEASE_DECISION_INTEGRITY_READY'?0:2")]];
for(const [n,ok] of checks){if(!ok)throw new Error('FAIL '+n)} console.log(`V10.7 release decision integrity contract: ${checks.length}/${checks.length} PASS`);
