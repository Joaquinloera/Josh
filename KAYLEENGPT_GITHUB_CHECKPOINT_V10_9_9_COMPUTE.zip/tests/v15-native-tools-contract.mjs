import fs from 'node:fs'; import assert from 'node:assert/strict';
import { listCapabilities, executeCapability, authorizeCapability } from '../netlify/functions/_core/tools.js';
const k=fs.readFileSync('netlify/functions/_core/knowledge.js','utf8'), e=fs.readFileSync('netlify/functions/tools.js','utf8'), cfg=fs.readFileSync('netlify/functions/_core/config.js','utf8');
const tests=[
 ['engine advanced',()=>assert.match(cfg,/native-core-0\.[5-9]/)],
 ['registry has four native tools',()=>assert.equal(listCapabilities().length,4)],
 ['unauthenticated execution denied',()=>assert.equal(authorizeCapability('crypto.sha256',{authenticated:false}).allowed,false)],
 ['sha256 deterministic',()=>assert.equal(executeCapability('crypto.sha256','abc',{authenticated:true}).result.digest,'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad')],
 ['json validator works',()=>assert.equal(executeCapability('json.validate','{"x":1}',{authenticated:true}).result.valid,true)],
 ['text metrics works',()=>assert.equal(executeCapability('text.metrics','one two',{authenticated:true}).result.words,2)],
 ['checklist bounded',()=>assert.ok(executeCapability('plan.checklist',Array(30).fill('x').join('\n'),{authenticated:true}).result.items.length<=20)],
 ['persistent work queue',()=>{assert.match(k,/enqueueAgentWork/);assert.match(k,/settleAgentWork/);assert.match(k,/MAX_QUEUE=120/)}],
 ['tool endpoint authenticated',()=>assert.match(e,/requireSession/)],
 ['tool endpoint queues before execution',()=>assert.ok(e.indexOf('const queued=await enqueueAgentWork')<e.indexOf('const receipt=executeCapability'))],
 ['unknown capability rejected',()=>assert.equal(executeCapability('shell.exec','x',{authenticated:true}).error,'UNKNOWN_CAPABILITY')],
 ['no arbitrary process execution',()=>assert.doesNotMatch(fs.readFileSync('netlify/functions/_core/tools.js','utf8'),/child_process|\bexecSync\b|\bspawn\s*\(/)],
]; let pass=0; for(const [n,f] of tests){try{f();pass++;console.log('PASS',n)}catch(err){console.error('FAIL',n,err.message);process.exitCode=1}} console.log(`${pass}/${tests.length} v1.5 native-tools checks passed`);
