import fs from 'node:fs';
const core=fs.readFileSync('netlify/functions/_core/auth.js','utf8')+'\n'+fs.readFileSync('netlify/functions/_core/webauthn-registration.js','utf8');
const route=fs.readFileSync('netlify/functions/auth.js','utf8');
const ui=fs.readFileSync('index.html','utf8');
const checks=[
 ['server verifies registration evidence',core.includes('export function verifyRegistration')],
 ['attestation object required by route',route.includes('d.attestationObject')],
 ['browser submits attestation object',ui.includes('attestationObject:bytesToB64u(cred.response.attestationObject)')],
 ['client data create type verified',core.includes("'webauthn.create',origin")],
 ['rp id hash verified',core.includes("WEBAUTHN_RP_INVALID")],
 ['user presence required',core.includes('(flags&0x01)===0')],
 ['user verification required',core.includes('(flags&0x04)===0')],
 ['attested credential data required',core.includes('(flags&0x40)===0')],
 ['credential id bound to authenticator data',core.includes('WEBAUTHN_CREDENTIAL_MISMATCH')],
 ['ES256 COSE key derived server side',core.includes('coseEs256ToSpki')&&core.includes("cose.get(3)!==-7")],
 ['browser public key cannot substitute authenticator key',core.includes('WEBAUTHN_PUBLIC_KEY_MISMATCH')],
 ['persisted passkey uses verified values',route.includes('credentialId:verified.credentialId')&&route.includes('publicKeySpki:verified.publicKeySpki')],
];
let pass=0; for(const [n,ok] of checks){console.log(`${ok?'PASS':'FAIL'} ${n}`);if(ok)pass++;}
console.log(`${pass}/${checks.length} V8.0 contracts passed`); if(pass!==checks.length)process.exit(1);
