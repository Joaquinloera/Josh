import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';
const s=readFileSync('scripts/dependency-retry-controller.mjs','utf8');
const p=JSON.parse(readFileSync('package.json','utf8'));
const checks=[
 ['version',()=>assert.match(p.version,/^10\.(?:4|5|6|7|8|9)\.\d+$/)],
 ['protocol',()=>assert.match(s,/JOSHGPT-DEPENDENCY-RETRY-CONTROLLER-1/)],
 ['probe first',()=>assert.ok(s.indexOf('dependency-network-probe.mjs') < s.indexOf('acquire-dependency-lock.mjs'))],
 ['reachable gate',()=>assert.match(s,/probe\?\.reachable===true/)],
 ['single acquisition',()=>assert.match(s,/maxAcquisitionAttempts:1/)],
 ['bounded',()=>assert.match(s,/bounded:true/)],
 ['no registry mutation',()=>assert.match(s,/noRegistryMutation:true/)],
 ['no proxy mutation',()=>assert.match(s,/noProxyMutation:true/)],
 ['no dns mutation',()=>assert.match(s,/noDnsMutation:true/)],
 ['no lock fabrication',()=>assert.match(s,/noLockFabrication:true/)],
 ['status receipt',()=>assert.match(s,/DEPENDENCY_RETRY_STATUS\.json/)],
 ['wired',()=>assert.equal(p.scripts['dependency:retry-controller'],'node scripts/dependency-retry-controller.mjs')],
];
let pass=0; for(const [n,f] of checks){f();pass++;} console.log(`V10.4 dependency retry controller contract: ${pass}/${checks.length} PASS`);
