import fs from 'node:fs';
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const gen=fs.readFileSync('scripts/release-manifest.mjs','utf8');
const verify=fs.readFileSync('scripts/verify-release-manifest.mjs','utf8');
const checks=[
 ['package version is valid semver',/^\d+\.\d+\.\d+$/.test(pkg.version)],
 ['manifest protocol v2',gen.includes('JOSHGPT-RELEASE-MANIFEST-2')&&verify.includes('JOSHGPT-RELEASE-MANIFEST-2')],
 ['generator walks full functions tree',gen.includes("walk('netlify/functions')")],
 ['generator includes all JS runtime files',gen.includes("p.endsWith('.js')")],
 ['inventory sorted deterministically',gen.includes('].sort()')],
 ['lockfile enters inventory when present',gen.includes("existsSync('package-lock.json')")],
 ['manifest records inventory policy',gen.includes('ALL_NETLIFY_FUNCTION_JS_PLUS_RELEASE_ROOTS')],
 ['manifest records inventory count',gen.includes('count:critical.length')],
 ['verifier independently rebuilds inventory',verify.includes('expectedInventory=')],
 ['verifier rejects missing or extra inventory',verify.includes('inventory is incomplete or contains unexpected files')],
 ['verifier checks every expected digest',verify.includes('for(const file of expected)')],
 ['verifier remains fail closed',verify.includes('process.exitCode=2')]
];
let bad=0;for(const [n,ok] of checks){console.log(`${ok?'PASS':'FAIL'} ${n}`);if(!ok)bad++;}if(bad)process.exit(1);console.log(`PASS: ${checks.length}/${checks.length} V8.6 release-inventory contracts`);
