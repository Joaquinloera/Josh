import assert from 'node:assert/strict';
import { buildTaskGraph, executeTaskGraph } from '../netlify/functions/_core/task-graph.js';
import { runNative } from '../netlify/functions/_core/native-engine.js';
const route={host:{id:'raphael',name:'Raphael'},agent:{id:'333',name:'Builder',role:'software'},agents:[{id:'333',name:'Builder',role:'software'},{id:'4444',name:'Analyst',role:'analysis'},{id:'999',name:'Consensus',role:'consensus'}]};
const tests=[
 ['graph has produce-review-reconcile nodes',()=>{const g=buildTaskGraph({intent:'software',route,text:'build it'});assert.deepEqual(g.nodes.map(x=>x.kind),['produce','review','reconcile'])}],
 ['review depends on producer',()=>{const g=buildTaskGraph({intent:'software',route,text:'x'});assert.deepEqual(g.nodes[1].dependsOn,['g1'])}],
 ['reconcile depends on producer and reviewer',()=>{const g=buildTaskGraph({intent:'software',route,text:'x'});assert.deepEqual(g.nodes[2].dependsOn,['g1','g2'])}],
 ['handoffs carry SHA-256 hashes',()=>{const x=executeTaskGraph({graph:buildTaskGraph({intent:'software',route,text:'x'}),text:'x',intent:'software',plan:[{action:'a'}],toolReceipts:[]});assert.equal(x.products[0].hash.length,64)}],
 ['review binds producer hash',()=>{const x=executeTaskGraph({graph:buildTaskGraph({intent:'software',route,text:'x'}),text:'x',intent:'software',plan:[{action:'a'}],toolReceipts:[]});assert.deepEqual(x.products[1].inputHashes,[x.products[0].hash])}],
 ['reconcile binds both prior products',()=>{const x=executeTaskGraph({graph:buildTaskGraph({intent:'software',route,text:'x'}),text:'x',intent:'software',plan:[{action:'a'}],toolReceipts:[]});assert.deepEqual(x.products[2].inputHashes,[x.products[0].hash,x.products[1].hash])}],
 ['complete graph verifies handoffs',()=>{const x=executeTaskGraph({graph:buildTaskGraph({intent:'software',route,text:'x'}),text:'x',intent:'software',plan:[{action:'a'}],toolReceipts:[]});assert.equal(x.verification.handoffsVerified,true)}],
 ['graph consensus is ready',()=>{const x=executeTaskGraph({graph:buildTaskGraph({intent:'software',route,text:'x'}),text:'x',intent:'software',plan:[{action:'a'}],toolReceipts:[]});assert.equal(x.verification.consensus,'READY')}],
 ['native pipeline exposes verified handoff stage',async()=>{const x=await runNative({messages:[{role:'user',content:'build software'}],route});assert.ok(x.native.pipeline.includes('verified-handoff'))}],
 ['native evaluation requires task graph',async()=>{const x=await runNative({messages:[{role:'user',content:'build software'}],route});assert.equal(x.native.evaluation.checks.find(c=>c.id==='task-graph-handoffs').pass,true)}],
 ['native graph has three verified products',async()=>{const x=await runNative({messages:[{role:'user',content:'build software'}],route});assert.equal(x.native.taskGraph.products.length,3);assert.ok(x.native.taskGraph.products.every(p=>p.verified))}],
 ['external provider remains unnecessary',async()=>{const x=await runNative({messages:[{role:'user',content:'build software'}],route});assert.equal(x.provider,'JOSHGPT_NATIVE');assert.equal(x.native.foundationModelInstalled,false)}],
];
let pass=0;for(const[n,f]of tests){try{await f();pass++;console.log('PASS',n)}catch(err){console.error('FAIL',n,err.message);process.exitCode=1}}console.log(`${pass}/${tests.length} v1.7 native-task-graph checks passed`);
