import {readFileSync} from 'node:fs';
const src=readFileSync('scripts/package-boundary.mjs','utf8');
const pkg=JSON.parse(readFileSync('package.json','utf8'));
const checks=[
 ['version',/^\d+\.\d+\.\d+$/.test(pkg.version)],
 ['protocol',src.includes('JOSHGPT-PACKAGE-BOUNDARY-1')],
 ['target',src.includes("target.project!=='joshgpt13'")],
 ['site-id',src.includes('322db469-6833-4187-b023-60638716b3c7')],
 ['corporate-deny',src.includes("corporateSitePolicy!=='DO_NOT_DEPLOY_OR_MODIFY'")],
 ['deny-netlify',src.includes("'.netlify'")],
 ['deny-node-modules',src.includes("'node_modules'")],
 ['deny-git',src.includes("'.git'")],
 ['deny-env',src.includes('\\.env')],
 ['deny-private-keys',src.includes('pem|key|p12|pfx')],
 ['nested-root',src.includes('nested checkpoint root detected')],
 ['runtime-required',src.includes('no Netlify runtime JavaScript found')]
];
let n=0;for(const [name,ok] of checks){if(!ok) throw new Error(`FAIL ${name}`);console.log(`PASS ${++n}/12 ${name}`)}
