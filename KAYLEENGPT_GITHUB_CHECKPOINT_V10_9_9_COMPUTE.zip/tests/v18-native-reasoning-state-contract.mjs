import assert from 'node:assert/strict';
import { buildReasoningState } from '../netlify/functions/_core/reasoning-state.js';
import { buildTaskGraph, executeTaskGraph } from '../netlify/functions/_core/task-graph.js';
import { runNative } from '../netlify/functions/_core/native-engine.js';
const route={host:{id:'raphael',name:'Raphael'},agent:{id:'333',name:'Builder',role:'software'},agents:[{id:'333',name:'Builder',role:'software'},{id:'4444',name:'Analyst',role:'analysis'},{id:'999',name:'Consensus',role:'consensus'}]};
const graph=executeTaskGraph({graph:buildTaskGraph({intent:'software',route,text:'build it'}),text:'build it',intent:'software',plan:[{action:'define'},{action:'test'}],toolReceipts:[]});
const make=()=>buildReasoningState({intent:'software',text:'build it',plan:[{action:'define'},{action:'test'}],toolReceipts:[],retrievedKnowledge:[],taskGraph:graph});
const tests=[
 ['creates three candidate solutions',()=>assert.equal(make().candidates.length,3)],
 ['scores candidates in bounded range',()=>assert.ok(make().candidates.every(x=>x.score>=0&&x.score<=1))],
 ['sorts candidates by score',()=>{const x=make().candidates;assert.ok(x[0].score>=x[1].score)}],
 ['retains verified request evidence',()=>assert.ok(make().evidence.some(x=>x.kind==='request'&&x.verified))],
 ['binds conclusion to evidence IDs',()=>assert.ok(make().conclusion.evidenceIds.length>0)],
 ['binds conclusion to verified task graph',()=>assert.equal(make().conclusion.graphBound,true)],
 ['contradiction state is explicit',()=>assert.ok(Array.isArray(make().contradictions))],
 ['revision passes are bounded',()=>assert.ok(make().revisionPasses>=0&&make().revisionPasses<=3)],
 ['reasoning state verifies ready',()=>assert.equal(make().verification.ready,true)],
 ['native pipeline exposes candidate generation',async()=>{const x=await runNative({messages:[{role:'user',content:'build software'}],route});assert.ok(x.native.pipeline.includes('candidate-generate'))}],
 ['native evaluation requires reasoning verification',async()=>{const x=await runNative({messages:[{role:'user',content:'build software'}],route});assert.equal(x.native.evaluation.checks.find(c=>c.id==='reasoning-state-verified').pass,true)}],
 ['external provider remains unnecessary',async()=>{const x=await runNative({messages:[{role:'user',content:'build software'}],route});assert.equal(x.provider,'JOSHGPT_NATIVE');assert.equal(x.native.foundationModelInstalled,false)}],
];
let pass=0;for(const[n,f]of tests){try{await f();pass++;console.log('PASS',n)}catch(err){console.error('FAIL',n,err.message);process.exitCode=1}}console.log(`${pass}/${tests.length} v1.8 native-reasoning-state checks passed`);
