import { readFileSync } from 'node:fs';
const html=readFileSync('index.html','utf8');
const auth=readFileSync('netlify/functions/_core/auth.js','utf8')+'\n'+readFileSync('netlify/functions/_core/webauthn-registration.js','utf8');
const route=readFileSync('netlify/functions/auth.js','utf8');
const pkg=JSON.parse(readFileSync('package.json','utf8'));
const checks=[
 ['version',Number(pkg.version.split('.')[0])>=9||(Number(pkg.version.split('.')[0])===8&&Number(pkg.version.split('.')[1])>=9)],
 ['attestation-required-client',html.includes('attestationObject:bytesToB64u(cred.response.attestationObject)')],
 ['getPublicKey-optional',html.includes('cred.response.getPublicKey?.()')],
 ['no-export-hard-fail',!html.includes('cannot export the passkey public key')&&!html.includes('cannot provide the passkey public key')],
 ['conditional-spki-client',(html.match(/if\(pub\)enrollment\.publicKeySpki=bytesToB64u\(pub\)/g)||[]).length===2],
 ['server-spki-optional',auth.includes("if(publicKeySpki&&!safeEq(derivedSpki,unb64u(publicKeySpki)))")],
 ['server-derives-key',auth.includes('publicKeySpki:b64u(derivedSpki)')],
 ['server-binds-credential',auth.includes("if(!safeEq(cred,unb64u(credentialId))) throw new Error('WEBAUTHN_CREDENTIAL_MISMATCH')")],
 ['server-rp-check',auth.includes("throw new Error('WEBAUTHN_RP_INVALID')")],
 ['server-uv-check',auth.includes("throw new Error('WEBAUTHN_USER_VERIFICATION_REQUIRED')")],
 ['enrollment-route-attestation',route.includes('attestationObject:d.attestationObject')&&route.includes('publicKeySpki:d.publicKeySpki||null')],
 ['no-provider-regression',!/(api\.openai\.com|generativelanguage\.googleapis\.com|OPENAI_API_KEY|GEMINI_API_KEY)/i.test(auth)]
];
let n=0; for(const [name,ok] of checks){console.log(`${ok?'PASS':'FAIL'} ${name}`);if(ok)n++;}
if(n!==checks.length)process.exit(1);console.log(`PASS: ${n}/${checks.length} V8.9 passkey browser compatibility contracts`);
