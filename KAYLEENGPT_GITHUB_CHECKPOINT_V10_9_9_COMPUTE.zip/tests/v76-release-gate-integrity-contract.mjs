import fs from 'node:fs';
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const pre=fs.readFileSync('scripts/deployment-preflight.mjs','utf8');
const gate=fs.readFileSync('scripts/release-readiness.mjs','utf8');
const checks=[
 ['package version is semver',/^\d+\.\d+\.\d+$/.test(pkg.version)],
 ['preflight validates package semver dynamically',pre.includes("/^\\d+\\.\\d+\\.\\d+$/")],
 ['release gate validates package semver dynamically',gate.includes("/^\\d+\\.\\d+\\.\\d+$/")],
 ['blobs pin retained',pkg.dependencies?.['@netlify/blobs']==='11.1.0'],
 ['gate requires lockfile',gate.includes("existsSync('package-lock.json')")],
 ['gate verifies lock root pin',gate.includes('verifyDependencyLock')],
 ['gate verifies resolved package',gate.includes('dependency lock integrity')],
 ['preflight provider scan retained',pre.includes('provider-independence')],
 ['preflight deployment target retained',pre.includes('322db469-6833-4187-b023-60638716b3c7')],
 ['preflight corporate exclusion retained',pre.includes('DO_NOT_DEPLOY_OR_MODIFY')],
 ['release gate remains fail closed',gate.includes('process.exitCode=2')],
 ['release command exposed',pkg.scripts?.['release:gate']==='node scripts/release-readiness.mjs']
];
let bad=0; for(const [n,ok] of checks){console.log(`${ok?'PASS':'FAIL'} ${n}`); if(!ok) bad++;} if(bad) process.exit(1); console.log(`PASS: ${checks.length}/${checks.length} release-gate integrity contracts`);
