import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const s=readFileSync('scripts/dependency-evidence-chain.mjs','utf8');
const p=JSON.parse(readFileSync('package.json','utf8'));
const checks=[
 ['version',()=>assert.match(p.version,/^10\.(?:5|6|7|8|9)\.\d+$/)],
 ['protocol',()=>assert.match(s,/JOSHGPT-DEPENDENCY-EVIDENCE-CHAIN-1/)],
 ['environment',()=>assert.match(s,/dependency-environment-readiness\.mjs/)],
 ['network',()=>assert.match(s,/dependency-network-probe\.mjs/)],
 ['retry',()=>assert.match(s,/dependency-retry-controller\.mjs/)],
 ['sha256',()=>assert.match(s,/sha256BoundEvidence:true/)],
 ['lock-hash',()=>assert.match(s,/lockSha256/)],
 ['no-registry-mutation',()=>assert.match(s,/noRegistryMutation:true/)],
 ['no-proxy-mutation',()=>assert.match(s,/noProxyMutation:true/)],
 ['no-dns-mutation',()=>assert.match(s,/noDnsMutation:true/)],
 ['no-fabrication',()=>assert.match(s,/noLockFabrication:true/)],
 ['fail-closed',()=>assert.match(s,/BLOCKED_EVIDENCE_INCOMPLETE/)],
];
let pass=0; for(const [n,f] of checks){f();pass++;} console.log(`V10.5 dependency evidence chain contract: ${pass}/${checks.length} PASS`);
