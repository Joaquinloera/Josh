import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';
const s=readFileSync('scripts/dependency-network-probe.mjs','utf8');
const p=JSON.parse(readFileSync('package.json','utf8'));
const checks=[
 ['version',()=>assert.ok(Number(p.version.split('.')[0]) >= 10)],
 ['protocol',()=>assert.match(s,/JOSHGPT-DEPENDENCY-NETWORK-PROBE-1/)],
 ['bounded attempts',()=>assert.match(s,/const attempts = 3/)],
 ['system lookup',()=>assert.match(s,/dns\.lookup/)],
 ['ipv4 resolver',()=>assert.match(s,/dns\.resolve4/)],
 ['ipv6 resolver',()=>assert.match(s,/dns\.resolve6/)],
 ['transient classification',()=>assert.match(s,/BLOCKED_TRANSIENT_DNS/)],
 ['eai again',()=>assert.match(s,/EAI_AGAIN/)],
 ['no proxy mutation',()=>assert.match(s,/noProxyMutation:true/)],
 ['no dns mutation',()=>assert.match(s,/noDnsMutation:true/)],
 ['no lock fabrication',()=>assert.match(s,/noLockFabrication:true/)],
 ['wired',()=>assert.equal(p.scripts['dependency:network-probe'],'node scripts/dependency-network-probe.mjs')],
];
let pass=0; for(const [n,f] of checks){f();pass++;} console.log(`V10.3 dependency network probe contract: ${pass}/${checks.length} PASS`);
