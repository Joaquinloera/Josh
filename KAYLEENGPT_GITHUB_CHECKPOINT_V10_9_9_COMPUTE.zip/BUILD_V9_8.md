# JoshGPT Native Portal V9.8 — Detached Artifact Attestation

Adds a detached, SHA-256-bound attestation for the exact packaged deployment ZIP. The attestation is generated only after the ZIP passes the V9.3 content-binding verifier and records the exact ZIP SHA-256/byte size, release-manifest digest/inventory, deployment target, corporate-site exclusion policy, and ZIP verification evidence. This avoids self-referential hashing by keeping the attestation outside the ZIP.

The dependency lock release gate remains fail-closed; no package-lock.json is fabricated.
