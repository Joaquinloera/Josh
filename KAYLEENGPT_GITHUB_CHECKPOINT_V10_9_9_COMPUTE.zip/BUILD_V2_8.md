# JoshGPT Native Portal V2.8 — Epistemic Knowledge Lifecycle

- Adds CKG-2 over the preserved CKG-1 concept/provenance graph.
- Agents form bounded candidate claims from verified work products.
- Candidate claims are challenged against provenance, evidence sufficiency, and conflicting established claims.
- Only passing candidates become ESTABLISHED; failed candidates remain explicitly REJECTED and are never silently promoted.
- Challenge and resolution records are SHA-256 bound.
- CKG-1 evidence context now feeds Native reasoning-state construction directly.
- No external AI provider dependency is introduced.
