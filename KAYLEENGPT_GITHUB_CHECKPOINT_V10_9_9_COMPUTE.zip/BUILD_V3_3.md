# JoshGPT Native Portal V3.3 — Native Semantic Formation

Protocol: NSF-1

V3.3 adds a deterministic semantic-formation boundary before routing and reasoning. Human input is normalized into bounded intents, concepts, named entities, semantic relations, constraints, context digests, and a CAP-1 machine signal. The semantic frame is SHA-256 bound and must verify before the request proceeds.

This layer is JoshGPT-owned software. It is not a trained language model and does not claim unrestricted natural-language understanding. It supplies deterministic structure to the existing agent, CKG, Bio × Quantum, reasoning, memory, and verification layers.

External AI providers: none required.
