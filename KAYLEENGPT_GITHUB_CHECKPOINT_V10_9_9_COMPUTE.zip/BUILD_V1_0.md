# JoshGPT Native Portal v1.0 checkpoint

Status: CHECKPOINT — NOT DEPLOYED

Adds site-wide persistent JoshGPT identity using Netlify Blobs as storage for JoshGPT-owned account records, opaque server sessions, and single-use WebAuthn challenges. Passwords are PBKDF2-SHA256 hashed with per-account random salts (310,000 iterations). Passkey assertions are verified server-side and require user verification. Account creation uses an atomic only-if-new write. The chat endpoint requires a valid server-side session.

No OpenAI or Gemini API key/endpoint is present in the active runtime.

Deployment note: this source checkpoint adds @netlify/blobs 11.1.0. Before a manual ZIP deploy, dependency bundling must be verified in the exact deployment artifact. Do not treat this checkpoint ZIP as the final upload artifact.
