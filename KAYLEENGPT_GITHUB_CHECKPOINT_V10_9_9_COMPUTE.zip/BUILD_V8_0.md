# JoshGPT Native Portal V8.0 — Passkey Registration Verification

V8.0 closes the passkey-enrollment trust gap. The server now consumes the WebAuthn attestation object, validates the creation client data, RP ID hash, user-presence/user-verification/attested-credential flags, binds the credential ID to authenticator data, parses the ES256 COSE public key, derives the persisted SPKI server-side, and rejects a browser-supplied public-key mismatch.

This remains a checkpoint. It does not deploy or modify the live JoshGPT project, and it does not touch the corporate project. Dependency resolution and live Netlify smoke validation remain separate release gates.
