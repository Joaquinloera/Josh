# JoshGPT Native Portal V9.2

## Deployment ZIP Attestation
V9.2 adds a dependency-free ZIP central-directory verifier for the final manual-upload artifact. It fails closed on malformed central directories, unsafe/absolute/traversal paths, encrypted entries, symlinks, forbidden build directories, secret-like files, missing release roots, and missing Netlify runtime JavaScript.

This checkpoint does not bypass the dependency lock gate. A genuine package-lock.json resolving the pinned @netlify/blobs dependency is still required before final release.
