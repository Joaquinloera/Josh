# JoshGPT Native Portal V7.1 — Deployment Hardening I

V7.1 begins post-freeze deployment hardening without changing the frozen V7.0 cognitive architecture.

- Deployment source is normalized at ZIP root.
- `@netlify/blobs` remains exactly pinned at 11.1.0.
- CSP and frame-denial headers are promoted to the global `/*` policy so SPA routes inherit them.
- `npm run preflight` validates deployment structure, Netlify redirects/functions/bundler, provider independence, secure cookies, and strong Blob reads.
- Frozen Native architecture remains V7.0 / NSF-38.

Dependency installation/bundling remains a final-deployment validation item; this checkpoint does not pretend an offline package-lock was generated.

Checkpoint only. Do not upload until final Netlify packaging and production behavior validation are complete.
