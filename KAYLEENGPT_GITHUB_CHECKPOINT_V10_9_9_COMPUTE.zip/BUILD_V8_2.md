# JoshGPT Native Portal V8.2 — Request Boundary Hardening

V8.2 adds a shared fail-closed JSON request boundary to authenticated and authentication write endpoints. Request bodies are capped at 1 MiB using both Content-Length precheck and streaming byte accounting, malformed JSON returns 400, and oversized payloads return 413. The deployment preflight now also requires the `/api/tools` redirect.

Architecture remains frozen at V7.0 / NSF-38. This checkpoint does not install trained foundation-model weights and adds no OpenAI or Gemini provider dependency. The corporate project remains excluded from deployment.

Release status: checkpoint only. Reproducible npm dependency resolution and production-runtime smoke validation remain required before upload.
