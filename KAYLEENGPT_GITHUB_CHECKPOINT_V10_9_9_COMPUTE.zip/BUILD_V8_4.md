# JoshGPT Native Portal V8.4 — Passkey Counter Continuity

V8.4 hardens WebAuthn assertion continuity by persisting the authenticator signature counter from registration and checking it on later assertions. When both the stored and presented counters are positive, a non-increasing counter fails closed. Authenticators that intentionally report a zero counter remain compatible. The verified counter is persisted only after the assertion signature, RP ID, origin, challenge, UP and UV checks succeed.

This remains a checkpoint. The reproducible dependency/release gate and production-runtime smoke gate remain separate. Deployment target remains `joshgpt13`; the corporate project remains excluded.
