# JoshGPT Native Portal V4.0 — NSF-8 Semantic Ledger Checkpointing

NSF-8 replaces the fixed-capacity NSF-7 semantic feedback ledger with bounded, tamper-evident checkpoint compaction. Older entries are summarized by a SHA-256-bound checkpoint anchor while the retained tail preserves direct hash continuity. Sequence/head continuity, archive digest, previous anchor lineage, CAP-1 ANCESTOR signal, and fail-closed verification are enforced. This remains deterministic software; no trained foundation-model weights or physical bio/quantum hardware are claimed.
