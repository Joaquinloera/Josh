# JoshGPT Native Portal V7.3 — Deployment Hardening III

Architecture remains frozen at V7.0 / NSF-38. V7.3 corrects the Netlify Blobs integration to conform to the documented SDK contract used for production deployment.

- Strong consistency is configured when opening the store, rather than as an unsupported per-read option.
- Production continues to use site-wide stores; preview/dev continues to use deploy-scoped stores.
- Removed unsupported `onlyIfNew` / `result.modified` account-creation behavior from `setJSON`.
- Account creation now performs a strong existing-record check, writes with the documented `setJSON(key, value)` signature, and verifies the persisted record.
- Added V7.3 SDK-conformance regression tests and extended deployment preflight.

Netlify Blobs does not provide transactional concurrency control; account creation is therefore guarded and verified but is not represented as an atomic compare-and-set operation.
